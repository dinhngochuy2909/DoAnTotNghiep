<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { LogIn, Lock, Mail } from 'lucide-vue-next'
import { loginWithEmail, loginWithGoogle } from '../firebase/services'

const router = useRouter()
const email = ref('admin@sportai.com')
const password = ref('password123')
const errorMsg = ref('')
const isLoading = ref(false)

const handleLogin = async () => {
  errorMsg.value = ''
  isLoading.value = true
  
  // 1. Thử đăng nhập qua Firebase Auth
  const res = await loginWithEmail(email.value, password.value)
  if (res.success) {
    localStorage.setItem('isAuthenticated', 'true')
    localStorage.setItem('userEmail', res.user.email)
    router.push('/admin')
    isLoading.value = false
    return
  }

  // 2. Fallback tài khoản demo quản trị viên
  if (email.value === 'admin@sportai.com' && password.value === 'password123') {
    localStorage.setItem('isAuthenticated', 'true')
    localStorage.setItem('userEmail', 'admin@sportai.com')
    router.push('/admin')
  } else {
    errorMsg.value = res.error || 'Email hoặc mật khẩu không chính xác'
  }
  isLoading.value = false
}

const handleGoogleLogin = async () => {
  isLoading.value = true
  errorMsg.value = ''
  const res = await loginWithGoogle()
  if (res.success) {
    localStorage.setItem('isAuthenticated', 'true')
    localStorage.setItem('userEmail', res.user.email)
    localStorage.setItem('userName', res.user.displayName)
    router.push('/admin')
  } else {
    errorMsg.value = 'Đăng nhập Google thất bại: ' + (res.error || '')
  }
  isLoading.value = false
}
</script>

<template>
  <div class="login-container">
    <div class="login-box glass-panel">
      <div class="login-header">
        <div class="logo-icon">⚽</div>
        <h2>Alobooking <span class="text-gradient">Firebase</span></h2>
        <p>Hệ thống quản lý và đặt sân thể thao</p>
      </div>

      <form @submit.prevent="handleLogin" class="login-form">
        <div class="form-group">
          <label>Email đăng nhập</label>
          <div class="input-wrapper">
            <Mail class="input-icon" :size="18" />
            <input 
              v-model="email" 
              type="email" 
              placeholder="admin@sportai.com" 
              required
            />
          </div>
        </div>

        <div class="form-group">
          <label>Mật khẩu</label>
          <div class="input-wrapper">
            <Lock class="input-icon" :size="18" />
            <input 
              v-model="password" 
              type="password" 
              placeholder="••••••••" 
              required
            />
          </div>
        </div>

        <div v-if="errorMsg" class="error-message">
          {{ errorMsg }}
        </div>

        <div class="form-options">
          <label class="remember-me">
            <input type="checkbox" />
            <span>Ghi nhớ đăng nhập</span>
          </label>
          <a href="#" class="forgot-pwd">Quên mật khẩu?</a>
        </div>

        <button type="submit" class="btn btn-primary login-btn" :disabled="isLoading">
          <LogIn v-if="!isLoading" :size="20" />
          <span v-if="!isLoading">Đăng Nhập</span>
          <span v-else class="loader"></span>
        </button>

        <div class="divider">
          <span>HOẶC TIẾP TỤC VỚI</span>
        </div>

        <button type="button" @click="handleGoogleLogin" class="btn btn-google" :disabled="isLoading">
          <svg class="google-icon" viewBox="0 0 24 24" width="18" height="18">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
          </svg>
          <span>Đăng nhập với Google</span>
        </button>
      </form>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background-color: var(--bg-darker);
  position: relative;
  overflow: hidden;
}

.login-container::before {
  content: '';
  position: absolute;
  top: -20%;
  left: -10%;
  width: 500px;
  height: 500px;
  background: radial-gradient(circle, rgba(79, 70, 229, 0.2) 0%, rgba(0, 0, 0, 0) 70%);
  border-radius: 50%;
  pointer-events: none;
}

.login-container::after {
  content: '';
  position: absolute;
  bottom: -20%;
  right: -10%;
  width: 600px;
  height: 600px;
  background: radial-gradient(circle, rgba(16, 185, 129, 0.15) 0%, rgba(0, 0, 0, 0) 70%);
  border-radius: 50%;
  pointer-events: none;
}

.login-box {
  width: 100%;
  max-width: 420px;
  padding: 2.5rem;
  position: relative;
  z-index: 10;
  animation: slideUp 0.5s ease-out;
}

@keyframes slideUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.login-header {
  text-align: center;
  margin-bottom: 2.5rem;
}

.logo-icon {
  font-size: 2rem;
  background: var(--primary-color);
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 16px;
  margin: 0 auto 1rem;
  box-shadow: 0 8px 24px rgba(79, 70, 229, 0.4);
}

.login-header h2 {
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

.login-header p {
  color: var(--text-muted);
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-muted);
  margin-bottom: 0.5rem;
}

.input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 1rem;
  color: var(--text-muted);
}

.input-wrapper input {
  width: 100%;
  background-color: rgba(0, 0, 0, 0.2);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.75rem 1rem 0.75rem 2.75rem;
  border-radius: 10px;
  font-family: inherit;
  font-size: 1rem;
  transition: var(--transition);
}

.input-wrapper input:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  font-size: 0.875rem;
}

.remember-me {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--text-muted);
  cursor: pointer;
}

.forgot-pwd {
  color: var(--primary-color);
  transition: var(--transition);
}

.forgot-pwd:hover {
  color: var(--primary-hover);
  text-decoration: underline;
}

.login-btn {
  width: 100%;
  padding: 0.875rem;
  font-size: 1rem;
  border-radius: 10px;
}

.error-message {
  background-color: rgba(239, 68, 68, 0.1);
  color: #f87171;
  padding: 0.75rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  font-size: 0.875rem;
  text-align: center;
  border: 1px solid rgba(239, 68, 68, 0.2);
}

.loader {
  border: 3px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  border-top: 3px solid white;
  width: 20px;
  height: 20px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.divider {
  display: flex;
  align-items: center;
  text-align: center;
  margin: 1.5rem 0;
  color: var(--text-muted);
  font-size: 0.75rem;
  letter-spacing: 0.05em;
}

.divider::before,
.divider::after {
  content: '';
  flex: 1;
  border-bottom: 1px solid var(--border-color);
}

.divider span {
  padding: 0 0.75rem;
}

.btn-google {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  background-color: rgba(255, 255, 255, 0.08);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.8rem;
  border-radius: 10px;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-google:hover {
  background-color: rgba(255, 255, 255, 0.15);
  border-color: rgba(255, 255, 255, 0.3);
  transform: translateY(-1px);
}

.google-icon {
  flex-shrink: 0;
}
</style>
