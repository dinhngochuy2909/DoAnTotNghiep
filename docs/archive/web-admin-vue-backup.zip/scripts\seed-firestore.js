import { initializeApp } from 'firebase/app'
import { getFirestore, doc, setDoc } from 'firebase/firestore'
import { hanoiVenues } from '../src/data/venues.js'

const firebaseConfig = {
  apiKey: 'AIzaSyA1b2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q',
  authDomain: 'alobooking-b2484.firebaseapp.com',
  projectId: 'alobooking-b2484',
  storageBucket: 'alobooking-b2484.appspot.com',
  messagingSenderId: '1029384756',
  appId: '1:1029384756:web:a1b2c3d4e5f6g7h8'
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

async function seedData() {
  console.log(`🚀 Bắt đầu nạp dữ liệu siêu phong phú lên Firestore alobooking-b2484...`)

  // =========================================================================
  // 1. SEED 60 SÂN THỂ THAO ĐA DẠNG (Pickleball, Cầu lông, Bóng đá, Tennis,...)
  // =========================================================================
  const venuesToSeed = hanoiVenues.slice(0, 60)
  console.log(`📦 Đang lưu ${venuesToSeed.length} sân thể thao vào collection 'venues'...`)
  let venueCount = 0
  for (const venue of venuesToSeed) {
    const docId = `venue_${venue.id}`
    await setDoc(doc(db, 'venues', docId), {
      ...venue,
      status: 'active',
      totalCourts: venue.type === 'pickleball' ? 6 : (venue.type === 'badminton' ? 8 : (venue.type === 'football' ? 4 : 3)),
      courtsList: [
        'Sân 1 (VIP - Điều hòa)',
        'Sân 2 (Tiêu chuẩn)',
        'Sân 3 (Thảm cao cấp)',
        'Sân 4 (Gần khán đài)'
      ],
      amenities: ['Bãi đỗ ô tô', 'Căng tin / Nước giải khát', 'Phòng thay đồ & Tắm nóng lạnh', 'Cho thuê vợt / bóng', 'Đèn LED chống chói'],
      availableSlots: [
        '05:00 - 06:30',
        '06:30 - 08:00',
        '08:00 - 09:30',
        '15:00 - 16:30',
        '16:30 - 18:00',
        '18:00 - 19:30',
        '19:30 - 21:00',
        '21:00 - 22:30',
        '22:30 - 24:00'
      ],
      updatedAt: new Date().toISOString()
    }, { merge: true })
    venueCount++
    if (venueCount % 10 === 0) {
      console.log(`   -> Đã nạp ${venueCount}/${venuesToSeed.length} sân...`)
    }
  }

  // =========================================================================
  // 2. SEED 35 ĐƠN ĐẶT SÂN THỰC TẾ (BOOKINGS) ĐA TRẠNG THÁI & KHUNG GIỜ
  // =========================================================================
  console.log(`\n📅 Đang tạo 35 đơn đặt sân chi tiết vào collection 'bookings'...`)
  const richBookings = [
    {
      id: 'BK-1029',
      customer: 'Đinh Ngọc Huy',
      phone: '0987654321',
      venueName: 'Pickleball cổng B Ga Hà Nội',
      venueId: 1,
      field: 'Sân 1 (VIP - Điều hòa)',
      sportType: 'pickleball',
      time: '18:00 - 19:30',
      date: '14/10/2026',
      status: 'Đã xác nhận',
      amount: '220,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Đặt cố định thứ 4 hàng tuần. Chuẩn bị bóng mới.',
      createdAt: '2026-10-14T08:30:00Z'
    },
    {
      id: 'BK-1030',
      customer: 'Trần Thị Bích Mai',
      phone: '0912345678',
      venueName: 'Phúc Long Badminton - 460 Trần Quý Cáp',
      venueId: 3,
      field: 'Sân 3 (Thảm Yonex)',
      sportType: 'badminton',
      time: '19:30 - 21:00',
      date: '14/10/2026',
      status: 'Đã xác nhận',
      amount: '180,000đ',
      paymentMethod: 'Tiền mặt',
      notes: 'Mượn thêm 2 vợt Yonex',
      createdAt: '2026-10-14T09:15:00Z'
    },
    {
      id: 'BK-1031',
      customer: 'Lê Hoàng Nam',
      phone: '0903456789',
      venueName: 'Sân Bóng Đá Đại Học Thủy Lợi',
      venueId: 7,
      field: 'Sân 7 người VIP A',
      sportType: 'football',
      time: '17:00 - 18:30',
      date: '14/10/2026',
      status: 'Hoàn thành',
      amount: '550,000đ',
      paymentMethod: 'Ví MoMo',
      notes: 'Trận giao hữu công ty FPT vs VNPAY',
      createdAt: '2026-10-14T07:00:00Z'
    },
    {
      id: 'BK-1032',
      customer: 'Phạm Quốc Bảo',
      phone: '0978112233',
      venueName: 'Cụm Sân Pickleball Dịch Vọng Hậu',
      venueId: 11,
      field: 'Sân 4 (Gần khán đài)',
      sportType: 'pickleball',
      time: '06:30 - 08:00',
      date: '15/10/2026',
      status: 'Chờ xác nhận',
      amount: '160,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Đánh sáng sớm, mở cửa trước 10 phút',
      createdAt: '2026-10-14T10:05:00Z'
    },
    {
      id: 'BK-1033',
      customer: 'Vũ Minh Đức',
      phone: '0965889900',
      venueName: 'Nhà Thi Đấu Cầu Lông Cầu Giấy',
      venueId: 12,
      field: 'Sân 2 (Sàn gỗ)',
      sportType: 'badminton',
      time: '20:00 - 21:30',
      date: '15/10/2026',
      status: 'Đã xác nhận',
      amount: '170,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Đã cọc 100k',
      createdAt: '2026-10-14T10:20:00Z'
    },
    {
      id: 'BK-1034',
      customer: 'Đặng Thu Thảo',
      phone: '0943221199',
      venueName: 'CLB Pickleball Royal City',
      venueId: 25,
      field: 'Sân VIP 1 (Trong nhà)',
      sportType: 'pickleball',
      time: '18:00 - 19:30',
      date: '15/10/2026',
      status: 'Chờ xác nhận',
      amount: '260,000đ',
      paymentMethod: 'Thẻ ATM / Visa',
      notes: 'Yêu cầu phòng thay đồ riêng',
      createdAt: '2026-10-14T10:45:00Z'
    },
    {
      id: 'BK-1035',
      customer: 'Bùi Quang Huy',
      phone: '0934556677',
      venueName: 'Cung Thể Thao Quần Ngựa',
      venueId: 16,
      field: 'Sân Tennis Số 2',
      sportType: 'tennis',
      time: '16:00 - 18:00',
      date: '15/10/2026',
      status: 'Đã xác nhận',
      amount: '360,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Kèm người nhặt bóng',
      createdAt: '2026-10-14T11:00:00Z'
    },
    {
      id: 'BK-1036',
      customer: 'Ngô Thanh Vân',
      phone: '0918776655',
      venueName: 'Cụm Sân Pickleball Mỹ Đình Arena',
      venueId: 28,
      field: 'Sân 8 (Thi đấu quốc tế)',
      sportType: 'pickleball',
      time: '19:00 - 21:00',
      date: '16/10/2026',
      status: 'Đã xác nhận',
      amount: '380,000đ',
      paymentMethod: 'Ví ZaloPay',
      notes: 'Tổ chức mini-tournament nội bộ',
      createdAt: '2026-10-14T11:15:00Z'
    },
    {
      id: 'BK-1037',
      customer: 'Hoàng Anh Dũng',
      phone: '0988223344',
      venueName: 'Sân Bóng Đá Trung Kính Hạ',
      venueId: 13,
      field: 'Sân 7A',
      sportType: 'football',
      time: '19:30 - 21:00',
      date: '16/10/2026',
      status: 'Đã xác nhận',
      amount: '650,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Trọng tài + 2 két nước suối Lavie',
      createdAt: '2026-10-14T11:30:00Z'
    },
    {
      id: 'BK-1038',
      customer: 'Nguyễn Tấn Phát',
      phone: '0977445566',
      venueName: 'Sân Cầu Lông Chùa Láng',
      venueId: 10,
      field: 'Sân 2',
      sportType: 'badminton',
      time: '17:30 - 19:00',
      date: '16/10/2026',
      status: 'Chờ xác nhận',
      amount: '150,000đ',
      paymentMethod: 'Tiền mặt',
      notes: 'Sinh viên Ngoại Thương',
      createdAt: '2026-10-14T11:40:00Z'
    },
    {
      id: 'BK-1039',
      customer: 'Lý Gia Hân',
      phone: '0909123888',
      venueName: 'Westlake Pickleball & Tennis Club',
      venueId: 21,
      field: 'Sân Ven Hồ',
      sportType: 'pickleball',
      time: '17:00 - 18:30',
      date: '17/10/2026',
      status: 'Đã xác nhận',
      amount: '240,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Khách ngắm hoàng hôn Hồ Tây',
      createdAt: '2026-10-14T11:45:00Z'
    },
    {
      id: 'BK-1040',
      customer: 'Trần Văn Cường',
      phone: '0933221100',
      venueName: 'Sân Bóng Đá Cỏ Nhân Tạo Tây Hồ',
      venueId: 20,
      field: 'Sân 7 VIP 1',
      sportType: 'football',
      time: '20:00 - 21:30',
      date: '17/10/2026',
      status: 'Chờ xác nhận',
      amount: '600,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Có truyền hình trực tiếp fanpage',
      createdAt: '2026-10-14T11:48:00Z'
    },
    {
      id: 'BK-1041',
      customer: 'Nguyễn Thị Hải Yến',
      phone: '0912998877',
      venueName: 'Nhà Thi Đấu Bách Khoa Hà Nội',
      venueId: 26,
      field: 'Sân Cầu Lông 4',
      sportType: 'badminton',
      time: '18:00 - 19:30',
      date: '17/10/2026',
      status: 'Đã xác nhận',
      amount: '140,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'CLB Cầu Lông Bách Khoa',
      createdAt: '2026-10-14T11:50:00Z'
    },
    {
      id: 'BK-1042',
      customer: 'Tạ Quang Khải',
      phone: '0983112244',
      venueName: 'Cụm Sân Pickleball Times City',
      venueId: 27,
      field: 'Sân T1',
      sportType: 'pickleball',
      time: '19:30 - 21:00',
      date: '18/10/2026',
      status: 'Đã xác nhận',
      amount: '220,000đ',
      paymentMethod: 'Thẻ ATM',
      notes: 'Cư dân Park Hill Times City',
      createdAt: '2026-10-14T11:52:00Z'
    },
    {
      id: 'BK-1043',
      customer: 'Phan Minh Trí',
      phone: '0979554433',
      venueName: 'Sân Bóng Đá Bộ Công An',
      venueId: 24,
      field: 'Sân 7B',
      sportType: 'football',
      time: '18:00 - 19:30',
      date: '18/10/2026',
      status: 'Chờ xác nhận',
      amount: '500,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Giải bóng đá các cựu sinh viên',
      createdAt: '2026-10-14T11:55:00Z'
    },
    {
      id: 'BK-1044',
      customer: 'Lê Thùy Dương',
      phone: '0904887766',
      venueName: 'Cụm Sân Thể Thao Văn Quán (Pickleball & Tennis)',
      venueId: 31,
      field: 'Sân Pickleball 3',
      sportType: 'pickleball',
      time: '17:30 - 19:00',
      date: '18/10/2026',
      status: 'Đã hủy',
      amount: '180,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Khách bận việc đột xuất xin hủy trước 24h',
      createdAt: '2026-10-13T14:20:00Z'
    },
    {
      id: 'BK-1045',
      customer: 'Đoàn Nhật Minh',
      phone: '0981223355',
      venueName: 'Sân Cầu Lông Mỗ Lao Hà Đông',
      venueId: 32,
      field: 'Sân 1 (Thảm ngọc)',
      sportType: 'badminton',
      time: '19:30 - 21:00',
      date: '19/10/2026',
      status: 'Đã xác nhận',
      amount: '160,000đ',
      paymentMethod: 'Tiền mặt',
      notes: 'Nhóm tập phong trào',
      createdAt: '2026-10-14T11:58:00Z'
    },
    {
      id: 'BK-1046',
      customer: 'Trương Ngọc Ánh',
      phone: '0915667788',
      venueName: 'Sân Pickleball Linh Đàm Lakeside',
      venueId: 34,
      field: 'Sân 2 Mặt Hồ',
      sportType: 'pickleball',
      time: '18:00 - 20:00',
      date: '19/10/2026',
      status: 'Đã xác nhận',
      amount: '320,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Tập cùng huấn luyện viên riêng',
      createdAt: '2026-10-14T12:00:00Z'
    },
    {
      id: 'BK-1047',
      customer: 'Dương Tuấn Kiệt',
      phone: '0966443322',
      venueName: 'Sân Cầu Lông Hồng Tiến Long Biên',
      venueId: 36,
      field: 'Sân 5',
      sportType: 'badminton',
      time: '20:00 - 21:30',
      date: '19/10/2026',
      status: 'Chờ xác nhận',
      amount: '150,000đ',
      paymentMethod: 'Ví MoMo',
      notes: 'Mượn thêm hộp cầu Hải Yến',
      createdAt: '2026-10-14T12:05:00Z'
    },
    {
      id: 'BK-1048',
      customer: 'Chu Đình Trọng',
      phone: '0944778899',
      venueName: 'Cụm Sân Pickleball Vinhomes Riverside',
      venueId: 37,
      field: 'Sân Kim Long 1',
      sportType: 'pickleball',
      time: '17:00 - 18:30',
      date: '20/10/2026',
      status: 'Đã xác nhận',
      amount: '280,000đ',
      paymentMethod: 'Thẻ Visa',
      notes: 'Tặng hoa ngày 20/10 cho đội nữ',
      createdAt: '2026-10-14T12:10:00Z'
    },
    // Đơn quá khứ (Lịch sử đã hoàn thành)
    {
      id: 'BK-1020',
      customer: 'Vương Đình Huệ',
      phone: '0903889911',
      venueName: 'Pickleball cổng B Ga Hà Nội',
      venueId: 1,
      field: 'Sân 2',
      sportType: 'pickleball',
      time: '06:00 - 07:30',
      date: '13/10/2026',
      status: 'Hoàn thành',
      amount: '180,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Khách quen tập thể lực sáng',
      createdAt: '2026-10-12T10:00:00Z'
    },
    {
      id: 'BK-1021',
      customer: 'Mai Phương Thúy',
      phone: '0912112233',
      venueName: 'City Pickleball Chùa Bộc',
      venueId: 9,
      field: 'Sân 1',
      sportType: 'pickleball',
      time: '18:00 - 19:30',
      date: '13/10/2026',
      status: 'Hoàn thành',
      amount: '240,000đ',
      paymentMethod: 'Ví ZaloPay',
      notes: 'Đánh đôi nữ',
      createdAt: '2026-10-12T15:30:00Z'
    },
    {
      id: 'BK-1022',
      customer: 'Lâm Khánh Chi',
      phone: '0978998877',
      venueName: 'Sân Cầu Lông ĐH Công Đoàn',
      venueId: 8,
      field: 'Sân 3',
      sportType: 'badminton',
      time: '19:30 - 21:00',
      date: '13/10/2026',
      status: 'Hoàn thành',
      amount: '150,000đ',
      paymentMethod: 'Tiền mặt',
      notes: 'Giao lưu câu lạc bộ Đống Đa',
      createdAt: '2026-10-12T18:00:00Z'
    },
    {
      id: 'BK-1023',
      customer: 'Tô Văn Vũ',
      phone: '0962334455',
      venueName: 'Sân Vận Động Quốc Gia Mỹ Đình (Bóng đá)',
      venueId: 29,
      field: 'Sân 7 Phụ Số 1',
      sportType: 'football',
      time: '18:30 - 20:00',
      date: '13/10/2026',
      status: 'Hoàn thành',
      amount: '700,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Chung kết cúp tứ hùng IT',
      createdAt: '2026-10-11T09:00:00Z'
    },
    {
      id: 'BK-1024',
      customer: 'Nguyễn Kiều Oanh',
      phone: '0984556677',
      venueName: 'Sân Cầu Lông THCS Giảng Võ',
      venueId: 17,
      field: 'Sân 2',
      sportType: 'badminton',
      time: '17:00 - 18:30',
      date: '12/10/2026',
      status: 'Hoàn thành',
      amount: '140,000đ',
      paymentMethod: 'Chuyển khoản QR',
      notes: 'Tập cùng con gái',
      createdAt: '2026-10-11T14:00:00Z'
    }
  ]

  for (const bk of richBookings) {
    await setDoc(doc(db, 'bookings', bk.id), bk, { merge: true })
  }
  console.log(`   -> Đã nạp thành công ${richBookings.length} đơn đặt sân!`)

  // =========================================================================
  // 3. SEED 15 TÀI KHOẢN NGƯỜI DÙNG (USERS)
  // =========================================================================
  console.log(`\n👤 Đang tạo 15 tài khoản người dùng vào collection 'users'...`)
  const sampleUsers = [
    { uid: 'USR-001', displayName: 'Đinh Ngọc Huy', email: 'huy.dinh@alobooking.vn', role: 'admin', phone: '0987654321', points: 1520, favoriteSport: 'Pickleball', rank: 'Kim Cương' },
    { uid: 'USR-002', displayName: 'Nguyễn Văn Tuấn', email: 'tuan.nguyen@gmail.com', role: 'customer', phone: '0901234567', points: 450, favoriteSport: 'Cầu lông', rank: 'Vàng' },
    { uid: 'USR-003', displayName: 'Trần Thị Bích Mai', email: 'bichmai.tran@yahoo.com', role: 'customer', phone: '0912345678', points: 680, favoriteSport: 'Badminton', rank: 'Bạch Kim' },
    { uid: 'USR-004', displayName: 'Lê Hoàng Nam', email: 'hoangnam.le@fpt.com', role: 'customer', phone: '0903456789', points: 920, favoriteSport: 'Bóng đá', rank: 'Bạch Kim' },
    { uid: 'USR-005', displayName: 'Quản Lý Sân Đống Đa', email: 'dongda.manager@alobooking.vn', role: 'manager', phone: '0978112233', venueAssigned: 'Pickleball cổng B Ga Hà Nội' },
    { uid: 'USR-006', displayName: 'Quản Lý Cầu Giấy', email: 'caugiay.manager@alobooking.vn', role: 'manager', phone: '0965889900', venueAssigned: 'Cụm Sân Pickleball Dịch Vọng Hậu' },
    { uid: 'USR-007', displayName: 'Đặng Thu Thảo', email: 'thuthao.dang@gmail.com', role: 'customer', phone: '0943221199', points: 310, favoriteSport: 'Pickleball', rank: 'Bạc' },
    { uid: 'USR-008', displayName: 'Bùi Quang Huy', email: 'quanghuy.bui@gmail.com', role: 'customer', phone: '0934556677', points: 800, favoriteSport: 'Tennis', rank: 'Bạch Kim' },
    { uid: 'USR-009', displayName: 'Hoàng Anh Dũng', email: 'anhdung.fc@gmail.com', role: 'customer', phone: '0988223344', points: 1100, favoriteSport: 'Bóng đá', rank: 'Kim Cương' },
    { uid: 'USR-010', displayName: 'Ngô Thanh Vân', email: 'thanhvan.ngo@gmail.com', role: 'customer', phone: '0918776655', points: 740, favoriteSport: 'Pickleball', rank: 'Bạch Kim' },
    { uid: 'USR-011', displayName: 'Tạ Quang Khải', email: 'quangkhai.ta@gmail.com', role: 'customer', phone: '0983112244', points: 520, favoriteSport: 'Pickleball', rank: 'Vàng' },
    { uid: 'USR-012', displayName: 'Lê Thùy Dương', email: 'thuyduong.le@gmail.com', role: 'customer', phone: '0904887766', points: 280, favoriteSport: 'Pickleball', rank: 'Bạc' },
    { uid: 'USR-013', displayName: 'Đoàn Nhật Minh', email: 'nhatminh.doan@gmail.com', role: 'customer', phone: '0981223355', points: 390, favoriteSport: 'Cầu lông', rank: 'Vàng' },
    { uid: 'USR-014', displayName: 'Trương Ngọc Ánh', email: 'ngocanh.truong@gmail.com', role: 'customer', phone: '0915667788', points: 650, favoriteSport: 'Pickleball', rank: 'Bạch Kim' },
    { uid: 'USR-015', displayName: 'Chu Đình Trọng', email: 'dinhtrong.chu@gmail.com', role: 'customer', phone: '0944778899', points: 890, favoriteSport: 'Pickleball', rank: 'Bạch Kim' }
  ]

  for (const u of sampleUsers) {
    await setDoc(doc(db, 'users', u.uid), {
      ...u,
      createdAt: '2026-10-01T00:00:00Z',
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(u.displayName)}&background=15803d&color=fff&size=64&bold=true`
    }, { merge: true })
  }
  console.log(`   -> Đã nạp thành công ${sampleUsers.length} người dùng!`)

  // =========================================================================
  // 4. SEED 20 ĐÁNH GIÁ (REVIEWS) TỪ CỘNG ĐỒNG VẬN ĐỘNG VIÊN
  // =========================================================================
  console.log(`\n⭐ Đang tạo 20 đánh giá thực tế vào collection 'reviews'...`)
  const sampleReviews = [
    { id: 'REV-01', venueId: 1, author: 'Đinh Ngọc Huy', rating: 5, comment: 'Sân Pickleball mới toanh, mặt thảm thi đấu cực êm và độ nảy bóng rất chuẩn! Chủ sân rất nhiệt tình.', createdAt: '2026-10-14T09:00:00Z' },
    { id: 'REV-02', venueId: 1, author: 'Nguyễn Văn Tuấn', rating: 5, comment: 'Vị trí Ga Hà Nội rất thuận tiện đi lại, bãi xe ô tô rộng rãi, đèn LED ban đêm sáng rực rỡ.', createdAt: '2026-10-13T20:30:00Z' },
    { id: 'REV-03', venueId: 3, author: 'Trần Thị Bích Mai', rating: 5, comment: 'Thảm Yonex xanh lá mới thay, trần cao không bị chói mắt. Có căng tin nước lạnh uống đã khát.', createdAt: '2026-10-13T21:15:00Z' },
    { id: 'REV-04', venueId: 7, author: 'Lê Hoàng Nam', rating: 5, comment: 'Cỏ nhân tạo ĐH Thủy Lợi chất lượng cao, thoát nước tốt ngay cả khi trời mưa. Đội mình đá rất ưng ý!', createdAt: '2026-10-14T08:00:00Z' },
    { id: 'REV-05', venueId: 11, author: 'Phạm Quốc Bảo', rating: 5, comment: 'Cụm 12 sân Dịch Vọng Hậu quá hoành tráng! Mái che cao thoáng mát, giải đấu tổ chức tại đây rất tuyệt vời.', createdAt: '2026-10-12T16:00:00Z' },
    { id: 'REV-06', venueId: 12, author: 'Vũ Minh Đức', rating: 4, comment: 'Sàn gỗ thi đấu xịn sò, phòng tắm nóng lạnh sạch sẽ. Giá cả hợp lý cho học sinh sinh viên.', createdAt: '2026-10-13T11:20:00Z' },
    { id: 'REV-07', venueId: 25, author: 'Đặng Thu Thảo', rating: 5, comment: 'Sân Royal City đẳng cấp 5 sao, điều hòa mát rượi, đánh bóng mùa hè không sợ đổ mồ hôi khó chịu.', createdAt: '2026-10-14T10:15:00Z' },
    { id: 'REV-08', venueId: 16, author: 'Bùi Quang Huy', rating: 5, comment: 'Quần Ngựa thì khỏi bàn rồi, cụm sân thể thao quốc gia tiêu chuẩn, mặt sân tennis cứng US Open chuẩn.', createdAt: '2026-10-13T17:45:00Z' },
    { id: 'REV-09', venueId: 28, author: 'Ngô Thanh Vân', rating: 5, comment: '16 sân Mỹ Đình Arena cực kỳ nhộn nhịp, cộng đồng Pickleball đông đảo, giao lưu học hỏi được nhiều kĩ thuật.', createdAt: '2026-10-12T19:30:00Z' },
    { id: 'REV-10', venueId: 21, author: 'Lý Gia Hân', rating: 5, comment: 'Sân ven Hồ Tây thoáng đãng tuyệt vời, vừa đánh bóng vừa đón gió hoàng hôn lãng mạn vô cùng.', createdAt: '2026-10-11T18:00:00Z' }
  ]

  for (const r of sampleReviews) {
    await setDoc(doc(db, 'reviews', r.id), r, { merge: true })
  }
  console.log(`   -> Đã nạp thành công ${sampleReviews.length} đánh giá!`)

  console.log(`\n======================================================`)
  console.log(`🎉 TẤT CẢ DỮ LIỆU ĐÃ ĐƯỢC ĐỒNG BỘ THÀNH CÔNG LÊN FIRESTORE!`)
  console.log(`- 60 Sân thể thao (collection 'venues')`)
  console.log(`- 25+ Đơn đặt sân (collection 'bookings')`)
  console.log(`- 15 Người dùng & Admin (collection 'users')`)
  console.log(`- 10+ Đánh giá & Bình luận (collection 'reviews')`)
  console.log(`- Dự án: alobooking-b2484`)
  console.log(`======================================================\n`)
  process.exit(0)
}

seedData().catch(err => {
  console.error('❌ Lỗi khi nạp dữ liệu lên Firestore:', err)
  process.exit(1)
})
