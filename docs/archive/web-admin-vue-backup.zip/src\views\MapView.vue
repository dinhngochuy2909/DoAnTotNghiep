<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { hanoiVenues } from '../data/venues.js'

const router = useRouter()
const mapElement = ref(null)
let leafletMap = null
let markerLayers = []

const activeCategory = ref('all')
const searchQuery = ref('')
const selectedVenue = ref(null)

// Sport categories matching screenshot
const categories = [
  { id: 'all', name: 'Tất cả', color: '#16a34a', icon: '🏆' },
  { id: 'pickleball', name: 'Pickleball', color: '#2563eb', bg: '#eff6ff', icon: '🎾' },
  { id: 'badminton', name: 'Cầu lông', color: '#0d9488', bg: '#f0fdfa', icon: '🏸' },
  { id: 'football', name: 'Bóng đá', color: '#16a34a', bg: '#f0fdf4', icon: '⚽' },
  { id: 'basketball', name: 'Bóng rổ', color: '#d97706', bg: '#fffbeb', icon: '🏀' },
  { id: 'tennis', name: 'Quần vợt', color: '#c2410c', bg: '#fff7ed', icon: '🎾' },
  { id: 'multi', name: 'Đa năng', color: '#be123c', bg: '#fff1f2', icon: '🎯' },
  { id: 'typti', name: 'Typti', color: '#0284c7', bg: '#f0f9ff', icon: '📍' },
]

// 42 Venues across all Hanoi districts from data/venues.js
const venues = ref(hanoiVenues.map(v => ({
  ...v,
  category: v.type
})))

// Custom SVG HTML Marker for Leaflet matching the screenshot drop-pin design exactly
const createCustomPinIcon = (category, isSelected = false) => {
  const cat = categories.find(c => c.id === category) || categories[1] // default pickleball
  const color = cat.color
  const scale = isSelected ? 1.4 : 1.0
  const width = Math.round(26 * scale)
  const height = Math.round(34 * scale)

  // Droplet pin with inner white circle and sport icon
  const html = `
    <div style="width: ${width}px; height: ${height}px; transform: translate(-50%, -100%); cursor: pointer; transition: transform 0.15s ease;">
      <svg width="${width}" height="${height}" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M14 0C6.26801 0 0 6.26801 0 14C0 21.5 11.2 34.2 13.2 35.5C13.7 35.8 14.3 35.8 14.8 35.5C16.8 34.2 28 21.5 28 14C28 6.26801 21.732 0 14 0Z" fill="${color}" filter="drop-shadow(0 2px 4px rgba(0,0,0,0.38))"/>
        <circle cx="14" cy="14" r="10.5" fill="#ffffff" fill-opacity="0.25"/>
        <circle cx="14" cy="14" r="9" fill="#ffffff"/>
        <circle cx="14" cy="14" r="8" fill="${color}"/>
        <text x="14" y="18" font-size="9" text-anchor="middle" fill="#ffffff">${cat.icon}</text>
      </svg>
    </div>
  `

  return L.divIcon({
    html: html,
    className: 'custom-venue-pin',
    iconSize: [0, 0],
    iconAnchor: [0, 0],
  })
}

// Initialize Leaflet Map
const initMap = () => {
  if (!mapElement.value) return

  // Center on Hanoi matching screenshot
  leafletMap = L.map(mapElement.value, {
    center: [21.0200, 105.8450],
    zoom: 12.5,
    zoomControl: false,
    attributionControl: false
  })

  // Google Maps Direct Layer (sử dụng trực tiếp tile Google Maps rõ nét, chuẩn 100% tiếng Việt)
  L.tileLayer('https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
    maxZoom: 20,
    subdomains: ['0', '1', '2', '3'],
  }).addTo(leafletMap)

  renderMarkers()
}

// Render filtered markers
const renderMarkers = () => {
  if (!leafletMap) return

  // Clear existing markers
  markerLayers.forEach(m => leafletMap.removeLayer(m))
  markerLayers = []

  const filtered = activeCategory.value === 'all'
    ? venues.value
    : venues.value.filter(v => v.category === activeCategory.value)

  filtered.forEach(v => {
    const isSelected = selectedVenue.value && selectedVenue.value.id === v.id
    const marker = L.marker([v.lat, v.lng], {
      icon: createCustomPinIcon(v.category, isSelected)
    })

    marker.on('click', () => {
      selectedVenue.value = v
      renderMarkers()
      leafletMap.panTo([v.lat, v.lng], { animate: true })
    })

    marker.addTo(leafletMap)
    markerLayers.push(marker)
  })
}

const setCategory = (catId) => {
  activeCategory.value = catId
  renderMarkers()
}

const selectVenue = (v) => {
  selectedVenue.value = v
  if (leafletMap) {
    leafletMap.setView([v.lat, v.lng], 14, { animate: true })
    renderMarkers()
  }
}

const locateMe = () => {
  if (navigator.geolocation && leafletMap) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = [pos.coords.latitude, pos.coords.longitude]
        leafletMap.setView(coords, 14, { animate: true })
        // Add a pulsing blue dot
        L.circleMarker(coords, {
          radius: 9,
          fillColor: '#2563eb',
          color: '#ffffff',
          weight: 3,
          opacity: 1,
          fillOpacity: 0.9
        }).addTo(leafletMap)
      },
      () => {
        alert('Không thể xác định vị trí hiện tại của thiết bị.')
      }
    )
  }
}

watch(activeCategory, () => {
  renderMarkers()
})

onMounted(() => {
  initMap()
})
</script>

<template>
  <div class="map-view-shell">
    
    <!-- ===== TOP BAR: SEARCH & RECENT PLACE ===== -->
    <div class="map-header-overlay">
      <!-- Search Box Card -->
      <div class="search-card">
        <div class="search-input-row">
          <!-- Green badminton logo -->
          <div class="brand-logo" @click="router.push('/')" title="Về trang chủ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="11" fill="#16a34a"/>
              <path d="M7 8 Q12 15 17 8 Q14 7 12 7 Q10 7 7 8 Z" fill="rgba(255,255,255,0.4)" stroke="#fff" stroke-width="1.2"/>
              <circle cx="12" cy="15" r="2.5" fill="#fff"/>
            </svg>
          </div>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Tìm kiếm sân quanh đây..."
            class="search-input"
          />
          <button class="search-action-btn" title="Tìm">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"/>
              <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
          </button>
        </div>

        <!-- Recent / Suggested place row -->
        <div class="recent-place-item" @click="selectVenue(venues[2])">
          <div class="recent-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
          </div>
          <div class="recent-text">
            <div class="recent-name">Trường THCS Giảng Võ 2</div>
            <div class="recent-address">(2.1km) 105, Ngõ 12 Núi Trúc, Giảng Võ, Hà Nội</div>
          </div>
          <button class="recent-dir-btn" title="Chỉ đường">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <polygon points="3 11 22 2 13 21 11 13 3 11"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Top Sport Filter Chips -->
      <div class="filter-chips-wrapper">
        <button
          v-for="cat in categories"
          :key="cat.id"
          class="sport-chip"
          :class="{ active: activeCategory === cat.id }"
          @click="setCategory(cat.id)"
        >
          <span class="chip-icon">{{ cat.icon }}</span>
          <span class="chip-name">{{ cat.name }}</span>
        </button>
      </div>
    </div>

    <!-- ===== MAP CANVAS ===== -->
    <div ref="mapElement" class="map-canvas"></div>

    <!-- ===== RIGHT FLOAT BUTTONS ===== -->
    <div class="floating-controls">
      <!-- Layers button -->
      <button class="fab-btn" title="Lớp bản đồ">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="12 2 2 7 12 12 22 7 12 2"/>
          <polyline points="2 17 12 22 22 17"/>
          <polyline points="2 12 12 17 22 12"/>
        </svg>
      </button>
      <!-- List button -->
      <button class="fab-btn fab-list" title="Danh sách sân" @click="router.push('/')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="8" y1="6" x2="21" y2="6"/>
          <line x1="8" y1="12" x2="21" y2="12"/>
          <line x1="8" y1="18" x2="21" y2="18"/>
          <line x1="3" y1="6" x2="3.01" y2="6"/>
          <line x1="3" y1="12" x2="3.01" y2="12"/>
          <line x1="3" y1="18" x2="3.01" y2="18"/>
        </svg>
      </button>
      <!-- Location GPS button -->
      <button class="fab-btn fab-gps" @click="locateMe" title="Vị trí của tôi">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <polygon points="12 8 8 12 12 16 16 12 12 8"/>
        </svg>
      </button>
    </div>

    <!-- ===== SELECTED VENUE POPUP CARD ===== -->
    <div v-if="selectedVenue" class="venue-info-float">
      <div class="venue-info-header">
        <div>
          <h4 class="venue-title">{{ selectedVenue.name }}</h4>
          <p class="venue-sub">{{ selectedVenue.distance }} • {{ selectedVenue.address }}</p>
          <span class="venue-price">{{ selectedVenue.price }}</span>
        </div>
        <button class="close-info-btn" @click="selectedVenue = null">✕</button>
      </div>
      <button class="btn-book-now" @click="router.push('/')">
        ĐẶT LỊCH NGAY
      </button>
    </div>

    <!-- ===== BOTTOM NAVIGATION ===== -->
    <nav class="bottom-nav">
      <button class="bnav-item" @click="router.push('/')">
        <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
          <polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
        <span class="bnav-label">Trang chủ</span>
      </button>

      <button class="bnav-item active">
        <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
          <line x1="8" y1="2" x2="8" y2="18"/>
          <line x1="16" y1="6" x2="16" y2="22"/>
        </svg>
        <span class="bnav-label">Bản đồ</span>
      </button>

      <button class="bnav-item" @click="router.push('/')">
        <div class="explore-circle">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="7" height="7"/>
            <rect x="14" y="3" width="7" height="7"/>
            <rect x="14" y="14" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/>
          </svg>
        </div>
        <span class="bnav-label">Khám phá</span>
      </button>

      <button class="bnav-item" @click="router.push('/')">
        <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
        </svg>
        <span class="bnav-label">Nổi bật</span>
      </button>

      <button class="bnav-item" @click="router.push('/profile')">
        <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
        <span class="bnav-label">Tài khoản</span>
      </button>
    </nav>

  </div>
</template>

<style scoped>
.map-view-shell {
  position: relative;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
}

/* Fullscreen Map Canvas */
.map-canvas {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
}

/* TOP OVERLAY HEADER */
.map-header-overlay {
  position: absolute;
  top: 14px;
  left: 14px;
  right: 14px;
  z-index: 1000;
  display: flex;
  align-items: flex-start;
  gap: 16px;
  pointer-events: none;
}

/* Search Card Left */
.search-card {
  width: 380px;
  background: #ffffff;
  border-radius: 20px;
  padding: 8px 12px 10px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.12);
  pointer-events: auto;
  border: 1px solid rgba(0, 0, 0, 0.06);
}

.search-input-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 4px 6px 8px;
  border-bottom: 1px solid #f3f4f6;
}

.brand-logo {
  cursor: pointer;
  display: flex;
  align-items: center;
}

.search-input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 0.95rem;
  color: #1f2937;
  background: transparent;
}

.search-input::placeholder {
  color: #9ca3af;
}

.search-action-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
}

/* Recent Place Item */
.recent-place-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 6px 2px;
  cursor: pointer;
  border-radius: 10px;
  transition: background 0.15s;
}

.recent-place-item:hover {
  background: #f9fafb;
}

.recent-icon {
  color: #6b7280;
  display: flex;
  align-items: center;
}

.recent-text {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.recent-name {
  font-size: 0.9rem;
  font-weight: 700;
  color: #166534;
}

.recent-address {
  font-size: 0.76rem;
  color: #6b7280;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 250px;
}

.recent-dir-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: #6b7280;
  display: flex;
  align-items: center;
}

/* Filter Chips Top Right */
.filter-chips-wrapper {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow-x: auto;
  pointer-events: auto;
  padding-top: 4px;
  scrollbar-width: none;
}

.filter-chips-wrapper::-webkit-scrollbar {
  display: none;
}

.sport-chip {
  display: flex;
  align-items: center;
  gap: 6px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  padding: 8px 14px;
  border-radius: 24px;
  font-size: 0.85rem;
  font-weight: 600;
  color: #374151;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  white-space: nowrap;
  transition: all 0.2s;
}

.sport-chip:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

.sport-chip.active {
  background: #16a34a;
  color: #ffffff;
  border-color: #16a34a;
}

/* FLOATING CONTROLS RIGHT */
.floating-controls {
  position: absolute;
  right: 18px;
  bottom: 85px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.fab-btn {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #374151;
  cursor: pointer;
  transition: all 0.2s;
}

.fab-btn:hover {
  transform: scale(1.08);
}

.fab-list, .fab-gps {
  background: #1e3a2b;
  color: #ffffff;
  border: none;
}

.fab-gps {
  background: #16a34a;
}

/* VENUE FLOAT CARD */
.venue-info-float {
  position: absolute;
  left: 20px;
  bottom: 85px;
  width: 340px;
  background: #ffffff;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  z-index: 1000;
  border: 1px solid #e5e7eb;
}

.venue-info-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 12px;
}

.venue-title {
  font-size: 1rem;
  font-weight: 700;
  color: #111827;
  margin: 0 0 4px;
}

.venue-sub {
  font-size: 0.8rem;
  color: #6b7280;
  margin: 0 0 6px;
}

.venue-price {
  font-size: 0.85rem;
  font-weight: 700;
  color: #16a34a;
}

.close-info-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: #9ca3af;
  font-size: 1rem;
}

.btn-book-now {
  width: 100%;
  background: #16a34a;
  color: #ffffff;
  border: none;
  padding: 10px 0;
  border-radius: 8px;
  font-weight: 700;
  font-size: 0.88rem;
  cursor: pointer;
  transition: background 0.2s;
}

.btn-book-now:hover {
  background: #15803d;
}

/* BOTTOM NAVIGATION */
.bottom-nav {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 64px;
  background: #ffffff;
  border-top: 1px solid #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-around;
  z-index: 1000;
  box-shadow: 0 -2px 12px rgba(0, 0, 0, 0.06);
}

.bnav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  background: none;
  border: none;
  cursor: pointer;
  color: #9ca3af;
  padding: 4px 12px;
  transition: all 0.2s;
}

.bnav-item.active {
  color: #16a34a;
}

.bnav-label {
  font-size: 0.7rem;
  font-weight: 600;
}

.explore-circle {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  border: 2px solid #16a34a;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #16a34a;
  margin-top: -12px;
  background: #ffffff;
}

@media (max-width: 768px) {
  .map-header-overlay {
    flex-direction: column;
  }
  .search-card {
    width: 100%;
  }
}
</style>
