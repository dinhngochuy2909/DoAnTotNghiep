<script setup>
import { ref, computed } from 'vue'
import { Users, Search, Phone, Mail, Calendar, Shield, Award, Star, X, CheckCircle2 } from 'lucide-vue-next'

const searchQuery = ref('')
const selectedRole = ref('all')

const customers = ref([
  { id: 1, name: 'Nguyễn Văn An', phone: '0901234567', email: 'an.nguyen@gmail.com', bookingsCount: 18, totalSpent: '4.250.000đ', favoriteSport: 'Pickleball', rank: 'VIP Vàng', status: 'Hoạt động', joinDate: '12/03/2026' },
  { id: 2, name: 'Trần Thị Bích', phone: '0912345678', email: 'bich.tran@gmail.com', bookingsCount: 12, totalSpent: '2.800.000đ', favoriteSport: 'Cầu lông', rank: 'Bạc', status: 'Hoạt động', joinDate: '24/04/2026' },
  { id: 3, name: 'Lê Hoàng Nam', phone: '0987654321', email: 'nam.le@yahoo.com', bookingsCount: 25, totalSpent: '7.600.000đ', favoriteSport: 'Bóng đá', rank: 'VIP Kim Cương', status: 'Hoạt động', joinDate: '05/01/2026' },
  { id: 4, name: 'Phạm Minh Đức', phone: '0933445566', email: 'duc.pham@outlook.com', bookingsCount: 8, totalSpent: '1.600.000đ', favoriteSport: 'Pickleball', rank: 'Đồng', status: 'Hoạt động', joinDate: '15/06/2026' },
  { id: 5, name: 'Hoàng Anh Tuấn', phone: '0977889900', email: 'tuan.hoang@gmail.com', bookingsCount: 15, totalSpent: '5.200.000đ', favoriteSport: 'Tennis', rank: 'VIP Vàng', status: 'Hoạt động', joinDate: '20/02/2026' },
  { id: 6, name: 'Đỗ Thùy Trang', phone: '0944556677', email: 'trang.do@gmail.com', bookingsCount: 4, totalSpent: '920.000đ', favoriteSport: 'Cầu lông', rank: 'Đồng', status: 'Tạm khóa', joinDate: '10/08/2026' },
])

const filteredCustomers = computed(() => {
  return customers.value.filter(c => {
    const q = searchQuery.value.trim().toLowerCase()
    const matchesQuery = !q ||
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.email.toLowerCase().includes(q)

    const matchesRole = selectedRole.value === 'all' ||
      (selectedRole.value === 'vip' && c.rank.includes('VIP')) ||
      (selectedRole.value === 'active' && c.status === 'Hoạt động')

    return matchesQuery && matchesRole
  })
})

const rankBadgeClass = (rank) => {
  if (rank.includes('Kim Cương')) return 'rank-diamond'
  if (rank.includes('Vàng')) return 'rank-gold'
  if (rank.includes('Bạc')) return 'rank-silver'
  return 'rank-bronze'
}
</script>

<template>
  <div class="customer-view">
    <div class="top-bar glass-panel">
      <div class="search-box">
        <Search :size="18" class="icon" />
        <input v-model="searchQuery" type="text" placeholder="Tìm theo tên khách, SĐT, email..." />
        <button v-if="searchQuery" @click="searchQuery = ''" class="clear-btn"><X :size="16" /></button>
      </div>

      <div class="filter-tabs">
        <button :class="['tab-btn', { active: selectedRole === 'all' }]" @click="selectedRole = 'all'">Tất cả ({{ customers.length }})</button>
        <button :class="['tab-btn', { active: selectedRole === 'vip' }]" @click="selectedRole = 'vip'">Hội Viên VIP</button>
        <button :class="['tab-btn', { active: selectedRole === 'active' }]" @click="selectedRole = 'active'">Đang Hoạt Động</button>
      </div>
    </div>

    <div class="table-container glass-panel">
      <table class="data-table">
        <thead>
          <tr>
            <th>Khách Hàng</th>
            <th>Liên Hệ</th>
            <th>Hạng Thành Viên</th>
            <th>Môn Yêu Thích</th>
            <th>Số Lượt Đặt</th>
            <th>Tổng Chi Tiêu</th>
            <th>Trạng Thái</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="c in filteredCustomers" :key="c.id">
            <td>
              <div class="cust-profile">
                <div class="avatar">{{ c.name.charAt(0) }}</div>
                <div class="info">
                  <strong>{{ c.name }}</strong>
                  <span class="join-date">Gia nhập: {{ c.joinDate }}</span>
                </div>
              </div>
            </td>
            <td>
              <div class="contact-info">
                <span><Phone :size="13" /> {{ c.phone }}</span>
                <span class="email"><Mail :size="13" /> {{ c.email }}</span>
              </div>
            </td>
            <td>
              <span class="rank-badge" :class="rankBadgeClass(c.rank)">
                <Award :size="14" /> {{ c.rank }}
              </span>
            </td>
            <td><span class="sport-tag">{{ c.favoriteSport }}</span></td>
            <td><strong>{{ c.bookingsCount }} lượt</strong></td>
            <td><strong class="text-success">{{ c.totalSpent }}</strong></td>
            <td>
              <span :class="['status-tag', c.status === 'Hoạt động' ? 'status-active' : 'status-blocked']">
                {{ c.status }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.customer-view {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.search-box {
  display: flex;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 0.55rem 1rem;
  width: 320px;
}

.search-box .icon { color: var(--text-muted); margin-right: 0.5rem; }
.search-box input { background: none; border: none; color: var(--text-main); outline: none; width: 100%; font-size: 0.9rem; }
.clear-btn { background: none; border: none; color: var(--text-muted); cursor: pointer; }

.filter-tabs {
  display: flex;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border-color);
  padding: 3px;
  border-radius: 10px;
  gap: 4px;
}

.tab-btn {
  padding: 6px 14px;
  border-radius: 8px;
  color: var(--text-muted);
  font-size: 0.85rem;
  transition: var(--transition-fast);
}

.tab-btn.active { background: var(--primary-color); color: #fff; font-weight: 600; }

.table-container { overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; }
.data-table th { background: rgba(0,0,0,0.25); color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; padding: 1rem 1.25rem; text-align: left; border-bottom: 1px solid var(--border-color); }
.data-table td { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border-color); font-size: 0.9rem; }
.data-table tr:hover { background: rgba(255,255,255,0.02); }

.cust-profile { display: flex; align-items: center; gap: 12px; }
.avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #a855f7); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.9rem; }
.cust-profile .info { display: flex; flex-direction: column; }
.join-date { font-size: 0.75rem; color: var(--text-muted); }

.contact-info { display: flex; flex-direction: column; gap: 2px; font-size: 0.85rem; color: var(--text-muted); }
.contact-info span { display: flex; align-items: center; gap: 6px; }

.rank-badge { display: inline-flex; align-items: center; gap: 5px; padding: 3px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
.rank-diamond { background: rgba(168, 85, 247, 0.2); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.4); }
.rank-gold { background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); }
.rank-silver { background: rgba(148, 163, 184, 0.2); color: #cbd5e1; border: 1px solid rgba(148, 163, 184, 0.4); }
.rank-bronze { background: rgba(217, 119, 6, 0.15); color: #d97706; border: 1px solid rgba(217, 119, 6, 0.3); }

.sport-tag { background: rgba(255, 255, 255, 0.05); padding: 3px 8px; border-radius: 6px; font-size: 0.8rem; }
.text-success { color: #10b981; }

.status-tag { display: inline-flex; padding: 3px 10px; border-radius: 12px; font-size: 0.8rem; font-weight: 500; }
.status-active { background: rgba(16, 185, 129, 0.15); color: #34d399; }
.status-blocked { background: rgba(239, 68, 68, 0.15); color: #f87171; }
</style>
