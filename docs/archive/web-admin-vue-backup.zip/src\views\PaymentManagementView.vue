<script setup>
import { ref, computed } from 'vue'
import { CreditCard, Search, ArrowDownLeft, ArrowUpRight, CheckCircle2, Clock, AlertCircle, DollarSign, X } from 'lucide-vue-next'

const searchQuery = ref('')
const selectedMethod = ref('all')

const payments = ref([
  { id: 'PAY-8921', bookingId: 'BK-1029', customer: 'Nguyễn Văn An', amount: '220.000đ', method: 'VietQR Pro', time: '31/10/2026 18:02', status: 'Thành công', bankRef: 'MBB-8491823' },
  { id: 'PAY-8922', bookingId: 'BK-1030', customer: 'Trần Thị Bích', amount: '180.000đ', method: 'Ví MoMo', time: '31/10/2026 19:15', status: 'Thành công', bankRef: 'MOMO-910248' },
  { id: 'PAY-8923', bookingId: 'BK-1031', customer: 'Lê Hoàng Nam', amount: '450.000đ', method: 'Tiền mặt', time: '31/10/2026 16:55', status: 'Thành công', bankRef: 'CASH-POS-01' },
  { id: 'PAY-8924', bookingId: 'BK-1032', customer: 'Phạm Minh Đức', amount: '200.000đ', method: 'VietQR Pro', time: '31/10/2026 19:50', status: 'Đang xử lý', bankRef: 'VCB-Pending' },
  { id: 'PAY-8925', bookingId: 'BK-1033', customer: 'Hoàng Anh Tuấn', amount: '350.000đ', method: 'VNPay QR', time: '30/10/2026 21:10', status: 'Thành công', bankRef: 'VNPAY-38190' },
  { id: 'PAY-8926', bookingId: 'BK-1034', customer: 'Đỗ Thùy Trang', amount: '240.000đ', method: 'VietQR Pro', time: '29/10/2026 17:30', status: 'Đã hoàn tiền', bankRef: 'REFUND-8201' },
])

const filteredPayments = computed(() => {
  return payments.value.filter(p => {
    const q = searchQuery.value.trim().toLowerCase()
    const matchesQuery = !q ||
      p.id.toLowerCase().includes(q) ||
      p.bookingId.toLowerCase().includes(q) ||
      p.customer.toLowerCase().includes(q)

    const matchesMethod = selectedMethod.value === 'all' || p.method.includes(selectedMethod.value)

    return matchesQuery && matchesMethod
  })
})

const statusClass = (status) => {
  if (status === 'Thành công') return 'status-success'
  if (status === 'Đang xử lý') return 'status-pending'
  return 'status-refund'
}
</script>

<template>
  <div class="payment-view">
    <div class="summary-cards">
      <div class="card glass-panel">
        <span class="label">Tổng thu ngân hôm nay</span>
        <h3>4.850.000đ</h3>
        <span class="sub text-success">+18% so với hôm qua</span>
      </div>
      <div class="card glass-panel">
        <span class="label">Thanh toán trực tuyến (VietQR / MoMo)</span>
        <h3>3.620.000đ</h3>
        <span class="sub text-muted">74.6% tổng giao dịch</span>
      </div>
      <div class="card glass-panel">
        <span class="label">Tiền mặt tại quầy</span>
        <h3>1.230.000đ</h3>
        <span class="sub text-muted">25.4% tổng giao dịch</span>
      </div>
    </div>

    <div class="top-bar glass-panel">
      <div class="search-box">
        <Search :size="18" class="icon" />
        <input v-model="searchQuery" type="text" placeholder="Tìm theo mã PAY, mã đơn BK, tên khách..." />
        <button v-if="searchQuery" @click="searchQuery = ''" class="clear-btn"><X :size="16" /></button>
      </div>

      <div class="filter-tabs">
        <button :class="['tab-btn', { active: selectedMethod === 'all' }]" @click="selectedMethod = 'all'">Tất cả</button>
        <button :class="['tab-btn', { active: selectedMethod === 'VietQR' }]" @click="selectedMethod = 'VietQR'">VietQR Pro</button>
        <button :class="['tab-btn', { active: selectedMethod === 'MoMo' }]" @click="selectedMethod = 'MoMo'">Ví MoMo</button>
        <button :class="['tab-btn', { active: selectedMethod === 'Tiền mặt' }]" @click="selectedMethod = 'Tiền mặt'">Tiền Mặt</button>
      </div>
    </div>

    <div class="table-container glass-panel">
      <table class="data-table">
        <thead>
          <tr>
            <th>Mã Giao Dịch</th>
            <th>Mã Đơn Sân</th>
            <th>Khách Hàng</th>
            <th>Số Tiền</th>
            <th>Phương Thức</th>
            <th>Thời Gian</th>
            <th>Mã Tham Chiếu</th>
            <th>Trạng Thái</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="p in filteredPayments" :key="p.id">
            <td><strong class="pay-id">{{ p.id }}</strong></td>
            <td><span class="bk-id">#{{ p.bookingId }}</span></td>
            <td>{{ p.customer }}</td>
            <td><strong class="text-success">{{ p.amount }}</strong></td>
            <td><span class="method-badge">{{ p.method }}</span></td>
            <td><span class="time-text">{{ p.time }}</span></td>
            <td><code class="ref-code">{{ p.bankRef }}</code></td>
            <td>
              <span class="status-pill" :class="statusClass(p.status)">
                {{ p.status }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.payment-view {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.summary-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.25rem;
}

.summary-cards .card {
  padding: 1.25rem 1.5rem;
}

.summary-cards .label {
  font-size: 0.85rem;
  color: var(--text-muted);
}

.summary-cards h3 {
  font-size: 1.5rem;
  margin: 6px 0 4px;
}

.summary-cards .sub {
  font-size: 0.8rem;
}

.text-success { color: #10b981; }

.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.search-box {
  display: flex;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 0.55rem 1rem;
  width: 320px;
}

.search-box .icon { color: var(--text-muted); margin-right: 0.5rem; }
.search-box input { background: none; border: none; color: var(--text-main); outline: none; width: 100%; font-size: 0.9rem; }
.clear-btn { background: none; border: none; color: var(--text-muted); cursor: pointer; }

.filter-tabs {
  display: flex;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border-color);
  padding: 3px;
  border-radius: 10px;
  gap: 4px;
}

.tab-btn {
  padding: 6px 14px;
  border-radius: 8px;
  color: var(--text-muted);
  font-size: 0.85rem;
  transition: var(--transition-fast);
}

.tab-btn.active { background: var(--primary-color); color: #fff; font-weight: 600; }

.table-container { overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; }
.data-table th { background: rgba(0,0,0,0.25); color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; padding: 1rem 1.25rem; text-align: left; border-bottom: 1px solid var(--border-color); }
.data-table td { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border-color); font-size: 0.9rem; }
.data-table tr:hover { background: rgba(255,255,255,0.02); }

.pay-id { color: #818cf8; font-family: monospace; }
.bk-id { color: var(--text-muted); font-size: 0.85rem; }
.method-badge { background: rgba(255, 255, 255, 0.05); padding: 3px 8px; border-radius: 6px; font-size: 0.8rem; }
.time-text { font-size: 0.85rem; color: var(--text-muted); }
.ref-code { font-size: 0.8rem; color: #cbd5e1; background: rgba(0, 0, 0, 0.4); padding: 2px 6px; border-radius: 4px; }

.status-pill { display: inline-flex; padding: 3px 10px; border-radius: 12px; font-size: 0.8rem; font-weight: 500; }
.status-success { background: rgba(16, 185, 129, 0.15); color: #34d399; }
.status-pending { background: rgba(245, 158, 11, 0.15); color: #fbbf24; }
.status-refund { background: rgba(239, 68, 68, 0.15); color: #f87171; }
</style>
