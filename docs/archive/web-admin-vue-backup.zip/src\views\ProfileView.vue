<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const activeTab = ref('overview') // 'overview' | 'links'

const profile = ref({
  name: 'Đinh Ngọc Huy',
  email: 'dinhngochuymmt@gmail.com',
  phone: '0396392904',
  birthYear: '2026',
  gender: 'Khác',
  height: 0,
  weight: 0,
  specialNotes: '',
  favoriteLocations: [
    'TP Hà Nội: Phường Định Công',
    'Phường Hoàng Mai',
    'Phường Vĩnh Hưng',
    'Phường Đống Đa',
    'Phường Yên Hòa',
    'Phường Láng',
    'Phường Hoàng Liệt',
    'Phường Lĩnh Nam',
    'Phường Yên Sở',
    'Phường Phương Liệt',
    'Phường Khương Đình',
    'Phường Thanh Xuân'
  ],
  sports: [
    { name: 'Cầu lông', level: 'TB' }
  ],
  goals: 'Tìm đội & bạn chơi , Tìm thành viên'
})

const goBack = () => {
  if (window.history.length > 1) {
    router.back()
  } else {
    router.push('/')
  }
}
</script>

<template>
  <div class="profile-page">
    <div class="profile-container">

      <!-- ===== COVER & HEADER ===== -->
      <div class="cover-banner">
        <!-- Top navigation actions on banner -->
        <div class="banner-nav">
          <button @click="goBack" class="circle-btn back-btn" title="Quay lại">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M15 18l-6-6 6-6"/>
            </svg>
          </button>
          <button class="circle-btn camera-btn" title="Đổi ảnh bìa">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
          </button>
        </div>

        <!-- Sport field pattern overlay -->
        <div class="pitch-pattern">
          <div class="pitch-center-circle"></div>
          <div class="pitch-center-line"></div>
        </div>

        <!-- User Card Overlapping Banner -->
        <div class="user-card-float">
          <div class="card-main-row">
            <!-- Avatar with badminton badge -->
            <div class="avatar-box">
              <div class="avatar-circle">
                <!-- Shuttlecock icon avatar -->
                <svg viewBox="0 0 64 64" class="avatar-svg">
                  <!-- Badminton shuttlecock graphic inside circle -->
                  <circle cx="32" cy="32" r="32" fill="#15803d"/>
                  <g transform="translate(14, 12)">
                    <path d="M7 6 Q12 18 18 26 Q24 18 29 6 Q24 4 18 3 Q12 4 7 6 Z" fill="rgba(255,255,255,0.3)" stroke="#ffffff" stroke-width="1.8"/>
                    <line x1="18" y1="26" x2="8" y2="6" stroke="#ffffff" stroke-width="1.8"/>
                    <line x1="18" y1="26" x2="13" y2="4" stroke="#ffffff" stroke-width="1.8"/>
                    <line x1="18" y1="26" x2="18" y2="3" stroke="#ffffff" stroke-width="1.8"/>
                    <line x1="18" y1="26" x2="23" y2="4" stroke="#ffffff" stroke-width="1.8"/>
                    <line x1="18" y1="26" x2="28" y2="6" stroke="#ffffff" stroke-width="1.8"/>
                    <path d="M12 26 Q12 33 18 35 Q24 33 24 26 Z" fill="#ffffff"/>
                  </g>
                </svg>
                <!-- Mini camera badge on avatar -->
                <div class="avatar-badge-cam">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                    <circle cx="12" cy="13" r="4"/>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Name and email pill -->
            <div class="name-block">
              <div class="name-row">
                <h1 class="user-display-name">{{ profile.name }}</h1>
                <button class="edit-name-btn" title="Chỉnh sửa tên">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                </button>
              </div>

              <div class="email-pill">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect width="20" height="16" x="2" y="4" rx="2"/>
                  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                </svg>
                <span>{{ profile.email }}</span>
              </div>
            </div>
          </div>

          <!-- Bottom stats row: Phone, Birth year, Gender -->
          <div class="card-details-row">
            <div class="detail-col">
              <div class="detail-label">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                <span>Điện thoại</span>
              </div>
              <div class="detail-value">{{ profile.phone }}</div>
            </div>

            <div class="detail-col">
              <div class="detail-label">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                  <line x1="16" y1="2" x2="16" y2="6"/>
                  <line x1="8" y1="2" x2="8" y2="6"/>
                  <line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
                <span>Năm sinh</span>
              </div>
              <div class="detail-value">{{ profile.birthYear }}</div>
            </div>

            <div class="detail-col">
              <div class="detail-label">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="4"/>
                  <path d="M12 2v2"/>
                  <path d="M12 20v2"/>
                  <path d="m4.93 4.93 1.41 1.41"/>
                  <path d="m17.66 17.66 1.41 1.41"/>
                  <path d="M2 12h2"/>
                  <path d="M20 12h2"/>
                </svg>
                <span>Giới tính</span>
              </div>
              <div class="detail-value">{{ profile.gender }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- ===== MAIN TABS ===== -->
      <div class="tab-switch-container">
        <button
          class="tab-pill-btn"
          :class="{ active: activeTab === 'overview' }"
          @click="activeTab = 'overview'"
        >
          Tổng quan
        </button>
        <button
          class="tab-pill-btn"
          :class="{ active: activeTab === 'links' }"
          @click="activeTab = 'links'"
        >
          Liên kết
        </button>
      </div>

      <!-- ===== TAB CONTENT: TỔNG QUAN ===== -->
      <div v-if="activeTab === 'overview'" class="tab-body">
        
        <!-- SECTION 1: THÔNG TIN THỂ CHẤT -->
        <section class="info-section">
          <div class="section-header">
            <h2 class="section-title">Thông tin thể chất</h2>
            <button class="section-edit-btn" title="Chỉnh sửa thể chất">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
          </div>

          <!-- Physical stats rounded box -->
          <div class="stats-box">
            <div class="stat-item">
              <div class="stat-label">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21.3 8.7 8.7 21.3c-1 1-2.5 1-3.4 0l-2.6-2.6c-1-1-1-2.5 0-3.4L15.3 2.7c1-1 2.5-1 3.4 0l2.6 2.6c1 1 1 2.4 0 3.4Z"/>
                  <path d="m14.5 3.5 6 6"/>
                  <path d="m7.5 10.5 2 2"/>
                  <path d="m10.5 13.5 2 2"/>
                  <path d="m4.5 16.5 2 2"/>
                </svg>
                <span>Chiều cao (cm)</span>
              </div>
              <div class="stat-number">{{ profile.height }} cm</div>
            </div>

            <div class="stat-divider"></div>

            <div class="stat-item">
              <div class="stat-label">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="9"/>
                  <path d="M12 7v5l3 3"/>
                </svg>
                <span>Cân nặng (kg)</span>
              </div>
              <div class="stat-number">{{ profile.weight }} kg</div>
            </div>
          </div>

          <!-- Special notes -->
          <div class="special-notes-row">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            <span class="notes-label">Ghi chú đặc biệt</span>
          </div>
        </section>

        <!-- SECTION 2: CÁ NHÂN HOÁ -->
        <section class="info-section">
          <div class="section-header">
            <h2 class="section-title">Cá nhân hoá</h2>
            <button class="section-edit-btn" title="Chỉnh sửa cá nhân hoá">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
          </div>

          <div class="personal-details-card">
            <!-- Vị trí yêu thích -->
            <div class="detail-group">
              <div class="detail-group-header">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                <span class="group-title">Vị trí yêu thích</span>
              </div>
              <p class="locations-text">
                {{ profile.favoriteLocations.join(' , ') }}
              </p>
            </div>

            <!-- Môn thể thao và trình độ -->
            <div class="detail-group">
              <div class="detail-group-header">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/>
                  <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/>
                  <path d="M4 22h16"/>
                  <path d="M10 14.66V17c0 .55-.45 1-1 1H7c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1h10c.55 0 1-.45 1-1v-1c0-.55-.45-1-1-1h-2c-.55 0-1-.45-1-1v-2.34"/>
                  <path d="M4.5 4h15v5a7.5 7.5 0 0 1-15 0V4z"/>
                </svg>
                <span class="group-title">Môn thể thao và trình độ</span>
              </div>
              <div class="sports-tags-row">
                <div v-for="sp in profile.sports" :key="sp.name" class="sport-badge">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2.5">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
                    <path d="M2 12h20"/>
                  </svg>
                  <span class="sport-name">{{ sp.name }}</span>
                  <span class="sport-level">{{ sp.level }}</span>
                </div>
              </div>
            </div>

            <!-- Mục tiêu -->
            <div class="detail-group">
              <div class="detail-group-header">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="10"/>
                  <circle cx="12" cy="12" r="6"/>
                  <circle cx="12" cy="12" r="2"/>
                </svg>
                <span class="group-title">Mục tiêu</span>
              </div>
              <p class="goals-text">
                {{ profile.goals }}
              </p>
            </div>
          </div>
        </section>

      </div>

      <!-- ===== TAB CONTENT: LIÊN KẾT ===== -->
      <div v-else class="tab-body">
        <section class="info-section">
          <div class="section-header">
            <h2 class="section-title">Tài khoản liên kết</h2>
          </div>
          <div class="personal-details-card links-card">
            <div class="link-item">
              <div class="link-info">
                <span class="link-icon">🌐</span>
                <div>
                  <div class="link-name">Google</div>
                  <div class="link-sub">{{ profile.email }}</div>
                </div>
              </div>
              <span class="badge-connected">Đã liên kết</span>
            </div>
            <div class="link-item">
              <div class="link-info">
                <span class="link-icon">📘</span>
                <div>
                  <div class="link-name">Facebook</div>
                  <div class="link-sub">Chưa kết nối</div>
                </div>
              </div>
              <button class="btn-connect">Kết nối</button>
            </div>
          </div>
        </section>
      </div>

    </div>
  </div>
</template>

<style scoped>
/* Page container */
.profile-page {
  min-height: 100vh;
  background-color: #f8faf8;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  color: #1f2937;
  padding-bottom: 50px;
}

.profile-container {
  max-width: 1100px;
  margin: 0 auto;
}

/* COVER BANNER */
.cover-banner {
  position: relative;
  height: 190px;
  background: linear-gradient(135deg, #15803d 0%, #16a34a 50%, #22c55e 100%);
  overflow: visible;
  margin-bottom: 95px;
}

/* Pitch pattern on cover */
.pitch-pattern {
  position: absolute;
  inset: 0;
  opacity: 0.22;
  pointer-events: none;
  overflow: hidden;
}

.pitch-center-circle {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 240px;
  height: 240px;
  border: 3px solid #ffffff;
  border-radius: 50%;
  transform: translate(-50%, -50%);
}

.pitch-center-line {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 50%;
  width: 3px;
  background: #ffffff;
  transform: translateX(-50%);
}

/* Banner Nav Buttons */
.banner-nav {
  position: absolute;
  top: 14px;
  left: 18px;
  right: 18px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  z-index: 10;
}

.circle-btn {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.45);
  color: #ffffff;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  backdrop-filter: blur(6px);
}

.circle-btn:hover {
  background: rgba(0, 0, 0, 0.65);
  transform: scale(1.06);
}

/* FLOATING USER CARD */
.user-card-float {
  position: absolute;
  bottom: -76px;
  left: 16px;
  right: 16px;
  background: #ffffff;
  border-radius: 18px;
  padding: 16px 24px 18px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08), 0 1px 4px rgba(0, 0, 0, 0.04);
  border: 1px solid #eef2ee;
  z-index: 5;
}

.card-main-row {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 16px;
}

/* Avatar */
.avatar-box {
  position: relative;
  flex-shrink: 0;
}

.avatar-circle {
  position: relative;
  width: 68px;
  height: 68px;
  border-radius: 50%;
  background: #15803d;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(21, 128, 61, 0.35);
  border: 3px solid #ffffff;
}

.avatar-svg {
  width: 100%;
  height: 100%;
  border-radius: 50%;
}

.avatar-badge-cam {
  position: absolute;
  bottom: 0;
  right: -2px;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: #374151;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid #ffffff;
  cursor: pointer;
}

/* Name Block */
.name-block {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.name-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.user-display-name {
  font-size: 1.35rem;
  font-weight: 700;
  color: #111827;
  margin: 0;
  letter-spacing: -0.01em;
}

.edit-name-btn {
  background: none;
  border: none;
  color: #6b7280;
  cursor: pointer;
  padding: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: color 0.15s;
}

.edit-name-btn:hover {
  color: #16a34a;
}

.email-pill {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  background: #f3f4f6;
  border: 1px solid #e5e7eb;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 0.8rem;
  color: #4b5563;
  width: fit-content;
}

/* Bottom 3 Details in User Card */
.card-details-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  padding-top: 12px;
  border-top: 1px solid #f3f4f6;
}

.detail-col {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 3px;
}

.detail-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.82rem;
  color: #6b7280;
}

.detail-label svg {
  color: #9ca3af;
}

.detail-value {
  font-size: 0.95rem;
  font-weight: 700;
  color: #1f2937;
}

/* TAB SWITCHER */
.tab-switch-container {
  display: flex;
  margin: 0 16px 20px;
  background: #15803d;
  border-radius: 12px;
  padding: 4px;
  gap: 4px;
}

.tab-pill-btn {
  flex: 1;
  padding: 11px 0;
  border-radius: 9px;
  border: none;
  font-size: 0.95rem;
  font-weight: 600;
  cursor: pointer;
  background: transparent;
  color: #ffffff;
  transition: all 0.2s ease;
  text-align: center;
}

.tab-pill-btn.active {
  background: #ffffff;
  color: #15803d;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

/* TAB BODY SECTIONS */
.tab-body {
  margin: 0 16px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.info-section {
  background: #ffffff;
  border-radius: 16px;
  padding: 18px 20px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.04);
  border: 1px solid #f0f3f0;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 14px;
}

.section-title {
  font-size: 1.05rem;
  font-weight: 700;
  color: #15803d;
  margin: 0;
}

.section-edit-btn {
  background: none;
  border: none;
  color: #15803d;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  transition: background-color 0.15s;
}

.section-edit-btn:hover {
  background-color: #f0fdf4;
}

/* STATS BOX */
.stats-box {
  display: flex;
  align-items: center;
  background: #fafbfa;
  border: 1px solid #e5e9e5;
  border-radius: 12px;
  padding: 14px 20px;
  margin-bottom: 16px;
}

.stat-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 4px;
}

.stat-divider {
  width: 1px;
  height: 38px;
  background-color: #e5e9e5;
}

.stat-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.8rem;
  color: #6b7280;
}

.stat-label svg {
  color: #9ca3af;
}

.stat-number {
  font-size: 1.05rem;
  font-weight: 700;
  color: #111827;
}

.special-notes-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.9rem;
  font-weight: 600;
  color: #111827;
}

.special-notes-row svg {
  color: #4b5563;
}

/* PERSONAL DETAILS */
.personal-details-card {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.detail-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.detail-group-header {
  display: flex;
  align-items: center;
  gap: 7px;
  color: #1f2937;
  font-size: 0.92rem;
  font-weight: 700;
}

.detail-group-header svg {
  color: #4b5563;
}

.locations-text {
  margin: 0;
  font-size: 0.86rem;
  line-height: 1.6;
  color: #4b5563;
  padding-left: 23px;
}

.sports-tags-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding-left: 23px;
}

.sport-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  padding: 4px 10px;
  border-radius: 20px;
}

.sport-name {
  font-size: 0.82rem;
  font-weight: 600;
  color: #166534;
}

.sport-level {
  background: #16a34a;
  color: #ffffff;
  font-size: 0.7rem;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 10px;
}

.goals-text {
  margin: 0;
  font-size: 0.86rem;
  color: #4b5563;
  padding-left: 23px;
}

/* LINKS TAB */
.links-card {
  gap: 12px;
}

.link-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 14px;
  background: #fafbfa;
  border: 1px solid #e5e9e5;
  border-radius: 10px;
}

.link-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.link-icon {
  font-size: 1.4rem;
}

.link-name {
  font-weight: 600;
  font-size: 0.92rem;
  color: #1f2937;
}

.link-sub {
  font-size: 0.8rem;
  color: #6b7280;
}

.badge-connected {
  font-size: 0.78rem;
  color: #16a34a;
  background: #dcfce7;
  padding: 3px 10px;
  border-radius: 12px;
  font-weight: 600;
}

.btn-connect {
  background: #15803d;
  color: #ffffff;
  border: none;
  padding: 5px 14px;
  border-radius: 8px;
  font-size: 0.82rem;
  font-weight: 600;
  cursor: pointer;
}

@media (max-width: 640px) {
  .user-card-float {
    padding: 14px 16px;
    bottom: -90px;
  }
  .cover-banner {
    margin-bottom: 110px;
  }
  .card-details-row {
    grid-template-columns: 1fr;
    gap: 8px;
  }
}
</style>
