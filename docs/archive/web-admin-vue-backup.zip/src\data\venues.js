// Bộ sưu tập ảnh thực tế sân thể thao chuẩn phong cách ứng dụng ALOBO Đặt Lịch
// Bao gồm: Ảnh sân bóng có thảm sơn xanh/tím, vạch kẻ chuẩn thi đấu, mái che cao, lưới căng, đèn LED và khu vực nghỉ ngơi.

export const sportCourtImages = {
  pickleball: [
    'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?w=600&h=320&fit=crop&q=80', // Sân ngoài trời xanh lá viền xanh dương
    'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600&h=320&fit=crop&q=80', // Mặt sân asphalt cao cấp chuẩn thi đấu
    'https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=600&h=320&fit=crop&q=80', // Sân trong nhà có mái che cao
    'https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=600&h=320&fit=crop&q=80', // Cụm nhiều sân thi đấu đôi
    'https://images.unsplash.com/photo-1545809074-59472b3f5ecc?w=600&h=320&fit=crop&q=80', // Sân thảm xanh ngọc chuyên nghiệp
    'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600&h=320&fit=crop&q=80', // Khu tập luyện hiện đại
    'https://images.unsplash.com/photo-1519766304817-4f37bda74a29?w=600&h=320&fit=crop&q=80', // Cụm sân có đèn LED ban đêm
    'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=320&fit=crop&q=80', // Sân ven hồ thoáng mát
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=320&fit=crop&q=80', // Sân thể thao đa dụng
    'https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?w=600&h=320&fit=crop&q=80', // Không gian nhà thi đấu
  ],
  badminton: [
    'https://images.unsplash.com/photo-1521537634581-0dced2fee2ef?w=600&h=320&fit=crop&q=80', // Thảm cầu lông xanh lá Yonex chuẩn thi đấu
    'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=600&h=320&fit=crop&q=80', // Nhà thi đấu cầu lông sàn gỗ bóng cao cấp
    'https://images.unsplash.com/photo-1613918108466-292b78a8ef95?w=600&h=320&fit=crop&q=80', // Quả cầu lông và lưới căng phẳng
    'https://images.unsplash.com/photo-1599474924187-334a4ae5bd3c?w=600&h=320&fit=crop&q=80', // Cụm nhiều sân cầu lông trong nhà trần cao
    'https://images.unsplash.com/photo-1544698310-74ea9d1c8258?w=600&h=320&fit=crop&q=80', // Vợt và cầu lông trên thảm vinyl
    'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=600&h=320&fit=crop&q=80', // Đèn cao áp chống chói
    'https://images.unsplash.com/photo-1575361204480-aadea25e6e68?w=600&h=320&fit=crop&q=80', // Cận cảnh vạch sân thi đấu
  ],
  football: [
    'https://images.unsplash.com/photo-1529900241451-93b9423c9604?w=600&h=320&fit=crop&q=80', // Sân bóng cỏ nhân tạo FIFA xanh mướt ban ngày
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=320&fit=crop&q=80', // Sân bóng đá mini 7 người
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=320&fit=crop&q=80', // Đèn LED chiếu sáng sân cỏ đêm
    'https://images.unsplash.com/photo-1551958219-acbc608c6377?w=600&h=320&fit=crop&q=80', // Cầu môn và khung thành lưới trắng
  ],
  basketball: [
    'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=600&h=320&fit=crop&q=80', // Sân bóng rổ sàn gỗ bóng loáng trong nhà
    'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=600&h=320&fit=crop&q=80', // Bảng rổ kính cường lực và vạch kẻ 3 điểm
    'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?w=600&h=320&fit=crop&q=80', // Sân bóng rổ ngoài trời mặt sơn màu
  ],
  tennis: [
    'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600&h=320&fit=crop&q=80', // Sân tennis cứng US Open chuẩn quốc tế
    'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?w=600&h=320&fit=crop&q=80', // Sân tennis đất nện hoặc thảm xanh
    'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=320&fit=crop&q=80', // Lưới tennis chuyên nghiệp
  ],
  multi: [
    'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=600&h=320&fit=crop&q=80', // Nhà thi đấu thể thao đa năng
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=320&fit=crop&q=80', // Tổ hợp thể thao phức hợp
  ]
}

// Danh sách cụm sân thể thao thực tế tại TP. Hà Nội (Alobo / SportAI Data)
const realVenues = [
  // ==========================================
  // QUẬN ĐỐNG ĐA
  // ==========================================
  {
    id: 1,
    name: 'Pickleball Cổng B Ga Hà Nội',
    type: 'pickleball',
    district: 'Đống Đa',
    distance: '271.5m',
    address: '1 P. Trần Quý Cáp, Văn Chương, Đống Đa, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Đơn ngày', 'Sự kiện'],
    rating: 4.9,
    price: '120k - 220k/h',
    lat: 21.0245,
    lng: 105.8412,
    image: sportCourtImages.pickleball[0],
    logo: 'https://ui-avatars.com/api/?name=PB&background=2563eb&color=fff&size=40&bold=true',
  },
  {
    id: 2,
    name: 'Phúc Long Pickleball & Badminton 460 Trần Quý Cáp',
    type: 'pickleball',
    district: 'Đống Đa',
    distance: '288.4m',
    address: '460 P. Trần Quý Cáp, Văn Miếu, Đống Đa, Hà Nội',
    hours: '00:00 – 24:00',
    tags: ['Mở 24/7', 'Thảm Yonex'],
    rating: 4.8,
    price: '80k - 200k/h',
    lat: 21.0260,
    lng: 105.8385,
    image: sportCourtImages.badminton[0],
    logo: 'https://ui-avatars.com/api/?name=PL&background=16a34a&color=fff&size=40&bold=true',
  },
  {
    id: 3,
    name: 'City Pickleball Chùa Bộc',
    type: 'pickleball',
    district: 'Đống Đa',
    distance: '1.4km',
    address: 'Số 1 ngõ 165 Chùa Bộc, Trung Tự, Đống Đa, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Trong nhà', 'Máy lạnh'],
    rating: 4.7,
    price: '140k - 240k/h',
    lat: 21.0082,
    lng: 105.8285,
    image: sportCourtImages.pickleball[2],
    logo: 'https://ui-avatars.com/api/?name=CP&background=0284c7&color=fff&size=40&bold=true',
  },
  {
    id: 4,
    name: 'Sân Cầu Lông Chùa Láng',
    type: 'badminton',
    district: 'Đống Đa',
    distance: '2.9km',
    address: '159 Chùa Láng, Láng Thượng, Đống Đa, Hà Nội',
    hours: '05:30 – 23:00',
    tags: ['Bãi ô tô rộng', 'Ánh sáng chuẩn'],
    rating: 4.7,
    price: '95k - 160k/h',
    lat: 21.0232,
    lng: 105.8035,
    image: sportCourtImages.badminton[3],
    logo: 'https://ui-avatars.com/api/?name=CL&background=16a34a&color=fff&size=40&bold=true',
  },
  {
    id: 5,
    name: 'Sân Bóng Đá Đại Học Thủy Lợi',
    type: 'football',
    district: 'Đống Đa',
    distance: '1.8km',
    address: '175 Tây Sơn, Trung Liệt, Đống Đa, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Cỏ FIFA', 'Sân 7 người'],
    rating: 4.8,
    price: '300k - 600k/trận',
    lat: 21.0076,
    lng: 105.8242,
    image: sportCourtImages.football[0],
    logo: 'https://ui-avatars.com/api/?name=TL&background=16a34a&color=fff&size=40&bold=true',
  },
  {
    id: 6,
    name: 'CLB Pickleball Ga Hà Nội (Lê Duẩn)',
    type: 'pickleball',
    district: 'Đống Đa',
    distance: '600m',
    address: '120 Lê Duẩn, Văn Miếu, Đống Đa, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Mặt sân Pro', 'Giao lưu'],
    rating: 4.6,
    price: '130k - 210k/h',
    lat: 21.0255,
    lng: 105.8425,
    image: sportCourtImages.pickleball[1],
    logo: 'https://ui-avatars.com/api/?name=GH&background=dc2626&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN BA ĐÌNH
  // ==========================================
  {
    id: 7,
    name: 'Sân Cầu Lông THCS Giảng Võ 2',
    type: 'badminton',
    district: 'Ba Đình',
    distance: '2.1km',
    address: '105 Ngõ 12 Núi Trúc, Giảng Võ, Ba Đình, Hà Nội',
    hours: '05:30 – 22:30',
    tags: ['Sàn gỗ thi đấu', 'Ánh sáng tốt'],
    rating: 4.6,
    price: '90k - 150k/h',
    lat: 21.0298,
    lng: 105.8236,
    image: sportCourtImages.badminton[1],
    logo: 'https://ui-avatars.com/api/?name=GV&background=0d9488&color=fff&size=40&bold=true',
  },
  {
    id: 8,
    name: 'Cung Thể Thao Quần Ngựa (Tennis & Pickleball)',
    type: 'tennis',
    district: 'Ba Đình',
    distance: '3.4km',
    address: 'Văn Cao, Liễu Giai, Ba Đình, Hà Nội',
    hours: '05:30 – 22:30',
    tags: ['Sân cứng quốc tế', 'Đèn LED cao'],
    rating: 4.8,
    price: '180k - 300k/h',
    lat: 21.0412,
    lng: 105.8163,
    image: sportCourtImages.tennis[0],
    logo: 'https://ui-avatars.com/api/?name=QN&background=ea580c&color=fff&size=40&bold=true',
  },
  {
    id: 9,
    name: 'Sân Cầu Lông Khách Sạn Khăn Quàng Đỏ',
    type: 'badminton',
    district: 'Ba Đình',
    distance: '2.8km',
    address: '94 Ngõ 189 Hoàng Hoa Thám, Liễu Giai, Ba Đình, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Thảm cao cấp', 'Trần cao'],
    rating: 4.7,
    price: '100k - 160k/h',
    lat: 21.0410,
    lng: 105.8190,
    image: sportCourtImages.badminton[4],
    logo: 'https://ui-avatars.com/api/?name=KQ&background=e11d48&color=fff&size=40&bold=true',
  },
  {
    id: 10,
    name: 'Vạn Phúc Pickleball Club',
    type: 'pickleball',
    district: 'Ba Đình',
    distance: '1.9km',
    address: 'Khu Ngoại Giao Đoàn Vạn Phúc, Liễu Giai, Ba Đình, Hà Nội',
    hours: '06:00 – 22:00',
    tags: ['Khuôn viên VIP', 'Sân mới'],
    rating: 4.9,
    price: '150k - 260k/h',
    lat: 21.0335,
    lng: 105.8175,
    image: sportCourtImages.pickleball[4],
    logo: 'https://ui-avatars.com/api/?name=VP&background=7c3aed&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN TÂY HỒ
  // ==========================================
  {
    id: 11,
    name: 'Pickleball Garden Tứ Liên',
    type: 'pickleball',
    district: 'Tây Hồ',
    distance: '3.2km',
    address: '96 Tứ Liên, Phường Hồng Hà, Tây Hồ, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Mái che di động', 'Máy bắn bóng'],
    rating: 4.9,
    price: '150k - 250k/h',
    lat: 21.0645,
    lng: 105.8450,
    image: sportCourtImages.pickleball[3],
    logo: 'https://ui-avatars.com/api/?name=PG&background=059669&color=fff&size=40&bold=true',
  },
  {
    id: 12,
    name: 'The Mezzo Pickleball Hồ Tây',
    type: 'pickleball',
    district: 'Tây Hồ',
    distance: '3.9km',
    address: 'Ngõ 310 Nghi Tàm, Yên Phụ, Tây Hồ, Hà Nội',
    hours: '06:00 – 23:00',
    tags: ['View hồ Tây', 'Cafe & Bar'],
    rating: 5.0,
    price: '160k - 280k/h',
    lat: 21.0550,
    lng: 105.8360,
    image: sportCourtImages.pickleball[7],
    logo: 'https://ui-avatars.com/api/?name=TM&background=4f46e5&color=fff&size=40&bold=true',
  },
  {
    id: 13,
    name: 'Sân Cầu Lông Tây Hồ Lạc Long Quân',
    type: 'badminton',
    district: 'Tây Hồ',
    distance: '4.8km',
    address: '101 Xuân La, Xuân Tảo, Tây Hồ, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['6 sân thảm xanh', 'Chỗ để xe rộng'],
    rating: 4.7,
    price: '90k - 150k/h',
    lat: 21.0580,
    lng: 105.8080,
    image: sportCourtImages.badminton[2],
    logo: 'https://ui-avatars.com/api/?name=TH&background=0284c7&color=fff&size=40&bold=true',
  },
  {
    id: 14,
    name: 'Sân Bóng Đá Trung Tâm VHTT Tây Hồ',
    type: 'football',
    district: 'Tây Hồ',
    distance: '4.5km',
    address: '101 Xuân La, Tây Hồ, Hà Nội',
    hours: '05:30 – 23:00',
    tags: ['Cỏ mềm mượt', 'Đèn cao áp'],
    rating: 4.6,
    price: '350k - 650k/trận',
    lat: 21.0595,
    lng: 105.8095,
    image: sportCourtImages.football[2],
    logo: 'https://ui-avatars.com/api/?name=TH&background=16a34a&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN CẦU GIẤY
  // ==========================================
  {
    id: 15,
    name: 'Sân Cầu Lông Sport YH (Yên Hòa)',
    type: 'badminton',
    district: 'Cầu Giấy',
    distance: '4.2km',
    address: 'Số 9 Hạ Yên Quyết, Yên Hòa, Cầu Giấy, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['6 sân thảm', 'Trần cao 10m'],
    rating: 4.8,
    price: '90k - 150k/h',
    lat: 21.0180,
    lng: 105.7940,
    image: sportCourtImages.badminton[5],
    logo: 'https://ui-avatars.com/api/?name=YH&background=0284c7&color=fff&size=40&bold=true',
  },
  {
    id: 16,
    name: 'Nhà Thi Đấu Đa Năng Cầu Giấy',
    type: 'multi',
    district: 'Cầu Giấy',
    distance: '4.2km',
    address: '35 Trần Quý Kiên, Dịch Vọng, Cầu Giấy, Hà Nội',
    hours: '06:00 – 22:00',
    tags: ['Bóng rổ', 'Cầu lông', 'Bóng bàn'],
    rating: 4.6,
    price: '100k - 200k/h',
    lat: 21.0345,
    lng: 105.7925,
    image: sportCourtImages.multi[0],
    logo: 'https://ui-avatars.com/api/?name=CG&background=be123c&color=fff&size=40&bold=true',
  },
  {
    id: 17,
    name: 'CLB Pickleball Cầu Giấy Duy Tân',
    type: 'pickleball',
    district: 'Cầu Giấy',
    distance: '4.7km',
    address: 'Phố Duy Tân, Dịch Vọng Hậu, Cầu Giấy, Hà Nội',
    hours: '05:30 – 23:00',
    tags: ['Cụm 6 sân', 'Mặt sân thi đấu'],
    rating: 4.8,
    price: '130k - 220k/h',
    lat: 21.0305,
    lng: 105.7830,
    image: sportCourtImages.pickleball[5],
    logo: 'https://ui-avatars.com/api/?name=DT&background=2563eb&color=fff&size=40&bold=true',
  },
  {
    id: 18,
    name: 'Sân Bóng Đá Trung Kính Hạ',
    type: 'football',
    district: 'Cầu Giấy',
    distance: '4.0km',
    address: 'Ngõ 219 Trung Kính, Yên Hòa, Cầu Giấy, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Sân 7 người', 'Đèn LED siêu sáng'],
    rating: 4.7,
    price: '320k - 580k/trận',
    lat: 21.0150,
    lng: 105.7970,
    image: sportCourtImages.football[1],
    logo: 'https://ui-avatars.com/api/?name=TK&background=16a34a&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN THANH XUÂN
  // ==========================================
  {
    id: 19,
    name: 'Pickleball Student Village (PSV)',
    type: 'pickleball',
    district: 'Thanh Xuân',
    distance: '3.5km',
    address: 'Làng Sinh Viên Hacinco, Nhân Chính, Thanh Xuân, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Cụm 10 sân', 'Mái bạt cao'],
    rating: 4.8,
    price: '120k - 210k/h',
    lat: 21.0020,
    lng: 105.8050,
    image: sportCourtImages.pickleball[2],
    logo: 'https://ui-avatars.com/api/?name=PS&background=7c3aed&color=fff&size=40&bold=true',
  },
  {
    id: 20,
    name: 'CLB Bóng Rổ PK - Không Quân',
    type: 'basketball',
    district: 'Thanh Xuân',
    distance: '2.5km',
    address: 'Đường Trường Chinh, Khương Mai, Thanh Xuân, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Sàn gỗ bóng', 'Vành NBA'],
    rating: 4.9,
    price: '150k - 250k/h',
    lat: 21.0021,
    lng: 105.8315,
    image: sportCourtImages.basketball[0],
    logo: 'https://ui-avatars.com/api/?name=KQ&background=d97706&color=fff&size=40&bold=true',
  },
  {
    id: 21,
    name: 'Sân Cầu Lông Khương Đình',
    type: 'badminton',
    district: 'Thanh Xuân',
    distance: '3.8km',
    address: 'Ngõ 460 Khương Đình, Hạ Đình, Thanh Xuân, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Thảm mới', 'Quạt trần công nghiệp'],
    rating: 4.6,
    price: '85k - 140k/h',
    lat: 20.9885,
    lng: 105.8150,
    image: sportCourtImages.badminton[0],
    logo: 'https://ui-avatars.com/api/?name=KD&background=059669&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN HAI BÀ TRƯNG
  // ==========================================
  {
    id: 22,
    name: 'Ông Mập Pickleball Minh Khai',
    type: 'pickleball',
    district: 'Hai Bà Trưng',
    distance: '2.8km',
    address: '521 Minh Khai, Vĩnh Tuy, Hai Bà Trưng, Hà Nội',
    hours: '05:30 – 23:30',
    tags: ['Trong nhà 2 tầng', 'Căng tin máy lạnh'],
    rating: 4.9,
    price: '130k - 220k/h',
    lat: 20.9995,
    lng: 105.8680,
    image: sportCourtImages.pickleball[1],
    logo: 'https://ui-avatars.com/api/?name=OM&background=ea580c&color=fff&size=40&bold=true',
  },
  {
    id: 23,
    name: 'Sân Cầu Lông Bách Khoa',
    type: 'badminton',
    district: 'Hai Bà Trưng',
    distance: '1.9km',
    address: 'Nhà thi đấu Bách Khoa, Tạ Quang Bửu, Hai Bà Trưng, Hà Nội',
    hours: '06:00 – 22:30',
    tags: ['Sàn thi đấu chuẩn', 'Khán đài'],
    rating: 4.6,
    price: '90k - 140k/h',
    lat: 21.0045,
    lng: 105.8430,
    image: sportCourtImages.badminton[1],
    logo: 'https://ui-avatars.com/api/?name=BK&background=059669&color=fff&size=40&bold=true',
  },
  {
    id: 24,
    name: 'Sân Tennis Bách Khoa',
    type: 'tennis',
    district: 'Hai Bà Trưng',
    distance: '2.2km',
    address: 'Tạ Quang Bửu, Bách Khoa, Hai Bà Trưng, Hà Nội',
    hours: '05:30 – 22:00',
    tags: ['Sân ngoài trời', 'Đèn tốt'],
    rating: 4.7,
    price: '170k - 290k/h',
    lat: 21.0060,
    lng: 105.8480,
    image: sportCourtImages.tennis[1],
    logo: 'https://ui-avatars.com/api/?name=TK&background=0284c7&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN HOÀNG MAI
  // ==========================================
  {
    id: 25,
    name: 'Sân Pickleball Định Công 175',
    type: 'pickleball',
    district: 'Hoàng Mai',
    distance: '4.0km',
    address: '175 Định Công, Hoàng Mai, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['6 sân mái che', 'Sơn cao cấp'],
    rating: 4.8,
    price: '120k - 210k/h',
    lat: 20.9880,
    lng: 105.8350,
    image: sportCourtImages.pickleball[6],
    logo: 'https://ui-avatars.com/api/?name=DC&background=16a34a&color=fff&size=40&bold=true',
  },
  {
    id: 26,
    name: 'Sân Cầu Lông Hoàng Mai Linh Đàm',
    type: 'badminton',
    district: 'Hoàng Mai',
    distance: '5.2km',
    address: 'Bán Đảo Linh Đàm, Hoàng Liệt, Hoàng Mai, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Thảm đạt chuẩn', 'Gần hồ thoáng mát'],
    rating: 4.7,
    price: '85k - 140k/h',
    lat: 20.9705,
    lng: 105.8320,
    image: sportCourtImages.badminton[3],
    logo: 'https://ui-avatars.com/api/?name=LD&background=059669&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN LONG BIÊN
  // ==========================================
  {
    id: 27,
    name: 'Suzy Pickleball Long Biên',
    type: 'pickleball',
    district: 'Long Biên',
    distance: '5.8km',
    address: '26 Đức Giang, Thượng Thanh, Long Biên, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['5 sân asphalt', 'Đệm giảm chấn'],
    rating: 4.9,
    price: '130k - 230k/h',
    lat: 21.0580,
    lng: 105.8920,
    image: sportCourtImages.pickleball[4],
    logo: 'https://ui-avatars.com/api/?name=SZ&background=db2777&color=fff&size=40&bold=true',
  },
  {
    id: 28,
    name: 'Sân Cầu Lông Hùng Hải Sport',
    type: 'badminton',
    district: 'Long Biên',
    distance: '4.8km',
    address: 'Đường Hồng Tiến, Bồ Đề, Long Biên, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Cụm 8 sân', 'Trong nhà mát mẻ'],
    rating: 4.9,
    price: '85k - 150k/h',
    lat: 21.0370,
    lng: 105.8740,
    image: sportCourtImages.badminton[2],
    logo: 'https://ui-avatars.com/api/?name=HH&background=2563eb&color=fff&size=40&bold=true',
  },
  {
    id: 29,
    name: 'Sân Cầu Lông Lệ Mật Long Biên',
    type: 'badminton',
    district: 'Long Biên',
    distance: '5.6km',
    address: 'Làng Lệ Mật, Việt Hưng, Long Biên, Hà Nội',
    hours: '05:30 – 22:30',
    tags: ['Thảm thi đấu', 'Yên tĩnh'],
    rating: 4.6,
    price: '75k - 130k/h',
    lat: 21.0490,
    lng: 105.8950,
    image: sportCourtImages.badminton[5],
    logo: 'https://ui-avatars.com/api/?name=LM&background=10b981&color=fff&size=40&bold=true',
  },

  // ==========================================
  // QUẬN HÀ ĐÔNG & THANH TRÌ
  // ==========================================
  {
    id: 30,
    name: 'TukTuk Pickleball Yên Xá',
    type: 'pickleball',
    district: 'Thanh Trì',
    distance: '4.6km',
    address: 'Chợ Yên Xá, Tân Triều, Thanh Trì, Hà Nội',
    hours: '05:00 – 24:00',
    tags: ['Trẻ trung', 'Sự kiện'],
    rating: 4.6,
    price: '110k - 200k/h',
    lat: 20.9780,
    lng: 105.7990,
    image: sportCourtImages.pickleball[5],
    logo: 'https://ui-avatars.com/api/?name=TT&background=d97706&color=fff&size=40&bold=true',
  },
  {
    id: 31,
    name: 'Sân Cầu Lông Nhà Thi Đấu Hà Đông',
    type: 'badminton',
    district: 'Hà Đông',
    distance: '7.5km',
    address: '182 Quang Trung, Quang Trung, Hà Đông, Hà Nội',
    hours: '05:30 – 22:30',
    tags: ['Sàn gỗ bóng', 'Chuẩn quốc gia'],
    rating: 4.8,
    price: '90k - 160k/h',
    lat: 20.9710,
    lng: 105.7760,
    image: sportCourtImages.badminton[1],
    logo: 'https://ui-avatars.com/api/?name=HD&background=dc2626&color=fff&size=40&bold=true',
  },
  {
    id: 32,
    name: 'CLB Pickleball Văn Quán Hà Đông',
    type: 'pickleball',
    district: 'Hà Đông',
    distance: '6.8km',
    address: 'Khu Đô Thị Văn Quán, Văn Quán, Hà Đông, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Mặt sân mới', 'Có HLV dạy'],
    rating: 4.7,
    price: '120k - 200k/h',
    lat: 20.9800,
    lng: 105.7860,
    image: sportCourtImages.pickleball[0],
    logo: 'https://ui-avatars.com/api/?name=VQ&background=0284c7&color=fff&size=40&bold=true',
  },

  // ==========================================
  // NAM & BẮC TỪ LIÊM, HOÀI ĐỨC, GIA LÂM
  // ==========================================
  {
    id: 33,
    name: 'CLB Pickleball Mỹ Đình (SVĐ Quốc Gia)',
    type: 'pickleball',
    district: 'Nam Từ Liêm',
    distance: '6.5km',
    address: 'Khu liên hợp thể thao Mỹ Đình, Lê Đức Thọ, Nam Từ Liêm, Hà Nội',
    hours: '05:00 – 23:30',
    tags: ['Cụm sân VIP', 'Không gian rộng'],
    rating: 4.9,
    price: '150k - 260k/h',
    lat: 21.0205,
    lng: 105.7640,
    image: sportCourtImages.pickleball[6],
    logo: 'https://ui-avatars.com/api/?name=MD&background=ea580c&color=fff&size=40&bold=true',
  },
  {
    id: 34,
    name: 'Cụm Sân Pickleball Hoa Phượng',
    type: 'pickleball',
    district: 'Hoài Đức',
    distance: '8.2km',
    address: 'BT9.15 Khu biệt thự Hoa Phượng, An Khánh, Hoài Đức, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Cụm 9 sân', '6 sân mái che'],
    rating: 4.8,
    price: '120k - 220k/h',
    lat: 20.9990,
    lng: 105.7360,
    image: sportCourtImages.pickleball[3],
    logo: 'https://ui-avatars.com/api/?name=HP&background=dc2626&color=fff&size=40&bold=true',
  },
  {
    id: 35,
    name: 'Pickleball Vinhomes Ocean Park 1',
    type: 'pickleball',
    district: 'Gia Lâm',
    distance: '11.5km',
    address: 'Khu Đô Thị Vinhomes Ocean Park, Đa Tốn, Gia Lâm, Hà Nội',
    hours: '05:00 – 23:00',
    tags: ['Mặt sân đạt chuẩn', 'Công viên biển'],
    rating: 5.0,
    price: '140k - 250k/h',
    lat: 20.9950,
    lng: 105.9450,
    image: sportCourtImages.pickleball[7],
    logo: 'https://ui-avatars.com/api/?name=OP&background=2563eb&color=fff&size=40&bold=true',
  }
]

// Sinh mạng lưới 270+ sân phủ dày đặc với ảnh thực tế tương ứng từng bộ môn
const sportTypes = ['pickleball', 'pickleball', 'pickleball', 'badminton', 'badminton', 'football', 'basketball', 'tennis', 'multi']
const sportNames = {
  pickleball: ['Pickleball Club', 'Sân Pickleball Pro', 'Pickleball Zone', 'Trung Tâm Pickleball', 'City Pickleball', 'Diamond Pickleball'],
  badminton: ['CLB Cầu Lông', 'Sân Cầu Lông Sao Vàng', 'Cầu Lông Hưng Phát', 'Nhà Tập Cầu Lông', 'Cầu Lông Tiêu Chuẩn'],
  football: ['Sân Bóng Đá Cỏ Nhân Tạo', 'Sân Bóng Mini 7', 'Sân Bóng Đô Thị'],
  basketball: ['Sân Bóng Rổ Thanh Niên', 'Bóng Rổ Hoop House'],
  tennis: ['CLB Quần Vợt', 'Sân Tennis Mặt Cứng'],
  multi: ['Khu Thể Thao Đa Năng', 'Nhà Đa Năng Cộng Đồng']
}

const hanoiClusters = [
  { centerLat: 21.025, centerLng: 105.835, radiusLat: 0.035, radiusLng: 0.040, count: 70, district: 'Đống Đa' },
  { centerLat: 21.008, centerLng: 105.795, radiusLat: 0.040, radiusLng: 0.045, count: 50, district: 'Cầu Giấy' },
  { centerLat: 21.060, centerLng: 105.815, radiusLat: 0.030, radiusLng: 0.035, count: 30, district: 'Tây Hồ' },
  { centerLat: 21.035, centerLng: 105.885, radiusLat: 0.045, radiusLng: 0.055, count: 35, district: 'Long Biên' },
  { centerLat: 20.975, centerLng: 105.830, radiusLat: 0.030, radiusLng: 0.040, count: 30, district: 'Hoàng Mai' },
  { centerLat: 21.000, centerLng: 105.735, radiusLat: 0.035, radiusLng: 0.035, count: 20, district: 'Hoài Đức' },
]

let idCounter = 36
const denseVenues = [...realVenues]

let seed = 42
function pseudoRandom() {
  seed = (seed * 9301 + 49297) % 233280
  return seed / 233280
}

hanoiClusters.forEach(cluster => {
  for (let i = 0; i < cluster.count; i++) {
    const latOffset = (pseudoRandom() - 0.5) * 2 * cluster.radiusLat
    const lngOffset = (pseudoRandom() - 0.5) * 2 * cluster.radiusLng
    const typeIndex = Math.floor(pseudoRandom() * sportTypes.length)
    const type = sportTypes[typeIndex]
    const nameList = sportNames[type]
    const baseName = nameList[Math.floor(pseudoRandom() * nameList.length)]
    const distNum = (0.3 + pseudoRandom() * 6).toFixed(1)

    // Lấy ảnh thực tế tương ứng chính xác theo bộ môn thể thao
    const imagePool = sportCourtImages[type] || sportCourtImages.pickleball
    const selectedImg = imagePool[i % imagePool.length]

    denseVenues.push({
      id: idCounter++,
      name: `${baseName} ${cluster.district} #${i + 1}`,
      type: type,
      district: cluster.district,
      distance: `${distNum}km`,
      address: `Khu đô thị & Phường ${cluster.district}, TP. Hà Nội`,
      hours: pseudoRandom() > 0.3 ? '05:00 – 23:30' : '00:00 – 24:00',
      tags: type === 'pickleball' ? ['Mái che', 'Chuẩn thi đấu'] : (type === 'badminton' ? ['Thảm Yonex', 'Trần cao'] : ['Cỏ FIFA', 'Đèn LED']),
      rating: +(4.4 + pseudoRandom() * 0.6).toFixed(1),
      price: type === 'pickleball' ? '120k - 220k/h' : (type === 'football' ? '300k - 550k/trận' : '80k - 150k/h'),
      lat: +(cluster.centerLat + latOffset).toFixed(4),
      lng: +(cluster.centerLng + lngOffset).toFixed(4),
      image: selectedImg,
      logo: `https://ui-avatars.com/api/?name=${type.substring(0, 2).toUpperCase()}&background=16a34a&color=fff&size=40&bold=true`
    })
  }
})

export const hanoiVenues = denseVenues
export const initialVenues = denseVenues

