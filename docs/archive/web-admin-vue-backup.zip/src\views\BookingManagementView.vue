<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import {
  Calendar,
  Search,
  Filter,
  Check,
  X,
  Eye,
  Plus,
  Clock,
  MapPin,
  Phone,
  User,
  DollarSign,
  CheckCircle2,
  AlertCircle,
  FileText
} from 'lucide-vue-next'
import { onBookingsChange, updateBookingStatus, createBooking } from '../firebase/services'

const bookings = ref([])
const searchQuery = ref('')
const selectedStatus = ref('all')
const isUpdating = ref(false)
let unsubscribe = null

// Toast notification
const toast = ref({ show: false, message: '', type: 'success' })
const showToast = (message, type = 'success') => {
  toast.value = { show: true, message, type }
  setTimeout(() => {
    toast.value.show = false
  }, 4000)
}

const defaultBookings = [
  { id: 'BK-1029', customer: 'Nguyễn Văn An', phone: '0901234567', field: 'Pickleball Cổng B Ga Hà Nội - Sân #2', time: '18:00 - 19:30', date: '31/10/2026', status: 'Chờ xác nhận', amount: '220,000đ', paymentMethod: 'Chuyển khoản VietQR', note: 'Khách yêu cầu mượn 2 vợt' },
  { id: 'BK-1030', customer: 'Trần Thị Bích', phone: '0912345678', field: 'Phúc Long Badminton - Sân Thảm #3', time: '19:30 - 21:00', date: '31/10/2026', status: 'Đã xác nhận', amount: '180,000đ', paymentMethod: 'Ví MoMo', note: 'Khách quen tuần 2 buổi' },
  { id: 'BK-1031', customer: 'Lê Hoàng Nam', phone: '0987654321', field: 'Sân Bóng Đá Mini Nam Từ Liêm', time: '17:00 - 18:30', date: '01/11/2026', status: 'Hoàn thành', amount: '450,000đ', paymentMethod: 'Tiền mặt tại quầy', note: 'Đã thanh toán đủ' },
  { id: 'BK-1032', customer: 'Phạm Minh Đức', phone: '0933445566', field: 'City Pickleball Chùa Bộc - Sân #1', time: '20:00 - 21:30', date: '01/11/2026', status: 'Chờ xác nhận', amount: '200,000đ', paymentMethod: 'Chuyển khoản VietQR', note: 'Đặt sân cố định' },
  { id: 'BK-1033', customer: 'Hoàng Anh Tuấn', phone: '0977889900', field: 'Tennis Club Ba Đình - Sân Đất Nện', time: '06:00 - 07:30', date: '02/11/2026', status: 'Đã xác nhận', amount: '350,000đ', paymentMethod: 'Chuyển khoản', note: 'Tập sáng' },
  { id: 'BK-1034', customer: 'Đỗ Thùy Trang', phone: '0944556677', field: 'Sân Cầu Lông Cầu Giấy Arena - Sân #5', time: '18:00 - 20:00', date: '29/10/2026', status: 'Đã hủy', amount: '240,000đ', paymentMethod: 'Chưa thanh toán', note: 'Khách báo bận đột xuất' },
]

onMounted(() => {
  bookings.value = defaultBookings
  unsubscribe = onBookingsChange((data) => {
    if (data && data.length > 0) {
      bookings.value = data.map(b => ({
        id: b.id,
        customer: b.customer || 'Khách đặt qua app',
        phone: b.phone || '098xxxxxxx',
        field: b.field || b.venueName || 'Sân thể thao',
        time: b.time || '18:00 - 19:30',
        date: b.date || '31/10/2026',
        status: b.status || 'Chờ xác nhận',
        amount: b.amount || '200,000đ',
        paymentMethod: b.paymentMethod || 'Chuyển khoản',
        note: b.note || 'Đặt qua app Alobooking'
      }))
    }
  })
})

onUnmounted(() => {
  if (unsubscribe) unsubscribe()
})

// Filter bookings
const filteredBookings = computed(() => {
  return bookings.value.filter(item => {
    const q = searchQuery.value.trim().toLowerCase()
    const matchesQuery = !q ||
      item.id.toLowerCase().includes(q) ||
      item.customer.toLowerCase().includes(q) ||
      item.phone.toLowerCase().includes(q) ||
      item.field.toLowerCase().includes(q)

    const matchesStatus = selectedStatus.value === 'all' || item.status === selectedStatus.value

    return matchesQuery && matchesStatus
  })
})

// Handle Actions
const handleApprove = async (id) => {
  isUpdating.value = true
  await updateBookingStatus(id, 'Đã xác nhận')
  const item = bookings.value.find(b => b.id === id)
  if (item) item.status = 'Đã xác nhận'
  showToast(`Đã xác nhận đơn đặt sân ${id}!`)
  isUpdating.value = false
}

const handleReject = async (id) => {
  isUpdating.value = true
  await updateBookingStatus(id, 'Đã hủy')
  const item = bookings.value.find(b => b.id === id)
  if (item) item.status = 'Đã hủy'
  showToast(`Đã hủy đơn đặt sân ${id}!`, 'error')
  isUpdating.value = false
}

const handleComplete = async (id) => {
  isUpdating.value = true
  await updateBookingStatus(id, 'Hoàn thành')
  const item = bookings.value.find(b => b.id === id)
  if (item) item.status = 'Hoàn thành'
  showToast(`Đã hoàn thành lượt sử dụng sân ${id}!`)
  isUpdating.value = false
}

const getStatusClass = (status) => {
  switch (status) {
    case 'Đã xác nhận': return 'badge-success'
    case 'Chờ xác nhận': return 'badge-warning'
    case 'Hoàn thành': return 'badge-primary'
    case 'Đã hủy': return 'badge-danger'
    default: return ''
  }
}

// Detail Modal
const isDetailOpen = ref(false)
const selectedBooking = ref(null)

const openDetailModal = (booking) => {
  selectedBooking.value = booking
  isDetailOpen.value = true
}

// Add Walk-in Booking Modal
const isAddModalOpen = ref(false)
const isSubmitting = ref(false)
const newBooking = ref({
  customer: '',
  phone: '',
  field: 'Pickleball Cổng B Ga Hà Nội - Sân #1',
  date: '31/10/2026',
  time: '18:00 - 19:30',
  amount: '200,000đ',
  paymentMethod: 'Tiền mặt tại quầy',
  note: 'Khách vãng lai đặt tại quầy'
})

const handleCreateBooking = async () => {
  if (!newBooking.value.customer || !newBooking.value.phone) {
    showToast('Vui lòng nhập tên khách và số điện thoại!', 'error')
    return
  }

  isSubmitting.value = true
  const newId = `BK-${Math.floor(1000 + Math.random() * 9000)}`
  const bookingObj = {
    id: newId,
    customer: newBooking.value.customer,
    phone: newBooking.value.phone,
    field: newBooking.value.field,
    date: newBooking.value.date,
    time: newBooking.value.time,
    amount: newBooking.value.amount,
    paymentMethod: newBooking.value.paymentMethod,
    note: newBooking.value.note,
    status: 'Đã xác nhận'
  }

  await createBooking(bookingObj)
  bookings.value.unshift(bookingObj)
  showToast(`Đã tạo đơn đặt sân ${newId} thành công!`)

  isSubmitting.value = false
  isAddModalOpen.value = false
  newBooking.value = {
    customer: '',
    phone: '',
    field: 'Pickleball Cổng B Ga Hà Nội - Sân #1',
    date: '31/10/2026',
    time: '18:00 - 19:30',
    amount: '200,000đ',
    paymentMethod: 'Tiền mặt tại quầy',
    note: 'Khách vãng lai đặt tại quầy'
  }
}
</script>

<template>
  <div class="booking-management">
    <!-- Toast Popup -->
    <transition name="fade">
      <div v-if="toast.show" class="toast-popup" :class="toast.type">
        <CheckCircle2 v-if="toast.type === 'success'" :size="20" />
        <AlertCircle v-else :size="20" />
        <span>{{ toast.message }}</span>
        <button class="toast-close" @click="toast.show = false"><X :size="16" /></button>
      </div>
    </transition>

    <!-- Top Action Bar -->
    <div class="header-actions glass-panel">
      <div class="search-filter">
        <div class="search-box">
          <Search :size="18" class="icon" />
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Tìm theo mã BK, tên khách, số điện thoại, sân..."
          />
          <button v-if="searchQuery" @click="searchQuery = ''" class="clear-btn"><X :size="16" /></button>
        </div>

        <div class="status-tabs">
          <button
            :class="['tab-btn', { active: selectedStatus === 'all' }]"
            @click="selectedStatus = 'all'"
          >
            Tất cả ({{ bookings.length }})
          </button>
          <button
            :class="['tab-btn', { active: selectedStatus === 'Chờ xác nhận' }]"
            @click="selectedStatus = 'Chờ xác nhận'"
          >
            Chờ xác nhận ({{ bookings.filter(b => b.status === 'Chờ xác nhận').length }})
          </button>
          <button
            :class="['tab-btn', { active: selectedStatus === 'Đã xác nhận' }]"
            @click="selectedStatus = 'Đã xác nhận'"
          >
            Đã xác nhận
          </button>
          <button
            :class="['tab-btn', { active: selectedStatus === 'Hoàn thành' }]"
            @click="selectedStatus = 'Hoàn thành'"
          >
            Hoàn thành
          </button>
        </div>
      </div>
      
      <div class="action-right">
        <button class="btn btn-primary" @click="isAddModalOpen = true">
          <Plus :size="18" />
          <span>Đặt Sân Tại Quầy</span>
        </button>
      </div>
    </div>

    <!-- Booking Table -->
    <div class="table-container glass-panel">
      <table class="data-table">
        <thead>
          <tr>
            <th>Mã Booking</th>
            <th>Khách Hàng</th>
            <th>Cụm Sân & Thời Gian</th>
            <th>Tổng Tiền</th>
            <th>Thanh Toán</th>
            <th>Trạng Thái</th>
            <th style="text-align: right;">Thao Tác</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="filteredBookings.length === 0">
            <td colspan="7" class="empty-cell">
              Không tìm thấy đơn đặt sân nào phù hợp.
            </td>
          </tr>
          <tr v-for="booking in filteredBookings" :key="booking.id">
            <td>
              <strong class="booking-id-tag">#{{ booking.id }}</strong>
            </td>
            <td>
              <div class="customer-info">
                <span class="name"><User :size="14" /> {{ booking.customer }}</span>
                <span class="phone"><Phone :size="13" /> {{ booking.phone }}</span>
              </div>
            </td>
            <td>
              <div class="booking-time-info">
                <span class="field-name"><MapPin :size="14" /> {{ booking.field }}</span>
                <span class="time-date"><Clock :size="13" /> {{ booking.time }} • {{ booking.date }}</span>
              </div>
            </td>
            <td>
              <strong class="amount-val">{{ booking.amount }}</strong>
            </td>
            <td>
              <span class="payment-method-tag">{{ booking.paymentMethod || 'Tiền mặt' }}</span>
            </td>
            <td>
              <span class="status-pill" :class="getStatusClass(booking.status)">
                {{ booking.status }}
              </span>
            </td>
            <td>
              <div class="action-buttons">
                <!-- Nút Xác Nhận -->
                <button 
                  v-if="booking.status === 'Chờ xác nhận'" 
                  class="icon-btn approve" 
                  title="Xác nhận lịch đặt"
                  :disabled="isUpdating"
                  @click="handleApprove(booking.id)"
                >
                  <Check :size="16" />
                </button>

                <!-- Nút Hoàn Thành -->
                <button 
                  v-if="booking.status === 'Đã xác nhận'" 
                  class="icon-btn complete" 
                  title="Đánh dấu hoàn thành"
                  :disabled="isUpdating"
                  @click="handleComplete(booking.id)"
                >
                  <Check :size="16" />
                </button>

                <!-- Nút Hủy Bỏ -->
                <button 
                  v-if="booking.status === 'Chờ xác nhận' || booking.status === 'Đã xác nhận'" 
                  class="icon-btn reject" 
                  title="Hủy đơn đặt sân"
                  :disabled="isUpdating"
                  @click="handleReject(booking.id)"
                >
                  <X :size="16" />
                </button>

                <!-- Nút Xem Chi Tiết -->
                <button class="icon-btn view" title="Xem chi tiết" @click="openDetailModal(booking)">
                  <Eye :size="16" />
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- MODAL XEM CHI TIẾT ĐƠN ĐẶT SÂN -->
    <transition name="fade">
      <div v-if="isDetailOpen" class="modal-overlay" @click.self="isDetailOpen = false">
        <div class="modal-card glass-panel" v-if="selectedBooking">
          <div class="modal-header">
            <h3>Chi Tiết Đơn Đặt Sân #{{ selectedBooking.id }}</h3>
            <button class="modal-close" @click="isDetailOpen = false"><X :size="20" /></button>
          </div>
          <div class="modal-body">
            <div class="booking-detail-grid">
              <div class="detail-row">
                <span class="label">Khách hàng:</span>
                <span class="val font-semibold">{{ selectedBooking.customer }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Số điện thoại:</span>
                <span class="val">{{ selectedBooking.phone }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Cụm sân:</span>
                <span class="val">{{ selectedBooking.field }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Ngày & Khung giờ:</span>
                <span class="val text-success">{{ selectedBooking.time }} • {{ selectedBooking.date }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Tổng tiền:</span>
                <span class="val text-highlight">{{ selectedBooking.amount }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Hình thức thanh toán:</span>
                <span class="val">{{ selectedBooking.paymentMethod }}</span>
              </div>
              <div class="detail-row">
                <span class="label">Trạng thái:</span>
                <span class="status-pill" :class="getStatusClass(selectedBooking.status)">
                  {{ selectedBooking.status }}
                </span>
              </div>
              <div class="detail-row">
                <span class="label">Ghi chú từ khách:</span>
                <span class="val note-val">{{ selectedBooking.note || 'Không có ghi chú' }}</span>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" @click="isDetailOpen = false">Đóng</button>
            <button
              v-if="selectedBooking.status === 'Chờ xác nhận'"
              class="btn btn-primary"
              @click="handleApprove(selectedBooking.id); isDetailOpen = false"
            >
              Xác Nhận Đơn Này
            </button>
          </div>
        </div>
      </div>
    </transition>

    <!-- MODAL TẠO ĐƠN ĐẶT SÂN TẠI QUẦY -->
    <transition name="fade">
      <div v-if="isAddModalOpen" class="modal-overlay" @click.self="isAddModalOpen = false">
        <div class="modal-card glass-panel">
          <div class="modal-header">
            <h3>Tạo Đơn Đặt Sân Tại Quầy</h3>
            <button class="modal-close" @click="isAddModalOpen = false"><X :size="20" /></button>
          </div>
          <form @submit.prevent="handleCreateBooking" class="modal-body">
            <div class="form-grid">
              <div class="form-group">
                <label>Tên Khách Hàng *</label>
                <input v-model="newBooking.customer" type="text" placeholder="Nguyễn Văn A" required />
              </div>
              <div class="form-group">
                <label>Số Điện Thoại *</label>
                <input v-model="newBooking.phone" type="tel" placeholder="0901234567" required />
              </div>
              <div class="form-group full-width">
                <label>Chọn Sân Thể Thao *</label>
                <input v-model="newBooking.field" type="text" required />
              </div>
              <div class="form-group">
                <label>Ngày Đặt Sân</label>
                <input v-model="newBooking.date" type="text" placeholder="31/10/2026" required />
              </div>
              <div class="form-group">
                <label>Khung Giờ</label>
                <input v-model="newBooking.time" type="text" placeholder="18:00 - 19:30" required />
              </div>
              <div class="form-group">
                <label>Tổng Tiền (VNĐ)</label>
                <input v-model="newBooking.amount" type="text" placeholder="200,000đ" required />
              </div>
              <div class="form-group">
                <label>Phương Thức Thanh Toán</label>
                <select v-model="newBooking.paymentMethod">
                  <option value="Tiền mặt tại quầy">Tiền mặt tại quầy</option>
                  <option value="Chuyển khoản VietQR">Chuyển khoản VietQR</option>
                  <option value="Ví MoMo">Ví MoMo</option>
                </select>
              </div>
              <div class="form-group full-width">
                <label>Ghi Chú</label>
                <input v-model="newBooking.note" type="text" placeholder="Ghi chú thêm nếu có..." />
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-outline" @click="isAddModalOpen = false">Hủy</button>
              <button type="submit" class="btn btn-primary" :disabled="isSubmitting">
                {{ isSubmitting ? 'Đang tạo...' : 'Xác Nhận Đặt Sân' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </transition>
  </div>
</template>

<style scoped>
.booking-management {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

/* Toast */
.toast-popup {
  position: fixed;
  top: 24px;
  right: 24px;
  z-index: 9999;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 20px;
  border-radius: 12px;
  font-weight: 500;
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
  backdrop-filter: blur(12px);
}

.toast-popup.success { background: rgba(16, 185, 129, 0.95); color: #fff; }
.toast-popup.error { background: rgba(239, 68, 68, 0.95); color: #fff; }

.toast-close {
  background: none;
  border: none;
  color: #fff;
  cursor: pointer;
}

/* Header Actions */
.header-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.search-filter {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.search-box {
  display: flex;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 0.55rem 1rem;
  width: 320px;
}

.search-box .icon {
  color: var(--text-muted);
  margin-right: 0.5rem;
}

.search-box input {
  background: none;
  border: none;
  color: var(--text-main);
  outline: none;
  width: 100%;
  font-size: 0.9rem;
}

.clear-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
}

.status-tabs {
  display: flex;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border-color);
  padding: 3px;
  border-radius: 10px;
  gap: 4px;
}

.tab-btn {
  padding: 6px 12px;
  border-radius: 8px;
  color: var(--text-muted);
  font-size: 0.85rem;
  transition: var(--transition-fast);
}

.tab-btn.active {
  background: var(--primary-color);
  color: #fff;
  font-weight: 600;
}

/* Table */
.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th {
  background-color: rgba(0, 0, 0, 0.25);
  color: var(--text-muted);
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 1rem 1.25rem;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

.data-table td {
  padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--border-color);
  font-size: 0.9rem;
}

.data-table tbody tr:hover {
  background-color: rgba(255, 255, 255, 0.02);
}

.booking-id-tag {
  color: #818cf8;
  font-family: monospace;
}

.customer-info, .booking-time-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.customer-info .name, .booking-time-info .field-name {
  font-weight: 600;
  color: var(--text-main);
  display: flex;
  align-items: center;
  gap: 6px;
}

.customer-info .phone, .booking-time-info .time-date {
  font-size: 0.85rem;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  gap: 6px;
}

.amount-val {
  color: #10b981;
}

.payment-method-tag {
  font-size: 0.8rem;
  background: rgba(255, 255, 255, 0.05);
  padding: 3px 8px;
  border-radius: 6px;
  color: var(--text-muted);
}

.status-pill {
  display: inline-flex;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
}

.badge-success { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
.badge-warning { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
.badge-primary { background: rgba(99, 102, 241, 0.15); color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.3); }
.badge-danger { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }

.action-buttons {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
}

.icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid var(--border-color);
  background: rgba(255, 255, 255, 0.05);
  color: var(--text-muted);
  transition: var(--transition-fast);
}

.icon-btn.approve:hover, .icon-btn.complete:hover {
  color: #34d399;
  background: rgba(16, 185, 129, 0.2);
  border-color: #10b981;
}

.icon-btn.reject:hover {
  color: #f87171;
  background: rgba(239, 68, 68, 0.2);
  border-color: #ef4444;
}

.icon-btn.view:hover {
  color: #60a5fa;
  background: rgba(59, 130, 246, 0.2);
  border-color: #3b82f6;
}

.empty-cell {
  text-align: center;
  padding: 3rem;
  color: var(--text-muted);
}

/* Modals */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(8px);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
}

.modal-card {
  width: 100%;
  max-width: 580px;
  background: #18181b;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 20px;
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid var(--border-color);
}

.modal-close {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
}

.modal-body {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.booking-detail-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: rgba(0, 0, 0, 0.25);
  padding: 1.25rem;
  border-radius: 12px;
  border: 1px solid var(--border-color);
}

.detail-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
}

.detail-row .label { color: var(--text-muted); }
.detail-row .val { color: var(--text-main); }
.text-highlight { color: #10b981; font-weight: 700; }
.note-val { font-style: italic; color: #cbd5e1; }

.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group.full-width {
  grid-column: span 2;
}

.form-group label {
  font-size: 0.85rem;
  color: var(--text-muted);
}

.form-group input, .form-group select {
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.7rem 1rem;
  border-radius: 10px;
  outline: none;
}

.form-group select option {
  background: #18181b;
  color: #fff;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 1.25rem 1.5rem;
  border-top: 1px solid var(--border-color);
}
</style>
