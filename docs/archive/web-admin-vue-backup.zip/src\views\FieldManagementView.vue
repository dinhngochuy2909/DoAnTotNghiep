<script setup>
import { ref, computed, onMounted } from 'vue'
import {
  Plus,
  Edit3,
  Trash2,
  Search,
  Filter,
  CloudUpload,
  Eye,
  CheckCircle2,
  AlertCircle,
  X,
  MapPin,
  Clock,
  Star,
  DollarSign,
  LayoutGrid,
  List,
  Sparkles,
  ArrowUpDown,
  Phone,
  RefreshCw
} from 'lucide-vue-next'
import { getVenues, syncVenuesToFirestore, addVenue, updateVenue, deleteVenue } from '../firebase/services'
import { sportCourtImages } from '../data/venues'

// --- STATE QUẢN LÝ SÂN ---
const fields = ref([])
const isLoading = ref(true)
const isSyncing = ref(false)
const viewMode = ref('table') // 'table' | 'grid'

// Toast notification
const toast = ref({ show: false, message: '', type: 'success' })
const showToast = (message, type = 'success') => {
  toast.value = { show: true, message, type }
  setTimeout(() => {
    toast.value.show = false
  }, 4000)
}

// Bộ lọc & Tìm kiếm
const searchQuery = ref('')
const filterType = ref('all')
const filterDistrict = ref('all')
const filterStatus = ref('all')
const sortBy = ref('id_asc')

// Danh sách quận huyện tại Hà Nội
const districts = [
  'Đống Đa', 'Cầu Giấy', 'Nam Từ Liêm', 'Thanh Xuân', 'Ba Đình',
  'Hoàn Kiếm', 'Tây Hồ', 'Hai Bà Trưng', 'Hoàng Mai', 'Hà Đông', 'Long Biên', 'Bắc Từ Liêm'
]

// Toạ độ mẫu theo từng quận để gợi ý tự động khi thêm sân
const districtCoordinates = {
  'Đống Đa': { lat: 21.0245, lng: 105.8350 },
  'Cầu Giấy': { lat: 21.0360, lng: 105.7905 },
  'Nam Từ Liêm': { lat: 21.0160, lng: 105.7650 },
  'Thanh Xuân': { lat: 20.9980, lng: 105.8120 },
  'Ba Đình': { lat: 21.0340, lng: 105.8230 },
  'Hoàn Kiếm': { lat: 21.0285, lng: 105.8542 },
  'Tây Hồ': { lat: 21.0710, lng: 105.8250 },
  'Hai Bà Trưng': { lat: 21.0080, lng: 105.8520 },
  'Hoàng Mai': { lat: 20.9730, lng: 105.8480 },
  'Hà Đông': { lat: 20.9720, lng: 105.7750 },
  'Long Biên': { lat: 21.0450, lng: 105.8850 },
  'Bắc Từ Liêm': { lat: 21.0650, lng: 105.7580 }
}

// Phân trang
const currentPage = ref(1)
const itemsPerPage = ref(10)

// --- LOAD DATA ---
const loadVenues = async () => {
  isLoading.value = true
  try {
    const data = await getVenues()
    fields.value = data.map((v, index) => ({
      id: v.id || index + 1,
      name: v.name || 'Sân thể thao',
      type: v.type || 'pickleball',
      district: v.district || 'Đống Đa',
      address: v.address || 'Hà Nội',
      price: v.price || '100k - 200k/h',
      status: v.status || (index % 5 === 0 ? 'Bảo trì' : index % 3 === 0 ? 'Đang sử dụng' : 'Trống'),
      hours: v.hours || '06:00 – 23:00',
      rating: v.rating || 4.8,
      lat: v.lat || 21.0285,
      lng: v.lng || 105.8542,
      image: v.image || sportCourtImages.pickleball?.[0] || 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600',
      tags: Array.isArray(v.tags) && v.tags.length ? v.tags : ['Mở 24/7', 'Đèn LED cao cấp'],
      courtsCount: v.courtsCount || Math.floor(Math.random() * 6) + 3
    }))
  } catch (error) {
    showToast('Lỗi khi tải dữ liệu sân', 'error')
  } finally {
    isLoading.value = false
  }
}

onMounted(() => {
  loadVenues()
})

// --- FILTER & SORT LOGIC ---
const filteredFields = computed(() => {
  return fields.value.filter(item => {
    // Search by name or address or district
    const query = searchQuery.value.trim().toLowerCase()
    const matchesQuery = !query ||
      item.name.toLowerCase().includes(query) ||
      item.address.toLowerCase().includes(query) ||
      item.district.toLowerCase().includes(query)

    // Type filter
    const matchesType = filterType.value === 'all' || item.type === filterType.value

    // District filter
    const matchesDistrict = filterDistrict.value === 'all' || item.district === filterDistrict.value

    // Status filter
    const matchesStatus = filterStatus.value === 'all' || item.status === filterStatus.value

    return matchesQuery && matchesType && matchesDistrict && matchesStatus
  }).sort((a, b) => {
    switch (sortBy.value) {
      case 'id_asc': return (a.id > b.id ? 1 : -1)
      case 'name_asc': return a.name.localeCompare(b.name)
      case 'name_desc': return b.name.localeCompare(a.name)
      case 'rating_desc': return (b.rating || 0) - (a.rating || 0)
      default: return 0
    }
  })
})

const totalPages = computed(() => Math.ceil(filteredFields.value.length / itemsPerPage.value) || 1)

const paginatedFields = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value
  return filteredFields.value.slice(start, start + itemsPerPage.value)
})

// --- MODAL THÊM / SỬA SÂN ---
const isFormModalOpen = ref(false)
const modalMode = ref('create') // 'create' | 'edit'
const isSubmitting = ref(false)

const formVenue = ref({
  id: null,
  name: '',
  type: 'pickleball',
  district: 'Đống Đa',
  address: '',
  price: '120k - 200k/h',
  hours: '06:00 – 23:00',
  rating: 4.8,
  status: 'Trống',
  lat: 21.0245,
  lng: 105.8412,
  image: '',
  tagsString: 'Mái che cao, Đèn LED, Chỗ đỗ xe',
  courtsCount: 4
})

const openAddModal = () => {
  modalMode.value = 'create'
  const coords = districtCoordinates['Đống Đa']
  formVenue.value = {
    id: null,
    name: '',
    type: 'pickleball',
    district: 'Đống Đa',
    address: '',
    price: '120k - 200k/h',
    hours: '06:00 – 23:00',
    rating: 4.8,
    status: 'Trống',
    lat: coords.lat,
    lng: coords.lng,
    image: sportCourtImages.pickleball[0],
    tagsString: 'Mái che cao, Đèn LED, Thảm thi đấu, Chỗ đỗ xe',
    courtsCount: 4
  }
  isFormModalOpen.value = true
}

const openEditModal = (venue) => {
  modalMode.value = 'edit'
  formVenue.value = {
    ...venue,
    tagsString: Array.isArray(venue.tags) ? venue.tags.join(', ') : venue.tags || ''
  }
  isFormModalOpen.value = true
}

// Khi đổi quận trong modal -> tự động cập nhật tọa độ gợi ý
const onModalDistrictChange = () => {
  const coords = districtCoordinates[formVenue.value.district]
  if (coords) {
    formVenue.value.lat = coords.lat
    formVenue.value.lng = coords.lng
  }
}

// Chọn ảnh mẫu nhanh từ thư viện theo loại môn
const pickSampleImage = (type) => {
  const list = sportCourtImages[type] || sportCourtImages.pickleball
  const randomIndex = Math.floor(Math.random() * list.length)
  formVenue.value.image = list[randomIndex]
}

const handleSaveVenue = async () => {
  if (!formVenue.value.name.trim()) {
    showToast('Vui lòng nhập tên cụm sân!', 'error')
    return
  }
  if (!formVenue.value.address.trim()) {
    showToast('Vui lòng nhập địa chỉ cụ thể!', 'error')
    return
  }

  isSubmitting.value = true

  const tags = formVenue.value.tagsString
    ? formVenue.value.tagsString.split(',').map(t => t.trim()).filter(Boolean)
    : ['Tiêu chuẩn']

  const payload = {
    name: formVenue.value.name.trim(),
    type: formVenue.value.type,
    district: formVenue.value.district,
    address: formVenue.value.address.trim(),
    price: formVenue.value.price.trim(),
    hours: formVenue.value.hours.trim(),
    rating: Number(formVenue.value.rating) || 4.8,
    status: formVenue.value.status,
    lat: Number(formVenue.value.lat) || 21.0285,
    lng: Number(formVenue.value.lng) || 105.8542,
    image: formVenue.value.image || sportCourtImages[formVenue.value.type]?.[0] || 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600',
    tags,
    courtsCount: Number(formVenue.value.courtsCount) || 4
  }

  if (modalMode.value === 'create') {
    // Thêm mới
    const newId = fields.value.length ? Math.max(...fields.value.map(f => Number(f.id) || 0)) + 1 : 1
    const newVenue = { id: newId, ...payload }

    // Gọi Firebase service
    const fbRes = await addVenue(payload)
    if (fbRes.success && fbRes.id) {
      newVenue.id = fbRes.id
    }

    fields.value.unshift(newVenue)
    showToast(`Đã thêm sân "${newVenue.name}" thành công!`)
  } else {
    // Sửa sân
    const id = formVenue.value.id
    await updateVenue(id, payload)

    const index = fields.value.findIndex(f => f.id === id)
    if (index !== -1) {
      fields.value[index] = { ...fields.value[index], ...payload }
    }
    showToast(`Đã cập nhật sân "${payload.name}" thành công!`)
  }

  isSubmitting.value = false
  isFormModalOpen.value = false
}

// --- MODAL XÁC NHẬN XÓA SÂN ---
const isDeleteModalOpen = ref(false)
const venueToDelete = ref(null)
const isDeleting = ref(false)

const openDeleteModal = (venue) => {
  venueToDelete.value = venue
  isDeleteModalOpen.value = true
}

const confirmDelete = async () => {
  if (!venueToDelete.value) return
  isDeleting.value = true
  const id = venueToDelete.value.id
  const name = venueToDelete.value.name

  await deleteVenue(id)
  fields.value = fields.value.filter(f => f.id !== id)

  showToast(`Đã xóa sân "${name}" khỏi hệ thống!`, 'success')
  isDeleting.value = false
  isDeleteModalOpen.value = false
  venueToDelete.value = null
}

// --- MODAL XEM CHI TIẾT SÂN ---
const isDetailModalOpen = ref(false)
const detailVenue = ref(null)

const openDetailModal = (venue) => {
  detailVenue.value = venue
  isDetailModalOpen.value = true
}

// --- ĐỒNG BỘ FIRESTORE ---
const handleSyncFirestore = async () => {
  isSyncing.value = true
  showToast('Đang kết nối và đồng bộ lên Firebase Firestore alobooking-b2484...', 'info')
  const res = await syncVenuesToFirestore()
  if (res.success) {
    showToast(`Đã đồng bộ thành công ${res.count} sân lên Firestore!`, 'success')
    await loadVenues()
  } else {
    showToast(`Lỗi đồng bộ: ${res.error}. Đang dùng dữ liệu bộ nhớ đệm.`, 'error')
  }
  isSyncing.value = false
}

// Helper tên thể thao tiếng Việt
const sportName = (type) => {
  switch (type) {
    case 'pickleball': return 'Pickleball'
    case 'badminton': return 'Cầu lông'
    case 'football': return 'Bóng đá'
    case 'tennis': return 'Tennis'
    case 'basketball': return 'Bóng rổ'
    default: return type
  }
}

const sportBadgeClass = (type) => {
  switch (type) {
    case 'pickleball': return 'badge-pickleball'
    case 'badminton': return 'badge-badminton'
    case 'football': return 'badge-football'
    case 'tennis': return 'badge-tennis'
    case 'basketball': return 'badge-basketball'
    default: return 'badge-default'
  }
}

const statusBadgeClass = (status) => {
  switch (status) {
    case 'Trống': return 'status-vacant'
    case 'Đang sử dụng':
    case 'Đang hoạt động': return 'status-occupied'
    case 'Bảo trì': return 'status-maintenance'
    default: return 'status-vacant'
  }
}
</script>

<template>
  <div class="field-management">
    <!-- TOAST NOTIFICATION -->
    <transition name="toast">
      <div v-if="toast.show" class="toast-popup" :class="toast.type">
        <CheckCircle2 v-if="toast.type === 'success'" :size="20" />
        <AlertCircle v-else :size="20" />
        <span>{{ toast.message }}</span>
        <button class="toast-close" @click="toast.show = false"><X :size="16" /></button>
      </div>
    </transition>

    <!-- FIREBASE SYNC BAR & STATS SUMMARY -->
    <div class="top-overview-bar glass-panel">
      <div class="fb-meta">
        <div class="meta-badge">
          <span class="pulse-indicator"></span>
          <strong>Cloud Firestore</strong>
        </div>
        <div class="meta-stats">
          <span>Tổng số sân: <strong>{{ fields.length }}</strong></span>
          <span class="sep">•</span>
          <span>Đang mở: <strong class="text-success">{{ fields.filter(f => f.status === 'Trống' || f.status === 'Đang hoạt động').length }}</strong></span>
          <span class="sep">•</span>
          <span>Bảo trì: <strong class="text-warning">{{ fields.filter(f => f.status === 'Bảo trì').length }}</strong></span>
        </div>
      </div>
      
      <div class="top-actions">
        <button @click="handleSyncFirestore" class="btn btn-sync" :disabled="isSyncing">
          <CloudUpload :size="18" :class="{ 'spin-anim': isSyncing }" />
          <span>{{ isSyncing ? 'Đang đồng bộ...' : 'Đồng bộ Firestore' }}</span>
        </button>
        <button @click="openAddModal" class="btn btn-primary add-btn">
          <Plus :size="20" />
          <span>Thêm Sân Mới</span>
        </button>
      </div>
    </div>

    <!-- CONTROLS & FILTER BAR -->
    <div class="filters-bar glass-panel">
      <div class="search-box">
        <Search :size="18" class="icon" />
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Tìm theo tên sân, quận, địa chỉ..."
        />
        <button v-if="searchQuery" @click="searchQuery = ''" class="clear-btn">
          <X :size="16" />
        </button>
      </div>

      <div class="filter-group">
        <!-- Lọc Loại Thể Thao -->
        <div class="select-wrapper">
          <select v-model="filterType" class="filter-select">
            <option value="all">Tất cả môn thể thao</option>
            <option value="pickleball">Pickleball</option>
            <option value="badminton">Cầu lông</option>
            <option value="football">Bóng đá</option>
            <option value="tennis">Tennis</option>
            <option value="basketball">Bóng rổ</option>
          </select>
        </div>

        <!-- Lọc Quận Huyện -->
        <div class="select-wrapper">
          <select v-model="filterDistrict" class="filter-select">
            <option value="all">Tất cả quận huyện</option>
            <option v-for="d in districts" :key="d" :value="d">{{ d }}</option>
          </select>
        </div>

        <!-- Lọc Trạng Thái -->
        <div class="select-wrapper">
          <select v-model="filterStatus" class="filter-select">
            <option value="all">Tất cả trạng thái</option>
            <option value="Trống">Trống / Sẵn sàng</option>
            <option value="Đang sử dụng">Đang sử dụng</option>
            <option value="Bảo trì">Đang bảo trì</option>
          </select>
        </div>

        <!-- Sắp xếp -->
        <div class="select-wrapper">
          <select v-model="sortBy" class="filter-select">
            <option value="id_asc">Sắp xếp: Mặc định</option>
            <option value="name_asc">Tên sân (A → Z)</option>
            <option value="name_desc">Tên sân (Z → A)</option>
            <option value="rating_desc">Đánh giá cao nhất ⭐</option>
          </select>
        </div>
      </div>

      <!-- VIEW MODE TOGGLE -->
      <div class="view-toggle">
        <button
          :class="['toggle-btn', { active: viewMode === 'table' }]"
          @click="viewMode = 'table'"
          title="Xem dạng Bảng"
        >
          <List :size="18" />
        </button>
        <button
          :class="['toggle-btn', { active: viewMode === 'grid' }]"
          @click="viewMode = 'grid'"
          title="Xem dạng Lưới Thẻ"
        >
          <LayoutGrid :size="18" />
        </button>
      </div>
    </div>

    <!-- MAIN DATA DISPLAY -->
    <div v-if="isLoading" class="loading-state glass-panel">
      <RefreshCw :size="32" class="spin-anim" />
      <p>Đang tải danh sách sân thể thao...</p>
    </div>

    <div v-else-if="filteredFields.length === 0" class="empty-state glass-panel">
      <AlertCircle :size="48" class="empty-icon" />
      <h3>Không tìm thấy sân thể thao phù hợp</h3>
      <p>Hãy thử thay đổi từ khóa tìm kiếm hoặc bỏ bớt các bộ lọc đang chọn.</p>
      <button @click="searchQuery = ''; filterType = 'all'; filterDistrict = 'all'; filterStatus = 'all'" class="btn btn-outline">
        Xóa tất cả bộ lọc
      </button>
    </div>

    <!-- TABLE VIEW -->
    <div v-else-if="viewMode === 'table'" class="table-container glass-panel">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width: 70px;">ID</th>
            <th>Tên Cụm Sân</th>
            <th>Môn Thể Thao</th>
            <th>Quận Huyện</th>
            <th>Giá Thuê</th>
            <th>Giờ Mở Cửa</th>
            <th>Trạng Thái</th>
            <th style="text-align: right; width: 150px;">Thao Tác</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="field in paginatedFields" :key="field.id">
            <td class="id-cell">#{{ field.id }}</td>
            <td class="venue-cell">
              <div class="venue-cell-content">
                <img :src="field.image" :alt="field.name" class="table-thumb" />
                <div class="venue-text">
                  <span class="venue-name" @click="openDetailModal(field)">{{ field.name }}</span>
                  <span class="venue-addr">{{ field.address }}</span>
                </div>
              </div>
            </td>
            <td>
              <span class="sport-badge" :class="sportBadgeClass(field.type)">
                {{ sportName(field.type) }}
              </span>
            </td>
            <td>
              <span class="district-tag"><MapPin :size="13" /> {{ field.district }}</span>
            </td>
            <td><strong class="price-text">{{ field.price }}</strong></td>
            <td>
              <span class="hours-tag"><Clock :size="13" /> {{ field.hours }}</span>
            </td>
            <td>
              <span class="status-pill" :class="statusBadgeClass(field.status)">
                <span class="dot"></span>
                {{ field.status }}
              </span>
            </td>
            <td>
              <div class="action-buttons">
                <button @click="openDetailModal(field)" class="icon-btn view" title="Xem chi tiết">
                  <Eye :size="16" />
                </button>
                <button @click="openEditModal(field)" class="icon-btn edit" title="Chỉnh sửa sân">
                  <Edit3 :size="16" />
                </button>
                <button @click="openDeleteModal(field)" class="icon-btn delete" title="Xóa sân">
                  <Trash2 :size="16" />
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- GRID VIEW -->
    <div v-else-if="viewMode === 'grid'" class="grid-container">
      <div v-for="field in paginatedFields" :key="field.id" class="venue-card glass-panel">
        <div class="card-img-wrapper">
          <img :src="field.image" :alt="field.name" class="card-img" />
          <span class="sport-badge-floating" :class="sportBadgeClass(field.type)">
            {{ sportName(field.type) }}
          </span>
          <span class="status-floating" :class="statusBadgeClass(field.status)">
            {{ field.status }}
          </span>
          <div class="card-rating">
            <Star :size="14" class="star-icon" />
            <span>{{ field.rating }}</span>
          </div>
        </div>

        <div class="card-body">
          <div class="card-title-row">
            <h3 class="card-title" @click="openDetailModal(field)">{{ field.name }}</h3>
          </div>
          
          <p class="card-address">
            <MapPin :size="14" class="icon" />
            <span>{{ field.address }}</span>
          </p>

          <div class="card-info-grid">
            <div class="info-item">
              <Clock :size="14" class="icon" />
              <span>{{ field.hours }}</span>
            </div>
            <div class="info-item">
              <DollarSign :size="14" class="icon" />
              <strong class="price-val">{{ field.price }}</strong>
            </div>
          </div>

          <div class="card-tags">
            <span v-for="tag in (field.tags || []).slice(0, 3)" :key="tag" class="tag-pill">
              {{ tag }}
            </span>
          </div>

          <div class="card-footer">
            <span class="sub-courts-count">🏟️ {{ field.courtsCount || 4 }} sân thi đấu</span>
            <div class="card-actions">
              <button @click="openDetailModal(field)" class="icon-btn view" title="Xem chi tiết">
                <Eye :size="16" />
              </button>
              <button @click="openEditModal(field)" class="icon-btn edit" title="Sửa sân">
                <Edit3 :size="16" />
              </button>
              <button @click="openDeleteModal(field)" class="icon-btn delete" title="Xóa sân">
                <Trash2 :size="16" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- PAGINATION -->
    <div v-if="filteredFields.length > 0" class="pagination-bar glass-panel">
      <div class="pagination-info">
        Hiển thị <strong>{{ paginatedFields.length }}</strong> trên tổng số <strong>{{ filteredFields.length }}</strong> sân
      </div>
      <div class="pagination-controls">
        <button
          class="page-btn"
          :disabled="currentPage === 1"
          @click="currentPage--"
        >
          Trước
        </button>
        <span class="page-current">Trang {{ currentPage }} / {{ totalPages }}</span>
        <button
          class="page-btn"
          :disabled="currentPage >= totalPages"
          @click="currentPage++"
        >
          Sau
        </button>
      </div>
    </div>

    <!-- ============================================================== -->
    <!-- MODAL THÊM / CHỈNH SỬA SÂN THỂ THAO -->
    <!-- ============================================================== -->
    <transition name="fade">
      <div v-if="isFormModalOpen" class="modal-overlay" @click.self="isFormModalOpen = false">
        <div class="modal-card glass-panel">
          <div class="modal-header">
            <div class="modal-title-wrap">
              <div class="icon-circle">
                <Sparkles v-if="modalMode === 'create'" :size="20" />
                <Edit3 v-else :size="20" />
              </div>
              <h2>{{ modalMode === 'create' ? 'Thêm Sân Thể Thao Mới' : 'Cập Nhật Thông Tin Sân' }}</h2>
            </div>
            <button class="modal-close" @click="isFormModalOpen = false"><X :size="20" /></button>
          </div>

          <form @submit.prevent="handleSaveVenue" class="modal-body">
            <div class="form-grid">
              <!-- Tên sân -->
              <div class="form-group full-width">
                <label>Tên Cụm Sân <span class="required">*</span></label>
                <input
                  v-model="formVenue.name"
                  type="text"
                  placeholder="VD: Cụm Sân Pickleball & Cầu Lông Đống Đa"
                  required
                />
              </div>

              <!-- Loại môn thể thao -->
              <div class="form-group">
                <label>Môn Thể Thao <span class="required">*</span></label>
                <select v-model="formVenue.type" @change="pickSampleImage(formVenue.type)">
                  <option value="pickleball">Pickleball</option>
                  <option value="badminton">Cầu lông</option>
                  <option value="football">Bóng đá</option>
                  <option value="tennis">Tennis</option>
                  <option value="basketball">Bóng rổ</option>
                </select>
              </div>

              <!-- Quận Huyện -->
              <div class="form-group">
                <label>Quận / Huyện (Hà Nội) <span class="required">*</span></label>
                <select v-model="formVenue.district" @change="onModalDistrictChange">
                  <option v-for="d in districts" :key="d" :value="d">{{ d }}</option>
                </select>
              </div>

              <!-- Địa chỉ cụ thể -->
              <div class="form-group full-width">
                <label>Địa Chỉ Chi Tiết <span class="required">*</span></label>
                <input
                  v-model="formVenue.address"
                  type="text"
                  placeholder="VD: Số 18 Chùa Bộc, Trung Liệt, Đống Đa, Hà Nội"
                  required
                />
              </div>

              <!-- Giá thuê -->
              <div class="form-group">
                <label>Mức Giá Thuê / Giờ</label>
                <input
                  v-model="formVenue.price"
                  type="text"
                  placeholder="VD: 120k - 220k/h"
                />
              </div>

              <!-- Giờ hoạt động -->
              <div class="form-group">
                <label>Giờ Hoạt Động</label>
                <input
                  v-model="formVenue.hours"
                  type="text"
                  placeholder="VD: 06:00 – 23:00 hoặc Mở 24/7"
                />
              </div>

              <!-- Trạng thái -->
              <div class="form-group">
                <label>Trạng Thái Sân</label>
                <select v-model="formVenue.status">
                  <option value="Trống">Trống / Sẵn sàng đón khách</option>
                  <option value="Đang sử dụng">Đang sử dụng</option>
                  <option value="Bảo trì">Đang bảo trì</option>
                </select>
              </div>

              <!-- Số lượng sân con -->
              <div class="form-group">
                <label>Số Sân Con / Sân Thi Đấu</label>
                <input
                  v-model.number="formVenue.courtsCount"
                  type="number"
                  min="1"
                  max="50"
                  placeholder="VD: 4"
                />
              </div>

              <!-- Toạ độ Lat & Lng -->
              <div class="form-group">
                <label>Vĩ độ (Latitude)</label>
                <input v-model.number="formVenue.lat" type="number" step="0.0001" />
              </div>
              <div class="form-group">
                <label>Kinh độ (Longitude)</label>
                <input v-model.number="formVenue.lng" type="number" step="0.0001" />
              </div>

              <!-- URL Hình ảnh sân -->
              <div class="form-group full-width">
                <div class="label-with-action">
                  <label>URL Hình Ảnh Sân Thể Thao</label>
                  <button type="button" @click="pickSampleImage(formVenue.type)" class="btn-text-action">
                    🎨 Lấy ảnh mẫu chất lượng cao
                  </button>
                </div>
                <input
                  v-model="formVenue.image"
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                />
                <div v-if="formVenue.image" class="image-preview-box">
                  <img :src="formVenue.image" alt="Preview" class="preview-img" />
                </div>
              </div>

              <!-- Tiện ích / Tags -->
              <div class="form-group full-width">
                <label>Tiện Ích & Đặc Điểm (ngăn cách bằng dấu phẩy)</label>
                <input
                  v-model="formVenue.tagsString"
                  type="text"
                  placeholder="VD: Mái che cao, Đèn LED, Thảm Yonex, Chỗ đỗ ô tô, Căng tin, Tủ đồ"
                />
              </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-outline" @click="isFormModalOpen = false">
                Hủy bỏ
              </button>
              <button type="submit" class="btn btn-primary" :disabled="isSubmitting">
                <span>{{ isSubmitting ? 'Đang lưu...' : (modalMode === 'create' ? 'Tạo Sân Mới' : 'Lưu Thay Đổi') }}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </transition>

    <!-- ============================================================== -->
    <!-- MODAL XÁC NHẬN XÓA SÂN -->
    <!-- ============================================================== -->
    <transition name="fade">
      <div v-if="isDeleteModalOpen" class="modal-overlay" @click.self="isDeleteModalOpen = false">
        <div class="modal-card delete-card glass-panel">
          <div class="delete-icon-wrapper">
            <Trash2 :size="32" />
          </div>
          <h3>Xác Nhận Xóa Sân Thể Thao</h3>
          <p class="delete-desc">
            Bạn có chắc chắn muốn xóa sân <strong>"{{ venueToDelete?.name }}"</strong>?
            Hành động này sẽ xóa dữ liệu sân khỏi Firestore và không thể hoàn tác.
          </p>

          <div class="modal-footer delete-footer">
            <button class="btn btn-outline" @click="isDeleteModalOpen = false">Hủy</button>
            <button class="btn btn-danger" :disabled="isDeleting" @click="confirmDelete">
              <span>{{ isDeleting ? 'Đang xóa...' : 'Xác Nhận Xóa' }}</span>
            </button>
          </div>
        </div>
      </div>
    </transition>

    <!-- ============================================================== -->
    <!-- MODAL XEM CHI TIẾT SÂN -->
    <!-- ============================================================== -->
    <transition name="fade">
      <div v-if="isDetailModalOpen" class="modal-overlay" @click.self="isDetailModalOpen = false">
        <div class="modal-card detail-card glass-panel">
          <div class="modal-header">
            <div class="modal-title-wrap">
              <span class="sport-badge" :class="sportBadgeClass(detailVenue?.type)">
                {{ sportName(detailVenue?.type) }}
              </span>
              <h2>{{ detailVenue?.name }}</h2>
            </div>
            <button class="modal-close" @click="isDetailModalOpen = false"><X :size="20" /></button>
          </div>

          <div class="modal-body detail-body" v-if="detailVenue">
            <div class="detail-hero-img-wrap">
              <img :src="detailVenue.image" :alt="detailVenue.name" class="detail-hero-img" />
              <div class="detail-status-overlay">
                <span class="status-pill" :class="statusBadgeClass(detailVenue.status)">
                  <span class="dot"></span>
                  {{ detailVenue.status }}
                </span>
                <span class="rating-badge">⭐ {{ detailVenue.rating }} / 5.0</span>
              </div>
            </div>

            <div class="detail-info-list">
              <div class="detail-item">
                <span class="label"><MapPin :size="16" /> Địa chỉ:</span>
                <span class="val">{{ detailVenue.address }} ({{ detailVenue.district }})</span>
              </div>
              <div class="detail-item">
                <span class="label"><Clock :size="16" /> Giờ hoạt động:</span>
                <span class="val">{{ detailVenue.hours }}</span>
              </div>
              <div class="detail-item">
                <span class="label"><DollarSign :size="16" /> Giá thuê:</span>
                <span class="val highlight">{{ detailVenue.price }}</span>
              </div>
              <div class="detail-item">
                <span class="label">🏟️ Quy mô:</span>
                <span class="val">{{ detailVenue.courtsCount || 4 }} sân chuẩn thi đấu</span>
              </div>
              <div class="detail-item">
                <span class="label">🌐 Toạ độ GPS:</span>
                <span class="val">{{ detailVenue.lat }}, {{ detailVenue.lng }}</span>
              </div>
            </div>

            <div class="detail-tags-section">
              <h4>Tiện ích & Dịch vụ đi kèm:</h4>
              <div class="tags-container">
                <span v-for="tag in detailVenue.tags" :key="tag" class="tag-pill">
                  ✓ {{ tag }}
                </span>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button class="btn btn-outline" @click="isDetailModalOpen = false">Đóng</button>
            <button class="btn btn-primary" @click="isDetailModalOpen = false; openEditModal(detailVenue)">
              <Edit3 :size="16" />
              <span>Chỉnh Sửa Sân Này</span>
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<style scoped>
.field-management {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  position: relative;
}

/* Toast Notification */
.toast-popup {
  position: fixed;
  top: 24px;
  right: 24px;
  z-index: 9999;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 20px;
  border-radius: 12px;
  font-weight: 500;
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
  backdrop-filter: blur(12px);
  animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.toast-popup.success {
  background: rgba(16, 185, 129, 0.95);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.toast-popup.error {
  background: rgba(239, 68, 68, 0.95);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.toast-popup.info {
  background: rgba(99, 102, 241, 0.95);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.toast-close {
  background: none;
  border: none;
  color: #fff;
  opacity: 0.8;
  cursor: pointer;
  display: flex;
  align-items: center;
}

@keyframes slideIn {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

/* Top Overview Bar */
.top-overview-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.fb-meta {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  flex-wrap: wrap;
}

.meta-badge {
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(245, 158, 11, 0.15);
  color: #fbbf24;
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 0.85rem;
  border: 1px solid rgba(245, 158, 11, 0.3);
}

.pulse-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #f59e0b;
  box-shadow: 0 0 10px #f59e0b;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(245, 158, 11, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
}

.meta-stats {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 0.9rem;
  color: var(--text-muted);
}

.meta-stats .sep {
  opacity: 0.3;
}

.text-success { color: #34d399; }
.text-warning { color: #fbbf24; }

.top-actions {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.btn-sync {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.65rem 1.2rem;
  border-radius: 10px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  transition: var(--transition-fast);
}

.btn-sync:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.3);
  transform: translateY(-1px);
}

.add-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0.65rem 1.4rem;
  font-weight: 600;
  box-shadow: 0 4px 14px rgba(99, 102, 241, 0.4);
}

/* Filters Bar */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  gap: 1rem;
  flex-wrap: wrap;
}

.search-box {
  display: flex;
  align-items: center;
  background: rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 0.55rem 1rem;
  width: 320px;
  transition: var(--transition-fast);
}

.search-box:focus-within {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
}

.search-box .icon {
  color: var(--text-muted);
  margin-right: 0.5rem;
}

.search-box input {
  background: none;
  border: none;
  outline: none;
  color: var(--text-main);
  width: 100%;
  font-size: 0.9rem;
}

.clear-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
}

.filter-group {
  display: flex;
  align-items: center;
  gap: 0.65rem;
  flex-wrap: wrap;
}

.select-wrapper {
  position: relative;
}

.filter-select {
  background: rgba(0, 0, 0, 0.25);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.55rem 1rem;
  border-radius: 10px;
  font-size: 0.85rem;
  outline: none;
  cursor: pointer;
  transition: var(--transition-fast);
}

.filter-select:hover, .filter-select:focus {
  border-color: var(--primary-color);
}

.filter-select option {
  background: #18181b;
  color: #fff;
}

.view-toggle {
  display: flex;
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 3px;
}

.toggle-btn {
  padding: 6px 10px;
  border-radius: 6px;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  transition: var(--transition-fast);
}

.toggle-btn.active {
  background: var(--primary-color);
  color: #fff;
}

/* Table View */
.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th {
  background: rgba(0, 0, 0, 0.25);
  color: var(--text-muted);
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 1rem 1.25rem;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

.data-table td {
  padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--border-color);
  font-size: 0.9rem;
}

.data-table tbody tr:hover {
  background: rgba(255, 255, 255, 0.02);
}

.id-cell {
  font-family: monospace;
  color: var(--text-muted);
  font-weight: 600;
}

.venue-cell-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.table-thumb {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  object-fit: crop;
  flex-shrink: 0;
  border: 1px solid var(--border-color);
}

.venue-text {
  display: flex;
  flex-direction: column;
}

.venue-name {
  font-weight: 600;
  color: var(--text-main);
  cursor: pointer;
  transition: var(--transition-fast);
}

.venue-name:hover {
  color: var(--primary-hover);
  text-decoration: underline;
}

.venue-addr {
  font-size: 0.8rem;
  color: var(--text-muted);
  max-width: 280px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.district-tag, .hours-tag {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 0.85rem;
  color: var(--text-muted);
}

.price-text {
  color: #10b981;
}

/* Badges */
.sport-badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.78rem;
  font-weight: 600;
  letter-spacing: 0.02em;
}

.badge-pickleball { background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.3); }
.badge-badminton { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
.badge-football { background: rgba(234, 88, 12, 0.15); color: #fb923c; border: 1px solid rgba(234, 88, 12, 0.3); }
.badge-tennis { background: rgba(234, 179, 8, 0.15); color: #facc15; border: 1px solid rgba(234, 179, 8, 0.3); }
.badge-basketball { background: rgba(236, 72, 153, 0.15); color: #f472b6; border: 1px solid rgba(236, 72, 153, 0.3); }

.status-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.78rem;
  font-weight: 500;
}

.status-pill .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.status-vacant { background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.25); }
.status-vacant .dot { background: #10b981; }

.status-occupied { background: rgba(59, 130, 246, 0.12); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.25); }
.status-occupied .dot { background: #3b82f6; }

.status-maintenance { background: rgba(239, 68, 68, 0.12); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.25); }
.status-maintenance .dot { background: #ef4444; }

/* Action Buttons */
.action-buttons {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
}

.icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid var(--border-color);
  background: rgba(255, 255, 255, 0.04);
  color: var(--text-muted);
  transition: var(--transition-fast);
}

.icon-btn.view:hover { background: rgba(59, 130, 246, 0.2); color: #60a5fa; border-color: #3b82f6; }
.icon-btn.edit:hover { background: rgba(99, 102, 241, 0.2); color: #818cf8; border-color: #6366f1; }
.icon-btn.delete:hover { background: rgba(239, 68, 68, 0.2); color: #f87171; border-color: #ef4444; }

/* Grid View */
.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 1.5rem;
}

.venue-card {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border-radius: 16px;
  transition: var(--transition);
}

.venue-card:hover {
  transform: translateY(-4px);
  border-color: rgba(255, 255, 255, 0.2);
}

.card-img-wrapper {
  position: relative;
  width: 100%;
  height: 180px;
}

.card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.sport-badge-floating {
  position: absolute;
  top: 12px;
  left: 12px;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  backdrop-filter: blur(8px);
}

.status-floating {
  position: absolute;
  top: 12px;
  right: 12px;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  backdrop-filter: blur(8px);
}

.card-rating {
  position: absolute;
  bottom: 12px;
  right: 12px;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(6px);
  color: #fbbf24;
  padding: 3px 8px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 4px;
}

.star-icon { fill: #fbbf24; color: #fbbf24; }

.card-body {
  padding: 1.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  flex: 1;
}

.card-title {
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: var(--transition-fast);
}

.card-title:hover {
  color: var(--primary-hover);
}

.card-address {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  color: var(--text-muted);
  font-size: 0.85rem;
  line-height: 1.4;
}

.card-info-grid {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.6rem 0;
  border-top: 1px solid var(--border-color);
  border-bottom: 1px solid var(--border-color);
  font-size: 0.85rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--text-muted);
}

.price-val {
  color: #10b981;
  font-size: 0.95rem;
}

.card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.tag-pill {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border-color);
  color: var(--text-muted);
  font-size: 0.75rem;
  padding: 2px 8px;
  border-radius: 6px;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: auto;
  padding-top: 0.75rem;
}

.sub-courts-count {
  font-size: 0.8rem;
  color: var(--text-muted);
}

.card-actions {
  display: flex;
  gap: 6px;
}

/* Pagination Bar */
.pagination-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
}

.pagination-info {
  font-size: 0.85rem;
  color: var(--text-muted);
}

.pagination-controls {
  display: flex;
  align-items: center;
  gap: 12px;
}

.page-btn {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 6px 14px;
  border-radius: 8px;
  font-size: 0.85rem;
  transition: var(--transition-fast);
}

.page-btn:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.15);
}

.page-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.page-current {
  font-size: 0.85rem;
  font-weight: 500;
  color: var(--text-muted);
}

/* Modal Overlay & Card */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(8px);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
}

.modal-card {
  width: 100%;
  max-width: 680px;
  max-height: 90vh;
  overflow-y: auto;
  background: #18181b;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 20px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid var(--border-color);
}

.modal-title-wrap {
  display: flex;
  align-items: center;
  gap: 12px;
}

.icon-circle {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  background: rgba(99, 102, 241, 0.15);
  color: var(--primary-color);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-close {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  padding: 6px;
  border-radius: 8px;
  transition: var(--transition-fast);
}

.modal-close:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.modal-body {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.25rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group.full-width {
  grid-column: span 2;
}

.form-group label {
  font-size: 0.85rem;
  font-weight: 500;
  color: var(--text-muted);
}

.required {
  color: #ef4444;
}

.label-with-action {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.btn-text-action {
  background: none;
  border: none;
  color: var(--primary-hover);
  font-size: 0.8rem;
  font-weight: 500;
  cursor: pointer;
}

.btn-text-action:hover {
  text-decoration: underline;
}

.form-group input,
.form-group select {
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid var(--border-color);
  color: var(--text-main);
  padding: 0.75rem 1rem;
  border-radius: 10px;
  font-size: 0.9rem;
  outline: none;
  transition: var(--transition-fast);
}

.form-group input:focus,
.form-group select:focus {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
}

.form-group select option {
  background: #18181b;
  color: #fff;
}

.image-preview-box {
  margin-top: 8px;
  border-radius: 10px;
  overflow: hidden;
  height: 120px;
  border: 1px solid var(--border-color);
}

.preview-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 1.25rem 1.5rem;
  border-top: 1px solid var(--border-color);
}

/* Delete Card Modal */
.delete-card {
  max-width: 440px;
  text-align: center;
  padding: 2rem 1.5rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.delete-icon-wrapper {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: rgba(239, 68, 68, 0.15);
  color: #ef4444;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.5rem;
}

.delete-desc {
  font-size: 0.9rem;
  color: var(--text-muted);
  line-height: 1.5;
}

.delete-footer {
  width: 100%;
  border-top: none;
  padding: 0;
  justify-content: center;
  margin-top: 0.5rem;
}

.btn-danger {
  background: #ef4444;
  color: #fff;
  padding: 0.7rem 1.5rem;
  border-radius: 10px;
  font-weight: 600;
  transition: var(--transition-fast);
}

.btn-danger:hover:not(:disabled) {
  background: #dc2626;
  box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);
}

/* Detail Card Modal */
.detail-card {
  max-width: 620px;
}

.detail-hero-img-wrap {
  position: relative;
  width: 100%;
  height: 220px;
  border-radius: 12px;
  overflow: hidden;
}

.detail-hero-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.detail-status-overlay {
  position: absolute;
  bottom: 12px;
  left: 12px;
  right: 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.rating-badge {
  background: rgba(0, 0, 0, 0.8);
  padding: 4px 12px;
  border-radius: 20px;
  font-weight: 700;
  color: #fbbf24;
  font-size: 0.85rem;
}

.detail-info-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: rgba(0, 0, 0, 0.25);
  padding: 1.25rem;
  border-radius: 12px;
  border: 1px solid var(--border-color);
}

.detail-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
}

.detail-item .label {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--text-muted);
}

.detail-item .val {
  font-weight: 500;
  color: var(--text-main);
}

.detail-item .val.highlight {
  color: #10b981;
  font-weight: 700;
}

.detail-tags-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.detail-tags-section h4 {
  font-size: 0.9rem;
  color: var(--text-muted);
}

.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

/* Loading & Empty */
.loading-state, .empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 4rem 2rem;
  gap: 1rem;
  text-align: center;
  color: var(--text-muted);
}

.empty-icon {
  color: var(--text-muted);
  opacity: 0.5;
}

.spin-anim {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .filters-bar {
    flex-direction: column;
    align-items: stretch;
  }
  .search-box {
    width: 100%;
  }
  .form-grid {
    grid-template-columns: 1fr;
  }
  .form-group.full-width {
    grid-column: span 1;
  }
}
</style>
