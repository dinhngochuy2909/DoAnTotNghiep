<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// Current date/time
const now = new Date()
const days = ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm', 'Thứ sáu', 'Thứ bảy']
const dayName = days[now.getDay()]
const dateStr = `${dayName}, ${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`

const activeTab = ref('home')
const activeFilter = ref('all')
const searchQuery = ref('')

const handleNavClick = (key) => {
  activeTab.value = key
  if (key === 'account') {
    router.push('/profile')
  } else if (key === 'map') {
    router.push('/map')
  }
}

const goToProfile = () => {
  router.push('/profile')
}

import { hanoiVenues } from '../data/venues.js'
import { createBooking } from '../firebase/services.js'

const venues = ref(hanoiVenues)

const favorites = ref(new Set())
const toggleFavorite = (id) => {
  if (favorites.value.has(id)) favorites.value.delete(id)
  else favorites.value.add(id)
}

// Logic Booking Modal kết nối Firebase
const selectedVenueForBooking = ref(null)
const bookingCustomerName = ref('Đinh Ngọc Huy')
const bookingCustomerPhone = ref('0396392904')
const bookingTimeSlot = ref('18:00 - 19:30')
const bookingDate = ref(new Date().toISOString().split('T')[0])
const isBookingSubmitting = ref(false)
const bookingSuccessMsg = ref('')

const openBookingModal = (venue) => {
  selectedVenueForBooking.value = venue
  bookingSuccessMsg.value = ''
}

const closeBookingModal = () => {
  selectedVenueForBooking.value = null
  bookingSuccessMsg.value = ''
}

const handleConfirmBooking = async () => {
  if (!selectedVenueForBooking.value) return
  isBookingSubmitting.value = true
  
  const bookingData = {
    customer: bookingCustomerName.value,
    phone: bookingCustomerPhone.value,
    venueId: selectedVenueForBooking.value.id,
    venueName: selectedVenueForBooking.value.name,
    district: selectedVenueForBooking.value.district,
    field: selectedVenueForBooking.value.type === 'football' ? 'Sân 7 người Cỏ FIFA' : selectedVenueForBooking.value.type === 'badminton' ? 'Sân Thảm Yonex #1' : 'Sân Chuẩn Thi Đấu',
    time: bookingTimeSlot.value,
    date: bookingDate.value,
    amount: selectedVenueForBooking.value.price || '200,000đ',
    status: 'Chờ xác nhận',
    paymentMethod: 'Chuyển khoản QR'
  }

  const res = await createBooking(bookingData)
  if (res.success) {
    bookingSuccessMsg.value = '🎉 Đặt sân thành công! Đơn đã lưu trực tiếp vào Firestore alobooking-b2484.'
    setTimeout(() => {
      closeBookingModal()
    }, 1800)
  } else {
    bookingSuccessMsg.value = '❌ Lỗi: ' + res.error
  }
  isBookingSubmitting.value = false
}

const currentSportFilter = ref('all') // 'all', 'pickleball', 'badminton', 'football', 'tennis'
const currentDistrict = ref('all') // 'all', 'Đống Đa', 'Cầu Giấy', 'Ba Đình', 'Tây Hồ', 'Thanh Xuân', etc.

const districts = [
  'Tất cả quận',
  'Đống Đa',
  'Cầu Giấy',
  'Ba Đình',
  'Tây Hồ',
  'Thanh Xuân',
  'Hai Bà Trưng',
  'Hoàng Mai',
  'Long Biên',
  'Hà Đông',
  'Nam Từ Liêm',
  'Bắc Từ Liêm',
  'Hoài Đức',
  'Gia Lâm',
  'Thanh Trì'
]

const filteredVenues = computed(() => {
  let list = venues.value

  // Filter by sport tag
  if (currentSportFilter.value !== 'all') {
    list = list.filter(v => v.type === currentSportFilter.value)
  }

  // Filter by district
  if (currentDistrict.value !== 'all' && currentDistrict.value !== 'Tất cả quận') {
    list = list.filter(v => v.district === currentDistrict.value)
  }

  // Filter by quick nav buttons
  if (activeFilter.value === 'fav') {
    list = list.filter(v => favorites.value.has(v.id))
  }

  // Filter by search query
  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase()
    list = list.filter(v =>
      v.name.toLowerCase().includes(q) ||
      v.address.toLowerCase().includes(q) ||
      (v.district && v.district.toLowerCase().includes(q)) ||
      (v.tags && v.tags.some(t => t.toLowerCase().includes(q)))
    )
  }

  return list
})

const navItems = [
  { key: 'home', label: 'Trang chủ', icon: 'home' },
  { key: 'map', label: 'Bản đồ', icon: 'map' },
  { key: 'explore', label: 'Khám phá', icon: 'explore' },
  { key: 'highlight', label: 'Nổi bật', icon: 'highlight' },
  { key: 'account', label: 'Tài khoản', icon: 'account' },
]
</script>

<template>
  <div class="app-shell">

    <!-- ===== HEADER ===== -->
    <header class="app-header">
      <!-- Shuttlecock decoration top-left (partially clipped by header overflow:hidden) -->
      <div class="shuttlecock-deco">
        <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
          <!-- Shuttlecock: cork at top-left, feathers spread bottom-right -->
          <!-- Rotated 135deg so cork is top-left, feathers go inward -->
          <g transform="translate(20, 20) rotate(135, 50, 50)">
            <!-- Feather vane outer fill -->
            <path d="M22 8 Q26 30 30 55 Q36 75 50 88 Q64 75 70 55 Q74 30 78 8 Q72 4 64 2 Q57 0 50 0 Q43 0 36 2 Q28 4 22 8 Z"
              fill="rgba(255,255,255,0.22)"
              stroke="rgba(255,255,255,0.65)" stroke-width="1.2"/>
            <!-- Feather shafts (7) -->
            <line x1="50" y1="86" x2="22" y2="8" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="30" y2="4" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="39" y2="1" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="50" y2="0" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="61" y2="1" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="70" y2="4" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <line x1="50" y1="86" x2="78" y2="8" stroke="rgba(255,255,255,0.75)" stroke-width="1.4" stroke-linecap="round"/>
            <!-- Top arc -->
            <path d="M22 8 Q30 2 39 1 Q44 0 50 0 Q56 0 61 1 Q70 2 78 8"
              stroke="rgba(255,255,255,0.7)" stroke-width="1.3" fill="none" stroke-linecap="round"/>
            <!-- Texture lines -->
            <path d="M32 52 Q38 35 43 18 Q46 8 50 3" stroke="rgba(255,255,255,0.35)" stroke-width="1" fill="none"/>
            <path d="M68 52 Q62 35 57 18 Q54 8 50 3" stroke="rgba(255,255,255,0.35)" stroke-width="1" fill="none"/>
            <!-- Cork hemisphere -->
            <path d="M38 88 Q38 100 50 103 Q62 100 62 88 Z"
              fill="rgba(255,255,255,0.45)" stroke="rgba(255,255,255,0.55)" stroke-width="1"/>
            <!-- Cork base -->
            <ellipse cx="50" cy="106" rx="13" ry="6" fill="rgba(255,255,255,0.38)"/>
            <ellipse cx="50" cy="104" rx="10" ry="4.5" fill="rgba(255,255,255,0.5)"/>
          </g>
        </svg>
      </div>
      <!-- Right side circle deco -->
      <div class="header-bg-deco"></div>
      <div class="header-top">
        <div class="header-user" @click="goToProfile" style="cursor: pointer;" title="Xem trang cá nhân">
          <div class="user-avatar-wrapper">
            <img
              src="https://ui-avatars.com/api/?name=DNH&background=ffffff&color=16a34a&size=44&bold=true"
              alt="avatar"
              class="user-avatar"
            />
          </div>
          <div class="user-text">
            <span class="user-date">{{ dateStr }}</span>
            <span class="user-name">Đinh Ngọc Huy</span>
          </div>
        </div>
        <div class="header-actions">
          <button class="hdr-btn" title="Tiếng Việt">
            <span class="flag-icon">🇻🇳</span>
          </button>
          <router-link to="/admin" class="hdr-btn admin-link-btn" title="Vào trang Quản trị (Admin)">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 14.93V17a1 1 0 0 1-2 0v-.07A7.003 7.003 0 0 1 5.07 11H5a1 1 0 0 1 0-2h.07A7.003 7.003 0 0 1 11 5.07V5a1 1 0 0 1 2 0v.07A7.003 7.003 0 0 1 18.93 11H19a1 1 0 0 1 0 2h-.07A7.003 7.003 0 0 1 13 16.93z"/>
            </svg>
          </router-link>
          <button class="hdr-btn notif-btn" title="Thông báo">
            <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
            <span class="notif-dot"></span>
          </button>
        </div>
      </div>

      <!-- Search bar -->
      <div class="search-row">
        <div class="search-input-wrap">
          <svg class="search-icon-svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Tìm kiếm"
            class="search-input"
          />
        </div>
        <button class="filter-btn" title="Lọc">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/>
          </svg>
        </button>
      </div>

      <!-- Quick nav tabs -->
      <div class="quick-nav">
        <button class="quick-nav-btn" :class="{ active: activeFilter === 'map' }" @click="router.push('/map')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>
            <line x1="9" y1="3" x2="9" y2="18"/>
            <line x1="15" y1="6" x2="15" y2="21"/>
          </svg>
          Bản đồ
        </button>
        <button class="quick-nav-btn" :class="{ active: activeFilter === 'booked' }" @click="activeFilter = 'booked'">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="9 11 12 14 22 4"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
          </svg>
          Sân đã đặt
        </button>
        <button class="quick-nav-btn fav-tab" :class="{ active: activeFilter === 'fav' }" @click="activeFilter = activeFilter === 'fav' ? 'all' : 'fav'">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
          Yêu thích ({{ favorites.size }})
        </button>
      </div>

      <!-- Sports Quick Filter Chips (Alobo Style) -->
      <div class="sports-chip-row">
        <button
          class="sport-filter-chip"
          :class="{ active: currentSportFilter === 'all' }"
          @click="currentSportFilter = 'all'"
        >
          🏆 Tất cả ({{ venues.length }})
        </button>
        <button
          class="sport-filter-chip"
          :class="{ active: currentSportFilter === 'pickleball' }"
          @click="currentSportFilter = 'pickleball'"
        >
          🎾 Pickleball
        </button>
        <button
          class="sport-filter-chip"
          :class="{ active: currentSportFilter === 'badminton' }"
          @click="currentSportFilter = 'badminton'"
        >
          🏸 Cầu lông
        </button>
        <button
          class="sport-filter-chip"
          :class="{ active: currentSportFilter === 'football' }"
          @click="currentSportFilter = 'football'"
        >
          ⚽ Bóng đá
        </button>
        <button
          class="sport-filter-chip"
          :class="{ active: currentSportFilter === 'tennis' }"
          @click="currentSportFilter = 'tennis'"
        >
          🎾 Quần vợt
        </button>
      </div>

      <!-- District Filter Horizontal Scroll (Hà Nội Districts) -->
      <div class="district-chip-row">
        <span class="district-label">Khu vực:</span>
        <button
          v-for="d in districts"
          :key="d"
          class="district-chip"
          :class="{ active: currentDistrict === d || (d === 'Tất cả quận' && currentDistrict === 'all') }"
          @click="currentDistrict = (d === 'Tất cả quận' ? 'all' : d)"
        >
          {{ d }}
        </button>
      </div>
    </header>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="main-scroll">
      <div class="venue-grid">
        <div
          v-for="venue in filteredVenues"
          :key="venue.id"
          class="venue-card"
        >
          <!-- Card image area -->
          <div class="card-img-wrapper">
            <img :src="venue.image" :alt="venue.name" class="card-img" loading="lazy" />

            <!-- Tags top-left -->
            <div class="card-tags">
              <span v-if="venue.rating" class="tag-rating">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="#facc15" stroke="none">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
                {{ venue.rating }}
              </span>
              <span v-for="tag in venue.tags" :key="tag" class="tag-label" :class="tag === 'Sự kiện' ? 'tag-pink' : 'tag-green'">
                {{ tag }}
              </span>
            </div>

            <!-- Action buttons top-right -->
            <div class="card-actions">
              <button
                class="card-action-btn"
                :class="{ favorited: favorites.has(venue.id) }"
                @click.stop="toggleFavorite(venue.id)"
                :title="favorites.has(venue.id) ? 'Bỏ yêu thích' : 'Yêu thích'"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" :fill="favorites.has(venue.id) ? '#ef4444' : 'none'" stroke="currentColor" stroke-width="2.2">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
              </button>
              <button class="card-action-btn" title="Chia sẻ">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                  <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                  <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                </svg>
              </button>
            </div>
          </div>

          <!-- Card body -->
          <div class="card-body">
            <div class="card-info-row">
              <img :src="venue.logo" :alt="venue.name" class="venue-logo" />
              <div class="card-text">
                <h3 class="venue-name">{{ venue.name }}</h3>
                <p class="venue-distance">
                  <span class="distance-badge">{{ venue.distance }}</span>
                  {{ venue.address }}
                </p>
                <div class="venue-meta-line">
                  <p class="venue-hours">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <circle cx="12" cy="12" r="10"/>
                      <polyline points="12 6 12 12 16 14"/>
                    </svg>
                    {{ venue.hours }}
                  </p>
                  <span v-if="venue.price" class="venue-price-pill">{{ venue.price }}</span>
                </div>
              </div>
              <button class="book-btn" @click.stop="openBookingModal(venue)">ĐẶT LỊCH</button>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- BOOKING MODAL (Kết nối Firestore alobooking-b2484) -->
    <div v-if="selectedVenueForBooking" class="booking-modal-overlay" @click.self="closeBookingModal">
      <div class="booking-modal-card">
        <div class="bmodal-header">
          <div>
            <h3>Đặt sân trực tuyến</h3>
            <span class="bmodal-subtitle">{{ selectedVenueForBooking.name }}</span>
          </div>
          <button class="bmodal-close" @click="closeBookingModal">✕</button>
        </div>

        <div v-if="bookingSuccessMsg" class="bmodal-success">
          {{ bookingSuccessMsg }}
        </div>

        <form v-else @submit.prevent="handleConfirmBooking" class="bmodal-body">
          <div class="bform-group">
            <label>Họ và tên khách hàng</label>
            <input v-model="bookingCustomerName" type="text" required placeholder="Nhập họ tên" />
          </div>

          <div class="bform-group">
            <label>Số điện thoại liên hệ</label>
            <input v-model="bookingCustomerPhone" type="tel" required placeholder="039xxxxxxx" />
          </div>

          <div class="bform-row">
            <div class="bform-group">
              <label>Ngày đặt sân</label>
              <input v-model="bookingDate" type="date" required />
            </div>

            <div class="bform-group">
              <label>Khung giờ</label>
              <select v-model="bookingTimeSlot">
                <option value="06:00 - 07:30">06:00 - 07:30 (Sáng sớm)</option>
                <option value="08:00 - 09:30">08:00 - 09:30 (Sáng)</option>
                <option value="16:00 - 17:30">16:00 - 17:30 (Chiều)</option>
                <option value="17:30 - 19:00">17:30 - 19:00 (Giờ vàng)</option>
                <option value="19:00 - 20:30">19:00 - 20:30 (Giờ cao điểm)</option>
                <option value="20:30 - 22:00">20:30 - 22:00 (Tối)</option>
              </select>
            </div>
          </div>

          <div class="bmodal-pricing">
            <span>Giá dự kiến:</span>
            <strong>{{ selectedVenueForBooking.price }}</strong>
          </div>

          <div class="bmodal-note">
            🔥 Đơn đặt sẽ được lưu trực tiếp vào <strong>Firestore alobooking-b2484</strong>.
          </div>

          <button type="submit" class="bmodal-submit-btn" :disabled="isBookingSubmitting">
            {{ isBookingSubmitting ? 'Đang tạo đơn...' : 'XÁC NHẬN ĐẶT SÂN' }}
          </button>
        </form>
      </div>
    </div>

    <!-- ===== BOTTOM NAV ===== -->
    <nav class="bottom-nav">
      <button
        v-for="item in navItems"
        :key="item.key"
        class="bnav-item"
        :class="{ active: activeTab === item.key }"
        @click="handleNavClick(item.key)"
      >
        <!-- Home icon -->
        <template v-if="item.icon === 'home'">
          <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
            <polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
        </template>
        <!-- Map icon -->
        <template v-if="item.icon === 'map'">
          <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>
            <line x1="9" y1="3" x2="9" y2="18"/>
            <line x1="15" y1="6" x2="15" y2="21"/>
          </svg>
        </template>
        <!-- Explore icon (special center) -->
        <template v-if="item.icon === 'explore'">
          <div class="explore-circle" :class="{ active: activeTab === 'explore' }">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="3" width="7" height="7"/>
              <rect x="14" y="3" width="7" height="7"/>
              <rect x="14" y="14" width="7" height="7"/>
              <rect x="3" y="14" width="7" height="7"/>
            </svg>
          </div>
        </template>
        <!-- Highlight icon -->
        <template v-if="item.icon === 'highlight'">
          <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
            <circle cx="9" cy="7" r="4"/>
            <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
            <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
          </svg>
        </template>
        <!-- Account icon -->
        <template v-if="item.icon === 'account'">
          <svg class="bnav-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
        </template>
        <span class="bnav-label">{{ item.label }}</span>
      </button>
    </nav>

  </div>
</template>

<style scoped>
/* ===========================
   RESET & SHELL
   =========================== */
.app-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  width: 100%;
  background: #f0f4f0;
  font-family: 'Inter', sans-serif;
  overflow: hidden;
}

/* ===========================
   HEADER
   =========================== */
.app-header {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 55%, #166534 100%);
  padding: 0 16px;
  position: relative;
  z-index: 10;
  flex-shrink: 0;
  box-shadow: 0 4px 24px rgba(22, 163, 74, 0.4);
  overflow: hidden;
}

.header-bg-deco {
  position: absolute;
  top: -60px;
  right: -60px;
  width: 220px;
  height: 220px;
  background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
  border-radius: 50%;
  pointer-events: none;
}

.header-bg-deco::after {
  content: '';
  position: absolute;
  bottom: -120px;
  left: -80px;
  width: 180px;
  height: 180px;
  background: radial-gradient(circle, rgba(255,255,255,0.06) 0%, transparent 70%);
  border-radius: 50%;
}

/* Shuttlecock decoration */
.shuttlecock-deco {
  position: absolute;
  top: 0;
  left: 0;
  width: 160px;
  height: 160px;
  pointer-events: none;
  opacity: 1;
  z-index: 0;
  animation: shuttle-float 6s ease-in-out infinite;
}

.shuttlecock-deco svg {
  width: 100%;
  height: 100%;
  filter: drop-shadow(0 3px 10px rgba(0,0,0,0.3));
}

@keyframes shuttle-float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-4px) rotate(2deg); }
}

.header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 0 12px;
  position: relative;
  z-index: 1;
}

.header-user {
  display: flex;
  align-items: center;
  gap: 11px;
}

.user-avatar-wrapper {
  width: 46px;
  height: 46px;
  border-radius: 50%;
  padding: 2px;
  background: linear-gradient(135deg, rgba(255,255,255,0.6), rgba(255,255,255,0.2));
  box-shadow: 0 3px 14px rgba(0,0,0,0.25);
  flex-shrink: 0;
}

.user-avatar {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid rgba(255,255,255,0.9);
}

.user-text {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.user-date {
  font-size: 0.72rem;
  color: rgba(255,255,255,0.78);
  font-weight: 400;
  letter-spacing: 0.01em;
}

.user-name {
  font-size: 1.05rem;
  font-weight: 700;
  color: #ffffff;
  letter-spacing: -0.01em;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.hdr-btn {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: rgba(255,255,255,0.16);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  border: 1.5px solid rgba(255,255,255,0.22);
  cursor: pointer;
  transition: all 0.2s ease;
  backdrop-filter: blur(8px);
}

.hdr-btn:hover {
  background: rgba(255,255,255,0.26);
  transform: scale(1.05);
}

.flag-icon {
  font-size: 1.25rem;
  line-height: 1;
}

.notif-btn { position: relative; }

.notif-dot {
  position: absolute;
  top: 7px;
  right: 7px;
  width: 8px;
  height: 8px;
  background: #fbbf24;
  border-radius: 50%;
  border: 2px solid rgba(22, 163, 74, 0.9);
  animation: pulse-dot 2s infinite;
}

@keyframes pulse-dot {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.3); opacity: 0.8; }
}

/* SEARCH ROW */
.search-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-bottom: 12px;
  position: relative;
  z-index: 1;
}

.search-input-wrap {
  flex: 1;
  display: flex;
  align-items: center;
  background: rgba(255,255,255,0.96);
  border-radius: 28px;
  padding: 10px 16px;
  gap: 9px;
  box-shadow: 0 2px 16px rgba(0,0,0,0.18);
  transition: box-shadow 0.25s ease;
}

.search-input-wrap:focus-within {
  box-shadow: 0 4px 24px rgba(0,0,0,0.22);
}

.search-icon-svg {
  color: #9ca3af;
  flex-shrink: 0;
}

.search-input {
  border: none;
  outline: none;
  background: transparent;
  font-size: 0.9rem;
  color: #374151;
  width: 100%;
  font-family: 'Inter', sans-serif;
}

.search-input::placeholder { color: #9ca3af; }

.filter-btn {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  background: rgba(255,255,255,0.16);
  border: 1.5px solid rgba(255,255,255,0.28);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  flex-shrink: 0;
}

.filter-btn:hover {
  background: rgba(255,255,255,0.26);
}

/* QUICK NAV */
.quick-nav {
  display: flex;
  gap: 8px;
  padding-bottom: 14px;
}

.quick-nav-btn {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 7px 14px;
  border-radius: 22px;
  font-size: 0.8rem;
  font-weight: 600;
  color: rgba(255,255,255,0.85);
  background: rgba(255,255,255,0.12);
  border: 1.5px solid rgba(255,255,255,0.2);
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
  font-family: 'Inter', sans-serif;
}

.quick-nav-btn:hover {
  background: rgba(255,255,255,0.2);
  color: #fff;
}

.quick-nav-btn.active {
  background: rgba(255,255,255,0.95);
  color: #15803d;
  border-color: transparent;
  box-shadow: 0 3px 12px rgba(0,0,0,0.18);
}

.fav-tab svg { color: rgba(255,255,255,0.85); }
.fav-tab.active svg { color: #ef4444; }

/* SPORTS FILTER CHIPS ROW */
.sports-chip-row {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  padding-bottom: 12px;
  scrollbar-width: none;
}

.sports-chip-row::-webkit-scrollbar {
  display: none;
}

.sport-filter-chip {
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 0.78rem;
  font-weight: 600;
  color: #ffffff;
  background: rgba(255, 255, 255, 0.16);
  border: 1px solid rgba(255, 255, 255, 0.25);
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s ease;
  font-family: 'Inter', sans-serif;
}

.sport-filter-chip:hover {
  background: rgba(255, 255, 255, 0.28);
}

.sport-filter-chip.active {
  background: #ffffff;
  color: #15803d;
  font-weight: 700;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
  border-color: #ffffff;
}

/* VENUE META LINE & PRICE PILL */
.venue-meta-line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  margin-top: 2px;
}

.venue-price-pill {
  font-size: 0.7rem;
  font-weight: 700;
  color: #15803d;
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  padding: 2px 7px;
  border-radius: 12px;
  white-space: nowrap;
}

/* DISTRICT CHIP ROW */
.district-chip-row {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow-x: auto;
  padding-bottom: 12px;
  scrollbar-width: none;
}

.district-chip-row::-webkit-scrollbar {
  display: none;
}

.district-label {
  font-size: 0.75rem;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.9);
  white-space: nowrap;
}

.district-chip {
  padding: 4px 11px;
  border-radius: 16px;
  font-size: 0.74rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.9);
  background: rgba(0, 0, 0, 0.18);
  border: 1px solid rgba(255, 255, 255, 0.18);
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s ease;
  font-family: 'Inter', sans-serif;
}

.district-chip:hover {
  background: rgba(255, 255, 255, 0.2);
}

.district-chip.active {
  background: #facc15;
  color: #1c1917;
  font-weight: 700;
  border-color: #facc15;
}

/* ===========================
   MAIN SCROLL
   =========================== */
.main-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 14px 20px 8px;
  background: #f0f4f0;
}

.main-scroll::-webkit-scrollbar { width: 4px; }
.main-scroll::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.12); border-radius: 4px; }

/* ===========================
   VENUE GRID
   =========================== */
.venue-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
  max-width: 1800px;
}

/* ===========================
   VENUE CARD
   =========================== */
.venue-card {
  background: #ffffff;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  transition: transform 0.22s ease, box-shadow 0.22s ease;
  cursor: pointer;
}

.venue-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 28px rgba(0,0,0,0.14);
}

/* Image */
.card-img-wrapper {
  position: relative;
  height: 118px;
  overflow: hidden;
}

.card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.4s ease;
}

.venue-card:hover .card-img {
  transform: scale(1.07);
}

/* Tags */
.card-tags {
  position: absolute;
  top: 7px;
  left: 7px;
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
}

.tag-label {
  font-size: 0.62rem;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 10px;
  letter-spacing: 0.01em;
}

.tag-green {
  background: #16a34a;
  color: #fff;
}

.tag-pink {
  background: #ec4899;
  color: #fff;
}

.tag-rating {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 0.62rem;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 10px;
  background: rgba(255,255,255,0.92);
  color: #374151;
}

/* Action buttons (heart, share) */
.card-actions {
  position: absolute;
  top: 7px;
  right: 7px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.card-action-btn {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: rgba(255,255,255,0.9);
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  color: #6b7280;
  box-shadow: 0 1px 6px rgba(0,0,0,0.15);
}

.card-action-btn:hover {
  background: #fff;
  transform: scale(1.12);
}

.card-action-btn.favorited {
  color: #ef4444;
}

/* Card body */
.card-body {
  padding: 9px 10px 11px;
}

.card-info-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.venue-logo {
  width: 34px;
  height: 34px;
  border-radius: 8px;
  object-fit: cover;
  flex-shrink: 0;
  box-shadow: 0 1px 6px rgba(0,0,0,0.14);
}

.card-text {
  flex: 1;
  min-width: 0;
}

.venue-name {
  font-size: 0.77rem;
  font-weight: 700;
  color: #111827;
  line-height: 1.3;
  margin-bottom: 3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.venue-distance {
  font-size: 0.67rem;
  color: #6b7280;
  line-height: 1.4;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 3px;
}

.distance-badge {
  display: inline-block;
  background: #dcfce7;
  color: #15803d;
  font-weight: 700;
  font-size: 0.6rem;
  padding: 1px 5px;
  border-radius: 5px;
  margin-right: 3px;
}

.venue-hours {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 0.67rem;
  color: #6b7280;
}

/* Book button */
.book-btn {
  flex-shrink: 0;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: #fff;
  font-size: 0.6rem;
  font-weight: 800;
  padding: 7px 9px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  letter-spacing: 0.03em;
  box-shadow: 0 2px 10px rgba(245, 158, 11, 0.45);
  white-space: nowrap;
  align-self: center;
  font-family: 'Inter', sans-serif;
}

.book-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 16px rgba(245, 158, 11, 0.55);
  background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
}

.book-btn:active {
  transform: translateY(0);
}

/* ===========================
   BOTTOM NAV
   =========================== */
.bottom-nav {
  display: flex;
  align-items: stretch;
  background: #fff;
  border-top: 1px solid #e5e7eb;
  box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
  flex-shrink: 0;
  height: 62px;
  z-index: 20;
}

.bnav-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  color: #9ca3af;
  cursor: pointer;
  transition: color 0.2s ease;
  border: none;
  background: transparent;
  padding: 0;
  position: relative;
  font-family: 'Inter', sans-serif;
}

.bnav-item:hover {
  color: #6b7280;
}

.bnav-item.active {
  color: #16a34a;
}

.bnav-item.active::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 30px;
  height: 3px;
  background: #16a34a;
  border-radius: 0 0 4px 4px;
}

.bnav-icon {
  transition: transform 0.2s ease;
}

.bnav-item:hover .bnav-icon {
  transform: translateY(-2px);
}

.bnav-item.active .bnav-icon {
  transform: scale(1.1);
}

/* Explore center button */
.explore-circle {
  width: 46px;
  height: 46px;
  border-radius: 50%;
  background: #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: -18px;
  border: 3px solid #fff;
  box-shadow: 0 3px 12px rgba(0,0,0,0.15);
  transition: all 0.2s ease;
  color: #6b7280;
}

.explore-circle.active {
  background: linear-gradient(135deg, #16a34a, #15803d);
  color: #fff;
  box-shadow: 0 4px 18px rgba(22, 163, 74, 0.5);
}

.bnav-label {
  font-size: 0.63rem;
  font-weight: 500;
  line-height: 1;
}

/* ===========================
   RESPONSIVE
   =========================== */

/* Very large desktop ≥ 1600px */
@media (min-width: 1600px) {
  .venue-grid {
    grid-template-columns: repeat(6, 1fr);
  }
  .main-scroll {
    padding: 20px 40px 12px;
  }
  .app-header {
    padding: 0 40px;
  }
}

/* Large desktop 1200–1599px */
@media (min-width: 1200px) and (max-width: 1599px) {
  .venue-grid {
    grid-template-columns: repeat(5, 1fr);
  }
  .main-scroll {
    padding: 16px 32px 10px;
  }
  .app-header {
    padding: 0 32px;
  }
}

/* Medium desktop 900–1199px */
@media (min-width: 900px) and (max-width: 1199px) {
  .venue-grid {
    grid-template-columns: repeat(4, 1fr);
  }
  .main-scroll {
    padding: 14px 24px 8px;
  }
  .app-header {
    padding: 0 24px;
  }
}

/* Tablet 620–899px */
@media (min-width: 620px) and (max-width: 899px) {
  .venue-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}

/* Small tablet 440–619px */
@media (max-width: 619px) {
  .venue-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 440px) {
  .venue-grid {
    grid-template-columns: 1fr;
  }
  .quick-nav {
    overflow-x: auto;
    padding-bottom: 12px;
    scrollbar-width: none;
  }
  .quick-nav::-webkit-scrollbar { display: none; }
}

/* =======================================================
   BOOKING MODAL STYLES (Firestore Alobooking)
   ======================================================= */
.booking-modal-overlay {
  position: fixed;
  inset: 0;
  background-color: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(6px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  animation: fadeIn 0.2s ease;
}

.booking-modal-card {
  background: #1e293b;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 16px;
  width: 100%;
  max-width: 480px;
  padding: 1.5rem;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
}

.bmodal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1.25rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding-bottom: 0.75rem;
}

.bmodal-header h3 {
  font-size: 1.2rem;
  font-weight: 700;
  color: #fff;
  margin: 0;
}

.bmodal-subtitle {
  font-size: 0.85rem;
  color: #38bdf8;
  display: block;
  margin-top: 0.2rem;
}

.bmodal-close {
  background: none;
  border: none;
  color: #94a3b8;
  font-size: 1.2rem;
  cursor: pointer;
  padding: 0.2rem 0.5rem;
  border-radius: 6px;
}

.bmodal-close:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.bmodal-success {
  background: rgba(16, 185, 129, 0.15);
  border: 1px solid rgba(16, 185, 129, 0.3);
  color: #34d399;
  padding: 1rem;
  border-radius: 10px;
  font-size: 0.95rem;
  font-weight: 500;
  text-align: center;
}

.bmodal-body {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.bform-group {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  flex: 1;
}

.bform-group label {
  font-size: 0.82rem;
  font-weight: 600;
  color: #94a3b8;
}

.bform-group input,
.bform-group select {
  background: rgba(15, 23, 42, 0.8);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #f8fafc;
  padding: 0.65rem 0.85rem;
  border-radius: 8px;
  font-size: 0.9rem;
  outline: none;
  transition: all 0.2s;
}

.bform-group input:focus,
.bform-group select:focus {
  border-color: #38bdf8;
  box-shadow: 0 0 0 2px rgba(56, 189, 248, 0.2);
}

.bform-row {
  display: flex;
  gap: 0.75rem;
}

.bmodal-pricing {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(255, 255, 255, 0.05);
  padding: 0.75rem 1rem;
  border-radius: 8px;
  font-size: 0.9rem;
  color: #cbd5e1;
}

.bmodal-pricing strong {
  color: #f59e0b;
  font-size: 1.05rem;
}

.bmodal-note {
  font-size: 0.78rem;
  color: #94a3b8;
  background: rgba(245, 158, 11, 0.1);
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  border: 1px dashed rgba(245, 158, 11, 0.3);
}

.bmodal-submit-btn {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: #fff;
  border: none;
  padding: 0.85rem;
  border-radius: 10px;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.bmodal-submit-btn:hover {
  opacity: 0.92;
  transform: translateY(-1px);
}
</style>
