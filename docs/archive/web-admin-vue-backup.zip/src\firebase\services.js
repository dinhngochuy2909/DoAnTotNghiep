import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore'
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth'
import { db, auth, googleProvider } from './config'
import { initialVenues } from '../data/venues'

/* ==========================================================================
   1. AUTHENTICATION SERVICES (Xác thực người dùng)
   ========================================================================== */

/**
 * Đăng nhập bằng Email và Password
 */
export async function loginWithEmail(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    return { success: true, user: userCredential.user }
  } catch (error) {
    console.error('Firebase Auth Error:', error)
    return { success: false, error: error.message }
  }
}

/**
 * Đăng ký tài khoản mới bằng Email và Password
 */
export async function registerWithEmail(email, password, displayName = '') {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user
    
    // Lưu thông tin người dùng vào Firestore collection 'users'
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email: user.email,
      displayName: displayName || email.split('@')[0],
      role: 'customer',
      createdAt: serverTimestamp()
    })
    
    return { success: true, user }
  } catch (error) {
    console.error('Firebase Register Error:', error)
    return { success: false, error: error.message }
  }
}

/**
 * Đăng nhập nhanh bằng tài khoản Google
 */
export async function loginWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider)
    const user = result.user
    
    // Lưu hoặc cập nhật user vào Firestore
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      lastLogin: serverTimestamp()
    }, { merge: true })

    return { success: true, user }
  } catch (error) {
    console.error('Google Sign In Error:', error)
    return { success: false, error: error.message }
  }
}

/**
 * Đăng xuất
 */
export async function logoutUser() {
  try {
    await signOut(auth)
    localStorage.removeItem('isAuthenticated')
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

/**
 * Theo dõi trạng thái đăng nhập
 */
export function subscribeAuthState(callback) {
  return onAuthStateChanged(auth, callback)
}

/* ==========================================================================
   2. VENUES & COURTS SERVICES (Quản lý Sân thể thao)
   ========================================================================== */

const VENUES_COLLECTION = 'venues'

/**
 * Lấy danh sách sân từ Firestore (nếu chưa có thì lấy từ venues.js local)
 */
export async function getVenues() {
  try {
    const querySnapshot = await getDocs(collection(db, VENUES_COLLECTION))
    if (querySnapshot.empty) {
      console.log('Firestore venues collection trống, sử dụng dữ liệu mặc định.')
      return initialVenues
    }
    const venues = []
    querySnapshot.forEach(doc => {
      venues.push({ id: doc.id, ...doc.data() })
    })
    return venues
  } catch (error) {
    console.warn('Không thể tải từ Firestore (sử dụng fallback local):', error)
    return initialVenues
  }
}

/**
 * Đồng bộ toàn bộ dữ liệu sân local (venues.js) lên Firestore với 1 click!
 */
export async function syncVenuesToFirestore() {
  try {
    let count = 0
    for (const venue of initialVenues) {
      const docRef = doc(db, VENUES_COLLECTION, String(venue.id))
      await setDoc(docRef, {
        ...venue,
        updatedAt: serverTimestamp()
      }, { merge: true })
      count++
    }
    return { success: true, count }
  } catch (error) {
    console.error('Lỗi khi đồng bộ lên Firestore:', error)
    return { success: false, error: error.message }
  }
}

/**
 * Thêm một sân thể thao mới lên Firestore
 */
export async function addVenue(venueData) {
  try {
    const docRef = await addDoc(collection(db, VENUES_COLLECTION), {
      ...venueData,
      createdAt: serverTimestamp()
    })
    return { success: true, id: docRef.id }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

/**
 * Cập nhật thông tin sân
 */
export async function updateVenue(venueId, venueData) {
  try {
    const docRef = doc(db, VENUES_COLLECTION, String(venueId))
    await updateDoc(docRef, {
      ...venueData,
      updatedAt: serverTimestamp()
    })
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

/**
 * Xóa sân
 */
export async function deleteVenue(venueId) {
  try {
    await deleteDoc(doc(db, VENUES_COLLECTION, String(venueId)))
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}

/* ==========================================================================
   3. BOOKINGS SERVICES (Quản lý Đơn Đặt Sân Realtime)
   ========================================================================== */

const BOOKINGS_COLLECTION = 'bookings'

/**
 * Tạo đơn đặt sân mới lên Firestore
 */
export async function createBooking(bookingData) {
  try {
    const docRef = await addDoc(collection(db, BOOKINGS_COLLECTION), {
      ...bookingData,
      status: bookingData.status || 'pending',
      createdAt: serverTimestamp()
    })
    return { success: true, id: docRef.id }
  } catch (error) {
    console.error('Lỗi tạo đơn đặt sân:', error)
    return { success: false, error: error.message }
  }
}

/**
 * Lắng nghe realtime danh sách đơn đặt sân (Realtime Firestore listener)
 */
export function onBookingsChange(callback) {
  try {
    const q = query(collection(db, BOOKINGS_COLLECTION), orderBy('createdAt', 'desc'))
    return onSnapshot(q, (snapshot) => {
      const bookings = []
      snapshot.forEach(doc => {
        bookings.push({ id: doc.id, ...doc.data() })
      })
      callback(bookings)
    }, (error) => {
      console.warn('Lỗi lắng nghe bookings realtime:', error)
    })
  } catch (error) {
    console.warn('Lỗi khởi tạo listener bookings:', error)
    return () => {}
  }
}

/**
 * Cập nhật trạng thái đơn đặt sân (pending -> confirmed -> completed / cancelled)
 */
export async function updateBookingStatus(bookingId, newStatus) {
  try {
    const docRef = doc(db, BOOKINGS_COLLECTION, String(bookingId))
    await updateDoc(docRef, {
      status: newStatus,
      updatedAt: serverTimestamp()
    })
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
}
