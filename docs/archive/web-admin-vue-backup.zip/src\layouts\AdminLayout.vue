<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { LayoutDashboard, Map, CalendarDays, Users, CreditCard, LogOut, Search, Bell, Settings } from 'lucide-vue-next'

const route = useRoute()
const router = useRouter()
const currentTitle = computed(() => route.meta.title || 'Quản trị')

const menuItems = [
  { name: 'Dashboard', path: '/admin', icon: LayoutDashboard },
  { name: 'Quản lý Sân', path: '/admin/fields', icon: Map },
  { name: 'Quản lý Lịch Đặt', path: '/admin/bookings', icon: CalendarDays },
  { name: 'Khách Hàng', path: '/admin/customers', icon: Users },
  { name: 'Thanh Toán', path: '/admin/payments', icon: CreditCard },
]

const handleLogout = () => {
  localStorage.removeItem('isAuthenticated')
  router.push('/login')
}
</script>

<template>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="logo">
          <div class="logo-icon-wrapper">
            <span class="logo-icon">⚽</span>
          </div>
          <h2>SportAI <span class="text-gradient">Admin</span></h2>
        </div>
      </div>

      <nav class="sidebar-nav">
        <p class="nav-label">QUẢN LÝ CHÍNH</p>
        <ul>
          <li v-for="item in menuItems" :key="item.path">
            <router-link :to="item.path" class="nav-link" active-class="active">
              <component :is="item.icon" class="nav-icon" :size="20" />
              <span>{{ item.name }}</span>
              <div v-if="route.path === item.path" class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </nav>

      <div class="sidebar-footer">
        <router-link to="/" class="nav-link user-app-btn">
          <span style="font-size: 16px;">📱</span>
          <span>Xem giao diện người dùng</span>
        </router-link>
        <button class="nav-link settings-btn">
          <Settings class="nav-icon" :size="20" />
          <span>Cài đặt hệ thống</span>
        </button>
        <button @click="handleLogout" class="nav-link logout-btn">
          <LogOut class="nav-icon" :size="20" />
          <span>Đăng xuất</span>
        </button>
      </div>
    </aside>

    <main class="main-content">
      <header class="topbar">
        <div class="page-title">
          <h1>{{ currentTitle }}</h1>
          <p class="page-subtitle">Quản lý và theo dõi số liệu hôm nay</p>
        </div>
        
        <div class="topbar-actions">
          <div class="search-bar">
            <Search class="search-icon" :size="16" />
            <input type="text" placeholder="Tìm kiếm nhanh (Ctrl+K)..." />
            <kbd class="shortcut-key">⌘K</kbd>
          </div>
          
          <div class="action-divider"></div>

          <button class="icon-btn action-btn">
            <Bell :size="20" />
            <span class="notification-badge">3</span>
          </button>
          
          <div class="user-profile">
            <div class="avatar-container">
              <img src="https://ui-avatars.com/api/?name=Admin&background=6366f1&color=fff&rounded=true&bold=true" alt="Admin" />
              <div class="status-dot"></div>
            </div>
            <div class="user-info">
              <span class="user-name">Đinh Ngọc Huy</span>
              <span class="user-role">Super Admin</span>
            </div>
          </div>
        </div>
      </header>

      <div class="content-area">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </div>
    </main>
  </div>
</template>

<style scoped>
.admin-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background-color: var(--bg-base);
}

/* Sidebar Styles */
.sidebar {
  width: 270px;
  background-color: var(--bg-panel-solid);
  display: flex;
  flex-direction: column;
  border-right: 1px solid var(--border-color);
  z-index: 20;
}

.sidebar-header {
  padding: 1.5rem;
}

.logo {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.logo-icon-wrapper {
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(99, 102, 241, 0.05));
  padding: 8px;
  border-radius: 12px;
  border: 1px solid rgba(99, 102, 241, 0.2);
}

.logo-icon {
  font-size: 1.25rem;
  display: flex;
}

.logo h2 {
  font-family: 'Outfit', sans-serif;
  font-size: 1.4rem;
}

.nav-label {
  font-size: 0.7rem;
  font-weight: 600;
  color: var(--text-dark);
  margin-bottom: 0.75rem;
  padding: 0 1.5rem;
  letter-spacing: 0.05em;
}

.sidebar-nav {
  flex: 1;
  padding: 1rem 0;
  overflow-y: auto;
}

.sidebar-nav ul {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  padding: 0 0.75rem;
}

.nav-link {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  padding: 0.75rem 1rem;
  border-radius: var(--radius-md);
  color: var(--text-muted);
  font-weight: 500;
  font-size: 0.95rem;
  transition: var(--transition-fast);
  position: relative;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.03);
  color: var(--text-main);
}

.nav-link.active {
  background-color: rgba(99, 102, 241, 0.1);
  color: var(--primary-color);
}

.active-indicator {
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  height: 60%;
  width: 3px;
  background-color: var(--primary-color);
  border-radius: 0 4px 4px 0;
  box-shadow: 1px 0 8px var(--primary-glow);
}

.nav-icon {
  opacity: 0.8;
}

.nav-link.active .nav-icon {
  opacity: 1;
}

.sidebar-footer {
  padding: 1.5rem 0.75rem;
  border-top: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.logout-btn:hover {
  color: var(--danger-color);
  background-color: rgba(239, 68, 68, 0.05);
}

/* Main Content */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
}

.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2.5rem;
  z-index: 10;
  background: rgba(9, 9, 11, 0.8);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(255,255,255,0.03);
}

.page-title h1 {
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--text-main);
}

.page-subtitle {
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-top: 0.2rem;
}

.topbar-actions {
  display: flex;
  align-items: center;
  gap: 1.25rem;
}

.search-bar {
  display: flex;
  align-items: center;
  background-color: var(--bg-panel);
  border: 1px solid var(--border-color);
  border-radius: 20px;
  padding: 0.4rem 0.8rem;
  width: 280px;
  transition: var(--transition);
}

.search-bar:focus-within {
  border-color: rgba(99, 102, 241, 0.5);
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
  background-color: rgba(24, 24, 27, 0.9);
}

.search-icon {
  color: var(--text-dark);
  margin-right: 0.5rem;
}

.search-bar input {
  background: none;
  border: none;
  color: var(--text-main);
  outline: none;
  width: 100%;
  font-size: 0.9rem;
}

.shortcut-key {
  font-size: 0.7rem;
  padding: 0.2rem 0.4rem;
  background: rgba(255,255,255,0.1);
  border-radius: 4px;
  color: var(--text-muted);
  font-family: monospace;
}

.action-divider {
  width: 1px;
  height: 24px;
  background-color: var(--border-color);
}

.action-btn {
  position: relative;
  color: var(--text-muted);
  padding: 0.5rem;
  border-radius: 50%;
  border: 1px solid transparent;
}

.action-btn:hover {
  color: var(--text-main);
  background-color: var(--bg-panel);
  border-color: var(--border-color);
}

.notification-badge {
  position: absolute;
  top: 2px;
  right: 2px;
  background-color: var(--primary-color);
  color: white;
  font-size: 0.65rem;
  font-weight: 700;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 0 2px var(--bg-base);
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
  padding: 0.4rem 0.75rem;
  border-radius: var(--radius-md);
  transition: var(--transition-fast);
  border: 1px solid transparent;
}

.user-profile:hover {
  background-color: var(--bg-panel);
  border-color: var(--border-color);
}

.avatar-container {
  position: relative;
}

.avatar-container img {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  box-shadow: var(--shadow-sm);
}

.status-dot {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 10px;
  height: 10px;
  background-color: var(--success-color);
  border-radius: 50%;
  border: 2px solid var(--bg-base);
}

.user-info {
  display: flex;
  flex-direction: column;
}

.user-name {
  font-weight: 500;
  font-size: 0.9rem;
}

.user-role {
  font-size: 0.75rem;
  color: var(--text-muted);
}

.content-area {
  flex: 1;
  padding: 2rem 2.5rem;
  overflow-y: auto;
  z-index: 1;
}
</style>
