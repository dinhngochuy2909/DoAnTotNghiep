import { createRouter, createWebHistory } from 'vue-router'
import AdminLayout from '../layouts/AdminLayout.vue'
import LoginView from '../views/LoginView.vue'
import HomeView from '../views/HomeView.vue'
import DashboardView from '../views/DashboardView.vue'
import FieldManagementView from '../views/FieldManagementView.vue'
import BookingManagementView from '../views/BookingManagementView.vue'
import ProfileView from '../views/ProfileView.vue'
import MapView from '../views/MapView.vue'

import CustomerManagementView from '../views/CustomerManagementView.vue'
import PaymentManagementView from '../views/PaymentManagementView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: LoginView,
      meta: { requiresAuth: false }
    },
    {
      path: '/',
      alias: '/home',
      name: 'home',
      component: HomeView,
      meta: { requiresAuth: false }
    },
    {
      path: '/map',
      name: 'map',
      component: MapView,
      meta: { requiresAuth: false }
    },
    {
      path: '/profile',
      name: 'profile',
      component: ProfileView,
      meta: { requiresAuth: false }
    },
    {
      path: '/admin',
      component: AdminLayout,
      meta: { requiresAuth: true },
      children: [
        {
          path: '',
          name: 'dashboard',
          component: DashboardView,
          meta: { title: 'Dashboard & Thống kê' }
        },
        {
          path: 'fields',
          name: 'fields',
          component: FieldManagementView,
          meta: { title: 'Quản lý Sân' }
        },
        {
          path: 'bookings',
          name: 'bookings',
          component: BookingManagementView,
          meta: { title: 'Quản lý Đặt Sân' }
        },
        {
          path: 'customers',
          name: 'customers',
          component: CustomerManagementView,
          meta: { title: 'Quản lý Khách Hàng' }
        },
        {
          path: 'payments',
          name: 'payments',
          component: PaymentManagementView,
          meta: { title: 'Thanh Toán & Doanh Thu' }
        }
      ]
    }
  ]
})

// Navigation Guard
router.beforeEach((to, from, next) => {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true'

  if (to.meta.requiresAuth && !isAuthenticated) {
    next({ name: 'login' })
  } else if (to.name === 'login' && isAuthenticated) {
    next({ name: 'dashboard' })
  } else {
    next()
  }
})

export default router
