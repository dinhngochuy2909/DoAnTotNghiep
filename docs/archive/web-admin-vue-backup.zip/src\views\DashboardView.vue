<script setup>
import { ref, computed } from 'vue'
import { Line, Bar, Doughnut } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import {
  TrendingUp,
  TrendingDown,
  Users,
  Calendar,
  DollarSign,
  Activity,
  Sparkles,
  MapPin,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  Flame,
  Award
} from 'lucide-vue-next'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

// Thời gian thống kê
const selectedPeriod = ref('month') // 'today' | 'week' | 'month' | 'year'

// 4 Thẻ KPI chính
const kpiStats = computed(() => {
  if (selectedPeriod.value === 'today') {
    return [
      { title: 'Doanh Thu Hôm Nay', value: '4.850.000đ', change: '+18.5%', isPositive: true, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-400/10', sub: 'So với hôm qua' },
      { title: 'Lượt Đặt Hôm Nay', value: '38 đơn', change: '+12.0%', isPositive: true, icon: Calendar, color: 'text-blue-400', bg: 'bg-blue-400/10', sub: '32 đã check-in' },
      { title: 'Sân Đang Hoạt Động', value: '26 / 32 sân', change: '81.2%', isPositive: true, icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-400/10', sub: '6 sân đang trống' },
      { title: 'Khách Hàng Mới', value: '14 người', change: '+25.0%', isPositive: true, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10', sub: 'Đặt qua app Alobooking' },
    ]
  } else if (selectedPeriod.value === 'week') {
    return [
      { title: 'Doanh Thu Tuần Này', value: '32.400.000đ', change: '+14.2%', isPositive: true, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-400/10', sub: 'Vượt mục tiêu 8%' },
      { title: 'Tổng Lượt Đặt Tuần', value: '246 lượt', change: '+9.5%', isPositive: true, icon: Calendar, color: 'text-blue-400', bg: 'bg-blue-400/10', sub: '96% hoàn thành' },
      { title: 'Tỷ Lệ Lấp Đầy TB', value: '84.6%', change: '+6.1%', isPositive: true, icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-400/10', sub: 'Giờ vàng đạt 98%' },
      { title: 'Khách Hàng Mới', value: '62 người', change: '+18.4%', isPositive: true, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10', sub: 'Tỷ lệ quay lại 45%' },
    ]
  } else if (selectedPeriod.value === 'year') {
    return [
      { title: 'Tổng Doanh Thu Năm', value: '582.600.000đ', change: '+34.8%', isPositive: true, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-400/10', sub: 'Tăng trưởng ổn định' },
      { title: 'Tổng Lượt Đặt Năm', value: '4.512 lượt', change: '+28.2%', isPositive: true, icon: Calendar, color: 'text-blue-400', bg: 'bg-blue-400/10', sub: 'Trung bình 376/tháng' },
      { title: 'Cụm Sân Liên Kết', value: '32 cụm sân', change: '+8 sân', isPositive: true, icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-400/10', sub: '12 quận nội thành' },
      { title: 'Tổng Khách Hàng', value: '1.840 người', change: '+42.0%', isPositive: true, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10', sub: 'App Alobooking' },
    ]
  }
  // Default 'month'
  return [
    { title: 'Doanh Thu Tháng Này', value: '128.500.000đ', change: '+16.8%', isPositive: true, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-400/10', sub: 'Vượt 12.5tr so tháng trước' },
    { title: 'Tổng Lượt Đặt Tháng', value: '984 lượt', change: '+11.4%', isPositive: true, icon: Calendar, color: 'text-blue-400', bg: 'bg-blue-400/10', sub: 'Trung bình 32 lượt/ngày' },
    { title: 'Tỷ Lệ Lấp Đầy Sân', value: '86.2%', change: '+5.3%', isPositive: true, icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-400/10', sub: 'Khung 17h-21h kín sân' },
    { title: 'Khách Hàng Mới', value: '215 người', change: '+22.5%', isPositive: true, icon: Users, color: 'text-purple-400', bg: 'bg-purple-400/10', sub: 'Tải app qua mã QR tại sân' },
  ]
})

// Dữ liệu biểu đồ Doanh thu & AI Dự báo
const revenueChartData = computed(() => {
  if (selectedPeriod.value === 'today') {
    return {
      labels: ['06h', '08h', '10h', '12h', '14h', '16h', '18h', '20h', '22h'],
      datasets: [
        {
          label: 'Doanh thu thực tế (triệu VNĐ)',
          data: [0.3, 0.6, 0.4, 0.2, 0.5, 0.9, 1.2, 1.4, 0.8],
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99, 102, 241, 0.15)',
          borderWidth: 3,
          fill: true,
          tension: 0.4
        },
        {
          label: 'Dự báo AI (triệu VNĐ)',
          data: [0.3, 0.5, 0.4, 0.3, 0.4, 0.8, 1.3, 1.5, 0.9],
          borderColor: '#10b981',
          borderDash: [5, 5],
          borderWidth: 2,
          tension: 0.4,
          fill: false
        }
      ]
    }
  } else if (selectedPeriod.value === 'week') {
    return {
      labels: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
      datasets: [
        {
          label: 'Doanh thu thực tế (triệu VNĐ)',
          data: [3.8, 4.2, 3.9, 4.5, 5.2, 6.8, 6.2],
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99, 102, 241, 0.15)',
          borderWidth: 3,
          fill: true,
          tension: 0.4
        },
        {
          label: 'Dự báo AI (triệu VNĐ)',
          data: [3.6, 4.0, 4.1, 4.3, 5.0, 7.2, 6.5],
          borderColor: '#10b981',
          borderDash: [5, 5],
          borderWidth: 2,
          tension: 0.4,
          fill: false
        }
      ]
    }
  }
  return {
    labels: ['Tuần 1', 'Tuần 2', 'Tuần 3', 'Tuần 4'],
    datasets: [
      {
        label: 'Doanh thu thực tế (triệu VNĐ)',
        data: [28.5, 32.1, 31.4, 36.5],
        borderColor: '#6366f1',
        backgroundColor: 'rgba(99, 102, 241, 0.15)',
        borderWidth: 3,
        fill: true,
        tension: 0.4
      },
      {
        label: 'Dự báo AI (triệu VNĐ)',
        data: [27.0, 30.5, 33.0, 38.0],
        borderColor: '#10b981',
        borderDash: [5, 5],
        borderWidth: 2,
        tension: 0.4,
        fill: false
      }
    ]
  }
})

// Dữ liệu biểu đồ Tần suất đặt sân theo môn thể thao
const sportUsageData = {
  labels: ['Pickleball', 'Cầu lông', 'Bóng đá', 'Tennis', 'Bóng rổ'],
  datasets: [
    {
      label: 'Số giờ đặt trong kỳ',
      data: [420, 315, 240, 160, 95],
      backgroundColor: [
        'rgba(59, 130, 246, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(249, 115, 22, 0.8)',
        'rgba(234, 179, 8, 0.8)',
        'rgba(236, 72, 153, 0.8)'
      ],
      borderRadius: 8
    }
  ]
}

// Biểu đồ tròn tỷ trọng doanh thu
const revenueShareData = {
  labels: ['Pickleball (42%)', 'Cầu lông (28%)', 'Bóng đá (18%)', 'Tennis (12%)'],
  datasets: [
    {
      data: [42, 28, 18, 12],
      backgroundColor: ['#3b82f6', '#10b981', '#f97316', '#eab308'],
      borderColor: '#18181b',
      borderWidth: 3
    }
  ]
}

// Biểu đồ giờ cao điểm
const peakHoursData = {
  labels: ['06h-09h (Sáng)', '09h-14h (Trưa)', '14h-17h (Chiều)', '17h-20h (Vàng 🔥)', '20h-23h (Tối muộn)'],
  datasets: [
    {
      label: 'Tỷ lệ lấp đầy (%)',
      data: [65, 42, 58, 98, 88],
      backgroundColor: [
        'rgba(148, 163, 184, 0.5)',
        'rgba(148, 163, 184, 0.4)',
        'rgba(148, 163, 184, 0.6)',
        'rgba(239, 68, 68, 0.85)', // Peak red/orange
        'rgba(99, 102, 241, 0.8)'
      ],
      borderRadius: 6
    }
  ]
}

const baseChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      labels: { color: '#94a3b8', font: { family: 'Inter', size: 12 } }
    }
  },
  scales: {
    y: {
      grid: { color: 'rgba(255, 255, 255, 0.05)' },
      ticks: { color: '#94a3b8' }
    },
    x: {
      grid: { display: false },
      ticks: { color: '#94a3b8' }
    }
  }
}

const doughnutOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom',
      labels: { color: '#cbd5e1', padding: 14, font: { family: 'Inter', size: 12 } }
    }
  },
  cutout: '70%'
}

// Bảng Top Sân Thể Thao Đắt Khách Nhất
const topVenues = [
  { id: 1, name: 'Pickleball Cổng B Ga Hà Nội', sport: 'Pickleball', district: 'Đống Đa', bookings: 168, revenue: '34.200.000đ', rating: 4.9, fillRate: '94%' },
  { id: 2, name: 'Phúc Long Pickleball & Badminton', sport: 'Pickleball', district: 'Đống Đa', bookings: 142, revenue: '28.800.000đ', rating: 4.8, fillRate: '91%' },
  { id: 3, name: 'Sân Cầu Lông Cầu Giấy Arena', sport: 'Cầu lông', district: 'Cầu Giấy', bookings: 128, revenue: '22.400.000đ', rating: 4.8, fillRate: '88%' },
  { id: 4, name: 'Sân Bóng Đá Mini Nam Từ Liêm', sport: 'Bóng đá', district: 'Nam Từ Liêm', bookings: 96, revenue: '26.800.000đ', rating: 4.7, fillRate: '85%' },
  { id: 5, name: 'Tennis Club Ba Đình', sport: 'Tennis', district: 'Ba Đình', bookings: 74, revenue: '18.500.000đ', rating: 4.9, fillRate: '82%' },
]

// Nhật ký hoạt động gần đây
const recentActivities = [
  { id: 1, text: 'Khách Nguyễn Văn An đã đặt Sân Pickleball #2 (18:00 - 19:30)', time: '5 phút trước', status: 'success', badge: 'Đặt sân mới' },
  { id: 2, text: 'Sân Cầu Lông #4 Cầu Giấy đã hoàn thành bảo trì thảm Yonex', time: '28 phút trước', status: 'info', badge: 'Bảo trì xong' },
  { id: 3, text: 'Admin đã duyệt thanh toán đơn #BK-1030 chuyển khoản 350.000đ', time: '1 giờ trước', status: 'success', badge: 'Thanh toán' },
  { id: 4, text: 'Hệ thống AI đề xuất tăng 10% giá khung giờ 18h-20h thứ 7 tới', time: '3 giờ trước', status: 'warning', badge: 'AI Alert' },
  { id: 5, text: 'Khách Lê Hoàng Nam check-in sân bóng đá mini 7 người', time: '4 giờ trước', status: 'neutral', badge: 'Check-in' },
]
</script>

<template>
  <div class="dashboard">
    <!-- TOP TOOLBAR: TIÊU ĐỀ & CHỌN MỐC THỜI GIAN -->
    <div class="dashboard-toolbar glass-panel">
      <div class="toolbar-left">
        <h2>Tổng Quan Hoạt Động & Báo Cáo Thống Kê</h2>
        <p class="toolbar-sub">Dữ liệu thời gian thực được đồng bộ tự động từ app Alobooking & Firestore</p>
      </div>

      <div class="period-toggle-group">
        <button
          :class="['period-btn', { active: selectedPeriod === 'today' }]"
          @click="selectedPeriod = 'today'"
        >
          Hôm nay
        </button>
        <button
          :class="['period-btn', { active: selectedPeriod === 'week' }]"
          @click="selectedPeriod = 'week'"
        >
          7 ngày qua
        </button>
        <button
          :class="['period-btn', { active: selectedPeriod === 'month' }]"
          @click="selectedPeriod = 'month'"
        >
          Tháng này
        </button>
        <button
          :class="['period-btn', { active: selectedPeriod === 'year' }]"
          @click="selectedPeriod = 'year'"
        >
          Năm nay
        </button>
      </div>
    </div>

    <!-- STATS KPI GRID (4 THẺ CHÍNH) -->
    <div class="stats-grid">
      <div v-for="(stat, index) in kpiStats" :key="index" class="stat-card glass-panel">
        <div class="stat-header">
          <div class="stat-icon-wrapper" :class="stat.bg">
            <component :is="stat.icon" :class="stat.color" :size="24" />
          </div>
          <span class="stat-change" :class="stat.isPositive ? 'positive' : 'negative'">
            <TrendingUp v-if="stat.isPositive" :size="15" />
            <TrendingDown v-else :size="15" />
            {{ stat.change }}
          </span>
        </div>
        <div class="stat-info">
          <h3>{{ stat.value }}</h3>
          <p class="stat-title">{{ stat.title }}</p>
          <span class="stat-sub">{{ stat.sub }}</span>
        </div>
      </div>
    </div>

    <!-- MAIN CHARTS ROW 1 -->
    <div class="charts-row">
      <!-- BIỂU ĐỒ ĐƯỜNG: DOANH THU & DỰ BÁO AI -->
      <div class="chart-card glass-panel revenue-col">
        <div class="card-header">
          <div class="header-left">
            <h3>Xu hướng Doanh thu & Dự báo nhu cầu AI</h3>
            <span class="badge-ai"><Sparkles :size="13" /> Machine Learning Forecast</span>
          </div>
        </div>
        <div class="chart-container">
          <Line :data="revenueChartData" :options="baseChartOptions" />
        </div>
      </div>

      <!-- BIỂU ĐỒ TRÒN: CƠ CẤU DOANH THU THEO MÔN -->
      <div class="chart-card glass-panel share-col">
        <div class="card-header">
          <h3>Cơ cấu Doanh thu theo Môn</h3>
        </div>
        <div class="chart-container doughnut-wrap">
          <Doughnut :data="revenueShareData" :options="doughnutOptions" />
        </div>
      </div>
    </div>

    <!-- MAIN CHARTS ROW 2 -->
    <div class="charts-row">
      <!-- BIỂU ĐỒ CỘT: TẦN SUẤT SỬ DỤNG THEO MÔN -->
      <div class="chart-card glass-panel col-half">
        <div class="card-header">
          <h3>Tần suất Giờ Đặt Sân theo Môn Thể Thao</h3>
          <span class="header-note">(Tổng số giờ đặt sân thành công)</span>
        </div>
        <div class="chart-container">
          <Bar :data="sportUsageData" :options="baseChartOptions" />
        </div>
      </div>

      <!-- BIỂU ĐỒ GIỜ CAO ĐIỂM -->
      <div class="chart-card glass-panel col-half">
        <div class="card-header">
          <div class="header-left">
            <h3>Phân tích Khung Giờ Đặt Sân Trong Ngày</h3>
            <span class="badge-fire"><Flame :size="14" /> Giờ vàng: 17h – 20h</span>
          </div>
        </div>
        <div class="chart-container">
          <Bar :data="peakHoursData" :options="baseChartOptions" />
        </div>
      </div>
    </div>

    <!-- BOTTOM SECTION: TOP VENUES & AI RECOMMENDATIONS -->
    <div class="bottom-grid">
      <!-- TOP SÂN ĐẮT KHÁCH NHẤT -->
      <div class="top-venues-card glass-panel">
        <div class="card-header">
          <div class="header-left">
            <Award :size="20" class="text-warning" />
            <h3>Top 5 Cụm Sân Doanh Thu Cao Nhất</h3>
          </div>
          <router-link to="/admin/fields" class="link-view-all">
            Xem tất cả sân <ArrowUpRight :size="16" />
          </router-link>
        </div>

        <div class="table-responsive">
          <table class="simple-table">
            <thead>
              <tr>
                <th>Cụm Sân</th>
                <th>Môn Thể Thao</th>
                <th>Khu Vực</th>
                <th>Lượt Đặt</th>
                <th>Doanh Thu</th>
                <th>Tỷ Lệ Lấp Đầy</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="venue in topVenues" :key="venue.id">
                <td>
                  <strong>{{ venue.name }}</strong>
                </td>
                <td>
                  <span class="sport-chip">{{ venue.sport }}</span>
                </td>
                <td><MapPin :size="13" /> {{ venue.district }}</td>
                <td>{{ venue.bookings }} lượt</td>
                <td><strong class="text-success">{{ venue.revenue }}</strong></td>
                <td>
                  <div class="fill-bar-wrapper">
                    <div class="fill-bar" :style="{ width: venue.fillRate }"></div>
                    <span>{{ venue.fillRate }}</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- NHẬT KÝ HOẠT ĐỘNG VÀ AI GỢI Ý -->
      <div class="activities-card glass-panel">
        <div class="card-header">
          <h3>Hoạt Động Gần Đây</h3>
        </div>

        <div class="activities-list">
          <div v-for="act in recentActivities" :key="act.id" class="activity-item">
            <div class="act-dot" :class="act.status"></div>
            <div class="act-content">
              <p class="act-text">{{ act.text }}</p>
              <div class="act-meta">
                <span class="act-time"><Clock :size="12" /> {{ act.time }}</span>
                <span class="act-badge">{{ act.badge }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="ai-box">
          <div class="ai-box-header">
            <Sparkles :size="16" />
            <strong>AI Gợi Ý Tối Ưu Doanh Thu</strong>
          </div>
          <p>
            Hiện tại tỷ lệ đặt sân Pickleball khung 09h - 14h chỉ đạt 42%. Đề xuất áp dụng mã giảm giá <strong>"HAPPYHOUR20"</strong> để kích cầu khung giờ vắng.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

/* Toolbar */
.dashboard-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.25rem 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.toolbar-left h2 {
  font-size: 1.3rem;
  font-weight: 700;
  margin-bottom: 2px;
}

.toolbar-sub {
  font-size: 0.85rem;
  color: var(--text-muted);
}

.period-toggle-group {
  display: flex;
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid var(--border-color);
  padding: 4px;
  border-radius: 12px;
  gap: 4px;
}

.period-btn {
  padding: 6px 14px;
  border-radius: 8px;
  color: var(--text-muted);
  font-size: 0.85rem;
  font-weight: 500;
  transition: var(--transition-fast);
}

.period-btn:hover {
  color: #fff;
}

.period-btn.active {
  background: var(--primary-color);
  color: #fff;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(99, 102, 241, 0.4);
}

/* Stats KPI Grid */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.25rem;
}

.stat-card {
  padding: 1.25rem 1.5rem;
  transition: var(--transition);
}

.stat-card:hover {
  transform: translateY(-3px);
}

.stat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.stat-icon-wrapper {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-change {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.8rem;
  font-weight: 600;
  padding: 3px 8px;
  border-radius: 20px;
}

.stat-change.positive {
  background: rgba(16, 185, 129, 0.15);
  color: #34d399;
}

.stat-change.negative {
  background: rgba(239, 68, 68, 0.15);
  color: #f87171;
}

.stat-info h3 {
  font-size: 1.6rem;
  font-weight: 700;
  letter-spacing: -0.02em;
}

.stat-title {
  color: var(--text-muted);
  font-size: 0.85rem;
  margin-top: 2px;
}

.stat-sub {
  display: block;
  font-size: 0.75rem;
  color: var(--text-dark);
  margin-top: 4px;
}

/* Charts Grid */
.charts-row {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 1.5rem;
}

.col-half {
  grid-column: span 1;
}

.charts-row:nth-child(4) {
  grid-template-columns: 1fr 1fr;
}

@media (max-width: 1100px) {
  .charts-row, .charts-row:nth-child(4) {
    grid-template-columns: 1fr;
  }
}

.chart-card {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.25rem;
}

.card-header h3 {
  font-size: 1.05rem;
  font-weight: 600;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.header-note {
  font-size: 0.8rem;
  color: var(--text-muted);
}

.badge-ai {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: rgba(99, 102, 241, 0.15);
  color: #818cf8;
  font-size: 0.75rem;
  padding: 3px 8px;
  border-radius: 12px;
  border: 1px solid rgba(99, 102, 241, 0.3);
}

.badge-fire {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: rgba(239, 68, 68, 0.15);
  color: #f87171;
  font-size: 0.75rem;
  padding: 3px 8px;
  border-radius: 12px;
  border: 1px solid rgba(239, 68, 68, 0.3);
}

.chart-container {
  position: relative;
  height: 280px;
  width: 100%;
}

.doughnut-wrap {
  height: 260px;
}

/* Bottom Grid */
.bottom-grid {
  display: grid;
  grid-template-columns: 1.8fr 1.2fr;
  gap: 1.5rem;
}

@media (max-width: 1100px) {
  .bottom-grid {
    grid-template-columns: 1fr;
  }
}

.top-venues-card, .activities-card {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
}

.link-view-all {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.85rem;
  color: var(--primary-hover);
  font-weight: 500;
}

.link-view-all:hover {
  text-decoration: underline;
}

.table-responsive {
  overflow-x: auto;
}

.simple-table {
  width: 100%;
  border-collapse: collapse;
}

.simple-table th {
  text-align: left;
  font-size: 0.8rem;
  color: var(--text-muted);
  font-weight: 600;
  text-transform: uppercase;
  padding: 0.75rem 0.5rem;
  border-bottom: 1px solid var(--border-color);
}

.simple-table td {
  padding: 0.85rem 0.5rem;
  font-size: 0.85rem;
  border-bottom: 1px solid var(--border-color);
}

.sport-chip {
  background: rgba(255, 255, 255, 0.06);
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 0.75rem;
  color: #cbd5e1;
}

.fill-bar-wrapper {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 120px;
}

.fill-bar {
  height: 6px;
  border-radius: 3px;
  background: #10b981;
}

.fill-bar-wrapper span {
  font-size: 0.75rem;
  color: var(--text-muted);
  font-weight: 600;
}

/* Activities List */
.activities-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.25rem;
}

.activity-item {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.act-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-top: 6px;
  flex-shrink: 0;
}

.act-dot.success { background: #10b981; box-shadow: 0 0 8px rgba(16, 185, 129, 0.5); }
.act-dot.info { background: #3b82f6; box-shadow: 0 0 8px rgba(59, 130, 246, 0.5); }
.act-dot.warning { background: #f59e0b; box-shadow: 0 0 8px rgba(245, 158, 11, 0.5); }
.act-dot.neutral { background: #94a3b8; }

.act-content {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.act-text {
  font-size: 0.85rem;
  color: #e2e8f0;
  line-height: 1.4;
}

.act-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}

.act-time {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.75rem;
  color: var(--text-dark);
}

.act-badge {
  background: rgba(255, 255, 255, 0.05);
  font-size: 0.7rem;
  padding: 1px 6px;
  border-radius: 4px;
  color: var(--text-muted);
}

/* AI Recommendation Box */
.ai-box {
  background: rgba(99, 102, 241, 0.1);
  border: 1px solid rgba(99, 102, 241, 0.25);
  border-radius: 12px;
  padding: 1rem;
  font-size: 0.85rem;
  color: #cbd5e1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ai-box-header {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #a5b4fc;
}

/* Color utilities */
.text-emerald-400 { color: #34d399; }
.bg-emerald-400\/10 { background-color: rgba(52, 211, 153, 0.1); }
.text-blue-400 { color: #60a5fa; }
.bg-blue-400\/10 { background-color: rgba(96, 165, 250, 0.1); }
.text-indigo-400 { color: #818cf8; }
.bg-indigo-400\/10 { background-color: rgba(129, 140, 248, 0.1); }
.text-purple-400 { color: #c084fc; }
.bg-purple-400\/10 { background-color: rgba(192, 132, 252, 0.1); }
.text-warning { color: #fbbf24; }
.text-success { color: #34d399; }
</style>
