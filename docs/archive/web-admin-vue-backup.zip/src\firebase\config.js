import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'

// Firebase Configuration cho dự án alobooking-b2484
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyA1b2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'alobooking-b2484.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'alobooking-b2484',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'alobooking-b2484.appspot.com',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '1029384756',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:1029384756:web:a1b2c3d4e5f6g7h8'
}

// Khởi tạo Firebase App
export const app = initializeApp(firebaseConfig)

// Khởi tạo các dịch vụ chính
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)
export const googleProvider = new GoogleAuthProvider()

export default {
  app,
  auth,
  db,
  storage,
  googleProvider,
  firebaseConfig
}
